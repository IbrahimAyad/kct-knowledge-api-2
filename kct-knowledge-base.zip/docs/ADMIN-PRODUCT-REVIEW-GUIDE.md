# KCT Menswear - Admin Product Review System

**Document Created:** January 18, 2026
**Last Updated:** January 18, 2026
**Admin User:** kctmenswear@gmail.com

---

## Overview

The Product Review admin panel allows KCT staff to manage Shopify products directly from the KCT website. It provides bulk tagging, image uploading, and product archiving capabilities.

**Location:** `/admin/product-review`
**Access:** Admin users only (verified by `useUserRole` hook)

---

## Features

### 1. Product Listing

The system fetches ALL active products from Shopify using the Admin API with pagination:

```
Shopify Admin API → shopify-products-admin edge function → Product Review page
```

**Data Retrieved:**
- Product ID, title, handle
- Product type
- Images
- Tags (comma-separated string converted to array)
- Created/Updated dates
- Status (active/archived/draft)

---

### 2. Product Status Management

Each product can be assigned one of three review statuses:

| Status | Color | Meaning | Action on Save |
|--------|-------|---------|----------------|
| **New** (Priority) | Green | High priority, new arrival | Adds `priority` tag |
| **Neutral** | Yellow | Standard product | Removes `priority` tag |
| **Archive** | Red | Should be removed | Sets product status to `archived` in Shopify |

---

### 3. Collection Tagging Mode

Bulk-apply collection tags to multiple products at once:

| Tag | Label | Purpose |
|-----|-------|---------|
| `kct-holiday` | Holiday | Holiday/seasonal collection |
| `kct-prom` | Prom | Prom season collection |
| `kct-wedding` | Wedding | Wedding collection |
| `NewIN` | New Arrivals | New arrivals featured section |

**How to Use:**
1. Click a collection tag button to enter tagging mode
2. Click products to select them (checkboxes appear)
3. Click "Add [Tag] Tag" to apply to all selected
4. Click "Remove Tag" to remove from selected

**Quick Action:** "Add NewIN to Priority Products" - Automatically adds `NewIN` tag to all products that have the `priority` tag.

---

### 4. Color Tag Management

Fix products with incorrect color tags:

**Available Colors:**
Red, Blue, Navy, Green, Black, White, Grey, Burgundy, Pink, Purple, Brown, Tan, Gold, Silver

**How to Use:**
1. Click a color button to filter products WITH that color tag
2. Select products that shouldn't have that color
3. Click "Remove [Color] Tag from Selected"

This is useful for fixing mis-tagged products that appear in wrong color filter results.

---

### 5. Image Upload

Upload new primary images for products:

1. Click on any product image
2. Upload modal opens
3. Select new image file
4. Image is marked "Ready" (blue badge)
5. Click "Save Changes" to upload to Shopify

The image is converted to base64 and sent to Shopify Admin API.

---

### 6. Duplicate Detection

The system automatically detects products with identical titles and displays:
- Orange "Duplicate (Nx)" badge
- Product handle shown to differentiate

---

## Technical Architecture

### Frontend Components

```
ProductReview.tsx (main page)
├── ProductReviewCard.tsx (individual product card)
│   ├── Status buttons (New/Neutral/Archive)
│   ├── Selection checkbox (bulk mode)
│   └── Collection tag badges
└── ImageUploadModal.tsx (image upload dialog)
```

### Edge Function

**File:** `supabase/functions/shopify-products-admin/index.ts`

**Actions:**

| Action | Description | Parameters |
|--------|-------------|------------|
| `list` | Fetch all active products with pagination | none |
| `archive` | Set product status to archived | `productId` |
| `update-tags` | Replace product tags | `productId`, `tags[]` |
| `bulk-update-tags` | Add/remove tag from multiple products | `productIds[]`, `tag`, `addTag` |
| `upload-image` | Upload base64 image as primary | `productId`, `image` |

**API Details:**
- Uses Shopify Admin API (requires `SHOPIFY_ADMIN_TOKEN`)
- API Version: 2024-10
- Handles pagination via Link header
- De-duplicates products by ID

---

## Workflow Examples

### Adding New Arrivals

1. Go to Product Review
2. Sort by "Newest First"
3. Click "New Arrivals" tag button
4. Select all new products
5. Click "Add New Arrivals Tag"
6. Products now appear in New Arrivals collection

### Preparing for Prom Season

1. Go to Product Review
2. Search for "prom" or relevant terms
3. Click "Prom" tag button
4. Select appropriate products
5. Click "Add Prom Tag"

### Archiving Old Products

1. Go to Product Review
2. Find products to remove
3. Click "Archive" button on each
4. Click "Save Changes"
5. Products are archived in Shopify

### Fixing Color Tags

1. Click "Blue" in Color Tag Management
2. View all products tagged "blue"
3. Select any that aren't actually blue
4. Click "Remove Blue Tag from Selected"

---

## Database Dependencies

This system does NOT use Supabase tables for product storage. It directly connects to:

- **Shopify Admin API** - Product data, tags, images
- **Supabase Auth** - Admin role verification

---

## Environment Variables Required

```
SHOPIFY_ADMIN_TOKEN - Shopify Admin API access token
```

This is stored in Supabase Edge Function secrets.

---

## Security

- Page protected by `useUserRole` hook
- Only users with `admin` role can access
- Admin role determined by `kctmenswear@gmail.com` account
- All Shopify API calls made server-side via edge functions

---

## Troubleshooting

### Products Show 0 Total

- Check if `SHOPIFY_ADMIN_TOKEN` is set in Supabase secrets
- Verify token has `read_products` and `write_products` scopes
- Check console for API errors

### Tags Not Saving

- Ensure you click "Save Changes" after making status changes
- Bulk tag operations save immediately (no save button needed)

### Image Upload Fails

- Check image file size (Shopify limit)
- Verify image is valid JPEG/PNG
- Check console for base64 encoding errors

---

## Related Documentation

- [AI Product Recommendations](./AI-PRODUCT-RECOMMENDATIONS.md)
- [Admin Dashboard Overview](./KCT-ATELIER-ADMIN-INTEGRATION-GUIDE.md)
