# KCT Menswear - AI Product Recommendations System

**Document Created:** January 18, 2026
**Last Updated:** January 18, 2026
**Status:** Active & Optimized

---

## Overview

KCT Menswear uses multiple AI-powered recommendation systems to suggest products to customers. These systems work together to increase engagement, average order value, and customer satisfaction.

---

## Recommendation Systems

### 1. Complete the Look (Complementary Products)

**Location:** Product detail pages
**Component:** `src/components/product/CompleteTheLook.tsx`
**Purpose:** Show items that go WITH the product being viewed

#### How It Works

1. Checks for Shopify metafields (`complementaryProducts`, `relatedProducts`)
2. If no metafields, uses smart matching algorithm
3. Displays up to 4 complementary items with bundle pricing

#### Smart Matching Algorithm

The `findSmartMatches` function:

1. **Detects product category** from title, productType, or tags:
   ```
   "Black and Red Floral Blazer" → category: "blazer"
   ```

2. **Looks up complementary categories**:
   ```javascript
   const complementaryCategories = {
     'blazer': ['shirt', 'tie', 'bowtie', 'pocket', 'pant', 'trouser', 'dress-shirt'],
     'tuxedo': ['shirt', 'bowtie', 'cummerbund', 'vest', 'shoe', 'pocket'],
     'suit': ['shirt', 'tie', 'bowtie', 'pocket', 'shoe', 'belt', 'cufflink'],
     'shirt': ['tie', 'bowtie', 'cufflink', 'suit', 'blazer', 'vest'],
     'tie': ['shirt', 'pocket', 'suit', 'blazer'],
     // ... etc
   };
   ```

3. **Color coordination** - Suggests colors that match:
   ```javascript
   const colorCoordination = {
     'black': ['white', 'black', 'silver', 'grey', 'red', 'burgundy', 'gold'],
     'navy': ['white', 'light-blue', 'blue', 'pink', 'silver', 'burgundy'],
     // ... etc
   };
   ```

4. **Scoring system**:
   - +50 points: Complementary product type
   - +20 points: Coordinating color
   - +10 points: Same occasion style
   - +5 points: Shared relevant tags (wedding, prom, formal, etc.)
   - +5 points: In stock

5. **Filter**: Only shows products with 50+ points (must be complementary)

#### Example

**Viewing:** Black and Red Floral Blazer

**Recommended:**
- White Tuxedo Shirt (+50 shirt, +20 white coordinates with black)
- Black Bow Tie (+50 bowtie, +20 black matches)
- Black Dress Pants (+50 pant, +20 black)

---

### 2. You May Also Like (Similar Products)

**Location:** Product detail pages
**Component:** `src/components/YouMayAlsoLike.tsx`
**Purpose:** Show similar style products for comparison shopping

#### How It Works

1. Fetches 50 products from Shopify
2. Scores each product based on similarity
3. Returns top 4 highest-scoring products

#### Scoring System

- +10 points: Same product type
- +5 points per matching tag
- +3 points: Similar price range (within $100)
- +2 points: In stock

#### Example

**Viewing:** Black and Red Floral Blazer

**Recommended:**
- Red Velvet Blazer (+10 same type, +5 Blazer tag, +5 holiday tag)
- Black Velvet Blazer (+10 same type, +5 Black tag, +5 Blazer tag)
- Navy Velvet Blazer (+10 same type, +5 Blazer tag)

---

### 3. Personalized Recommendations (Homepage)

**Location:** Homepage "Recommended for You" section
**Component:** `src/components/personalization/PersonalizedRecommendations.tsx`
**Purpose:** Personalized suggestions based on user behavior

#### How It Works

1. Uses `usePersonalizationEngine` hook to get user preferences
2. Fetches 50 Shopify products
3. Scores products against user preferences
4. Shows top recommendations with match percentage

#### Scoring System

- +20 points: Matches user's color preferences
- +15 points: Matches user's style preferences
- +15 points: Matches user's occasion preferences
- +10 points: Within user's price range
- +5 points: In stock
- ±10 points: Random variation for freshness

#### User Preference Sources

- Browsing history (stored in `ai_style_learning_data`)
- Search queries
- Outfit builder selections
- Purchase history
- Explicit preferences from profile

---

### 4. KCT Complete the Look (AI-Powered)

**Location:** Product detail pages (below standard Complete the Look)
**Component:** `src/components/KCTCompleteTheLook.tsx`
**Purpose:** AI-powered outfit coordination with style analysis

#### How It Works

1. Calls `kct-recommendations` edge function
2. Edge function calls KCT API (Railway-hosted)
3. Returns AI-analyzed outfit recommendations
4. Includes outfit validation score

#### KCT API Endpoint

```
POST /api/recommendations/complete-look
Host: kct-knowledge-api-2-production.up.railway.app
Authorization: Bearer [KCT_API_KEY]
```

#### Response Includes

- Product recommendations with confidence scores
- Style analysis (color harmony, style consistency, occasion match)
- Suggestions for improvement
- Formality level assessment

---

## Data Flow Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                      PRODUCT PAGE                                │
└─────────────────────────────────────────────────────────────────┘
                              │
        ┌─────────────────────┼─────────────────────┐
        │                     │                     │
        ▼                     ▼                     ▼
┌──────────────────┐  ┌───────────────────┐  ┌──────────────────┐
│ CompleteTheLook  │  │ KCTCompleteTheLook│  │ YouMayAlsoLike   │
│                  │  │                   │  │                  │
│ - Metafields     │  │ - KCT API         │  │ - Same type      │
│ - Smart matching │  │ - AI validation   │  │ - Tag matching   │
│ - Complementary  │  │ - Style scores    │  │ - Similar style  │
└────────┬─────────┘  └─────────┬─────────┘  └────────┬─────────┘
         │                      │                     │
         ▼                      ▼                     ▼
┌──────────────────────────────────────────────────────────────────┐
│                   SHOPIFY STOREFRONT API                         │
│                   Real product data, images, prices              │
└──────────────────────────────────────────────────────────────────┘
```

---

## Configuration

### Environment Variables

```
# Supabase Edge Function Secrets
KCT_API_URL=https://kct-knowledge-api-2-production.up.railway.app
KCT_API_KEY=[Bearer token]
SHOPIFY_STOREFRONT_TOKEN=[Storefront API token]
```

### Shopify Metafields (Optional)

Products can have these metafields for manual curation:

| Metafield | Type | Example |
|-----------|------|---------|
| `complementaryProducts` | JSON Array | `["navy-tie", "white-shirt"]` |
| `relatedProducts` | JSON Array | `["black-suit", "navy-suit"]` |

If metafields exist, they override the smart matching algorithm.

---

## Files Reference

### Frontend Components

| File | Purpose |
|------|---------|
| `src/components/product/CompleteTheLook.tsx` | Complementary product recommendations |
| `src/components/YouMayAlsoLike.tsx` | Similar product recommendations |
| `src/components/KCTCompleteTheLook.tsx` | AI-powered outfit recommendations |
| `src/components/personalization/PersonalizedRecommendations.tsx` | Homepage personalized section |

### Hooks

| File | Purpose |
|------|---------|
| `src/hooks/useEnhancedRecommendations.ts` | KCT API + Shopify enrichment |
| `src/hooks/useKCTRecommendations.ts` | KCT API wrapper with caching |
| `src/hooks/usePersonalizationEngine.ts` | User preference management |

### Edge Functions

| Function | Purpose |
|----------|---------|
| `kct-recommendations` | Calls KCT API for AI recommendations |
| `kct-outfit-validation` | Validates outfit color/style harmony |
| `ai-personalization-engine` | Analyzes user behavior patterns |
| `products-catalog` | Fetches Shopify products |

---

## Optimization History

### January 18, 2026

**Problem:** "Complete the Look" was showing alternative products (other suits) instead of complementary items (shirts, ties).

**Solution:** Rewrote `findSmartMatches` function to:
1. Detect product category
2. Look up complementary categories
3. Score by complementary type + color coordination
4. Filter to only show complementary products

**Result:** Now shows shirts, ties, and accessories instead of similar suits.

---

## Metrics & Analytics

Recommendation events are tracked to:

- **Supabase:** `recommendation_engagement` table
- **Railway Analytics:** Via `railwayAnalytics.trackRecommendationShown/Click`
- **Google Analytics:** Page view context

### Key Metrics

| Metric | Target |
|--------|--------|
| Recommendation click-through rate | 5-10% |
| "Complete the Look" add-to-cart rate | 3-5% |
| Personalized vs. non-personalized conversion | +20% |

---

## Troubleshooting

### No Recommendations Showing

1. Check if Shopify products are loading (`getProducts`)
2. Verify user preferences exist in `usePersonalizationEngine`
3. Check console for API errors

### Wrong Recommendations

1. Verify product has correct `productType` in Shopify
2. Check product tags include category keywords
3. Review complementary category mappings

### KCT API Errors

1. Check `KCT_API_URL` and `KCT_API_KEY` in Supabase secrets
2. Verify Railway service is running
3. Check rate limits (429 errors)

---

## Future Enhancements

See [AI Marketing Agents Roadmap](./AI-MARKETING-AGENTS-ROADMAP.md) for planned improvements including:

- Automated A/B testing of recommendation algorithms
- Machine learning model for personalization
- Real-time inventory-aware recommendations
- Cross-sell bundle optimization
