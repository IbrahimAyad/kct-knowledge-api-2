# KCT Atelier Admin: Blog & SEO Integration Guide

## Overview

This document provides everything needed to integrate blog scheduling, SEO reporting, and product recommendations into KCT Atelier Admin. The main KCT app already has a complete blog/SEO system that posts 2-3 articles per week and generates monthly SEO reports.

---

## 1. Blog Content System Architecture

### Two Content Sources

The blog system uses **two sources** that work together:

#### Source A: Static Blog Articles (Frontend - `src/data/blogArticles.ts`)
- **60+ pre-written articles** stored in a TypeScript file
- Supports **scheduled publishing** via `publishDate` field (ISO format: YYYY-MM-DD)
- Used for **high-quality, manually curated content**
- Includes images imported as ES6 modules

```typescript
export interface BlogArticle {
  id: string;
  slug: string;
  title: string;
  excerpt: string;
  category: string;           // Maps to blogCategories
  categoryColor: string;
  image: string;              // Full-size image
  thumbnailImage?: string;    // Optimized thumbnail
  author: BlogAuthor;
  date: string;
  readTime: string;
  tags: string[];             // For product matching & SEO
  content: string;            // Full HTML content
  featured: boolean;
  publishDate?: string;       // Schedule date (YYYY-MM-DD)
}
```

#### Source B: Content Queue (Database - `content_queue` table)
- **AI-generated/drafted content** stored in Supabase
- Used for **automated SEO blog agent** posts
- Contains SEO metrics and scheduling data

```sql
-- content_queue table structure
id: uuid
content_type: varchar      -- 'style-guide', 'how-to', 'trending', etc.
title: varchar
content: text              -- Full article content
template_used: varchar     -- Template that generated this
target_keywords: text[]    -- SEO keywords to target
status: varchar            -- 'draft', 'scheduled', 'pending_review', 'published'
priority: integer          -- 1 (highest) to 5 (lowest)
scheduled_date: timestamp  -- When to publish
generated_at: timestamp
reviewed_at: timestamp
published_at: timestamp
seo_metrics: jsonb         -- Pre-calculated SEO scores
```

**Sample `seo_metrics` JSON:**
```json
{
  "seo_score": 8.7,
  "readability": 8.9,
  "keyword_density": 0.024,
  "estimated_traffic": 1200
}
```

---

## 2. Blog Categories

```typescript
const blogCategories = [
  { id: "store-news", name: "Store News" },
  { id: "trending", name: "Trending" },
  { id: "style-guides", name: "Style Guides" },
  { id: "trends-news", name: "Trends & News" },
  { id: "how-to", name: "How-To" },
  { id: "product-spotlights", name: "Product Spotlights" },
  { id: "business-style", name: "Business Style" },
  { id: "occasion-guides", name: "Occasion Guides" },
  { id: "behind-the-scenes", name: "Behind the Scenes" }
];
```

---

## 3. Content Queue - Current Schedule

Query to get upcoming scheduled posts:

```sql
SELECT 
  id,
  title,
  content_type,
  target_keywords,
  status,
  priority,
  scheduled_date,
  seo_metrics
FROM content_queue 
WHERE status IN ('scheduled', 'pending_review', 'draft')
ORDER BY scheduled_date ASC;
```

### Current Schedule (as of Dec 2025):
| Date | Title | Type | SEO Score |
|------|-------|------|-----------|
| Dec 24 | Holiday Season Formal Wear Guide | trending | 9.0 |
| Dec 26 | Complete Guide to Velvet Blazers | style-guide | 8.7 |
| Dec 27 | Winter 2025 Color Palette: Burgundy & Emerald | product-spotlight | 8.8 |
| Dec 28 | Sustainable Luxury: Future of Premium Menswear | trending | 9.1 |
| Dec 29 | The Navy Business Suit | product-spotlight | 8.5 |
| Dec 30 | Smart Casual Evolution | business-style | 8.3 |
| Jan 5 | Shirt Fitting Guide | how-to | 7.9 |
| Jan 8 | Velvet Care and Maintenance | care-guide | 8.1 |

---

## 4. SEO Database Tables

### `seo_analysis` - Product SEO Analysis
```sql
id: uuid
product_id: uuid
seo_score: integer           -- 0-100
title_optimized: boolean
description_optimized: boolean
keywords_found: text[]       -- Current keywords in product
keywords_missing: text[]     -- Recommended keywords to add
image_alt_optimized: boolean
competitor_keywords: text[]  -- Keywords competitors use
suggested_keywords: text[]   -- AI-suggested keywords
analysis_date: timestamptz
```

### `seo_trends` - Keyword Trending Data
```sql
id: uuid
keyword: varchar             -- The keyword/phrase
search_volume: integer       -- Monthly search volume
trend_score: numeric         -- Trending score (0-100)
trend_direction: varchar     -- 'up', 'down', 'stable'
data_source: varchar         -- Where data came from
captured_at: timestamp
metadata: jsonb              -- Additional trend data
```

### `seo_tasks` - Actionable SEO Tasks
```sql
id: uuid
product_id: uuid
product_title: text
type: text                   -- 'keyword', 'meta', 'image', etc.
priority: text               -- 'high', 'medium', 'low'
status: text                 -- 'pending', 'in_progress', 'completed'
description: text            -- What needs to be done
created_at: timestamptz
updated_at: timestamptz
```

### `seo_performance` - Page Performance Tracking
```sql
id: uuid
page_path: text
page_title: text
meta_description: text
target_keywords: text[]
organic_traffic: integer
search_rankings: jsonb       -- Position data per keyword
core_web_vitals: jsonb       -- LCP, FID, CLS scores
date: date
```

### `blog_automation` - Blog Post Performance
```sql
id: uuid
article_id: varchar          -- Links to blogArticles
generation_date: timestamp
trend_source: varchar        -- What triggered this topic
template_used: varchar
keywords_targeted: text[]
image_url: varchar
auto_generated: boolean
performance_score: numeric   -- Post-publish performance
review_status: varchar       -- 'pending', 'approved', 'rejected'
```

### `blog_product_assignments` - Product ↔ Blog Links
```sql
id: uuid
blog_post_id: uuid           -- Links to content_queue
product_id: text             -- Shopify product ID or handle
assignment_type: varchar     -- 'featured', 'related', 'mentioned'
placement_context: text      -- Where in article to show
display_order: integer
custom_text: text            -- Override CTA text
performance_score: numeric
click_through_rate: numeric  -- CTR from blog to product
conversion_rate: numeric     -- Purchases from blog clicks
revenue_generated: numeric
is_active: boolean
```

---

## 5. Edge Functions for Blog/SEO

### `generate-blog-images`
Generates AI images for blog posts using Lovable AI.

**Endpoint:** `POST /functions/v1/generate-blog-images`

**Request:**
```json
{
  "prompts": [
    "Professional menswear photography showing burgundy velvet blazer..."
  ],
  "blogSlug": "velvet-blazer-guide-2025"
}
```

**Response:**
```json
{
  "success": true,
  "images": ["https://...storage.../blog-images/velvet-blazer-guide-2025_1.webp"],
  "count": 1
}
```

### `share-to-ifttt`
Shares published blog posts to social media (Twitter/X) via IFTTT webhook.

---

## 6. Blog-Product Integration Points

### Existing Function: `getRelevantArticles()`
Located in `src/data/blogArticles.ts` - scores articles by relevance to a product:

```typescript
function getRelevantArticles(
  productType: string,      // e.g., "blazer", "suit"
  productTitle: string,     // Product name
  productTags: string[],    // Product tags
  limit: number = 3
): BlogArticle[]
```

**Algorithm:**
1. Extracts search terms from product type, title, and tags
2. Scores each article by keyword matches
3. Boosts featured articles (+0.5)
4. Returns top `limit` articles

### Product Page Integration
On product detail pages (`src/pages/ProductDetail.tsx`), relevant blog articles are displayed using this function to drive engagement and SEO internal linking.

---

## 7. Monthly SEO Report Data Structure

For generating monthly SEO reports, query these tables:

```sql
-- Monthly traffic summary
SELECT 
  DATE_TRUNC('month', date) as month,
  SUM(organic_traffic) as total_organic_traffic,
  AVG(seo_score) as avg_seo_score,
  COUNT(DISTINCT page_path) as pages_tracked
FROM seo_performance
GROUP BY DATE_TRUNC('month', date)
ORDER BY month DESC;

-- Top performing keywords
SELECT 
  keyword,
  search_volume,
  trend_score,
  trend_direction
FROM seo_trends
WHERE captured_at >= NOW() - INTERVAL '30 days'
ORDER BY search_volume DESC
LIMIT 20;

-- SEO tasks completed this month
SELECT 
  type,
  priority,
  COUNT(*) as count
FROM seo_tasks
WHERE status = 'completed'
  AND updated_at >= NOW() - INTERVAL '30 days'
GROUP BY type, priority;

-- Blog post performance
SELECT 
  ba.article_id,
  ba.keywords_targeted,
  ba.performance_score,
  cq.title,
  cq.seo_metrics
FROM blog_automation ba
JOIN content_queue cq ON ba.article_id = cq.id::text
WHERE ba.generation_date >= NOW() - INTERVAL '30 days'
ORDER BY ba.performance_score DESC;
```

---

## 8. Product-Blog Assignment Queries

### Get products featured in blogs
```sql
SELECT 
  bpa.product_id,
  bpa.assignment_type,
  bpa.click_through_rate,
  bpa.conversion_rate,
  bpa.revenue_generated,
  cq.title as blog_title,
  cq.target_keywords
FROM blog_product_assignments bpa
JOIN content_queue cq ON bpa.blog_post_id = cq.id
WHERE bpa.is_active = true
ORDER BY bpa.revenue_generated DESC;
```

### Find products without blog coverage
```sql
-- This would need to compare against your Shopify product list
SELECT p.product_id, p.title
FROM products p  -- or your product source
LEFT JOIN blog_product_assignments bpa ON p.product_id = bpa.product_id
WHERE bpa.id IS NULL;
```

---

## 9. Recommended Features for Atelier Admin

### Blog Command Center
1. **Schedule Calendar View** - Visual calendar of upcoming posts
2. **Content Queue Manager** - Review, edit, approve AI-generated drafts
3. **SEO Score Dashboard** - Real-time SEO health metrics
4. **Product Assignment UI** - Drag-drop products to blog posts

### Monthly Report Generator
1. **Traffic Overview** - Organic traffic trends
2. **Keyword Rankings** - Position tracking over time
3. **Blog Performance** - CTR, conversions per post
4. **Product Attribution** - Revenue from blog-driven traffic
5. **Recommendations** - AI-suggested topics based on trends

### Integration Endpoints to Build
```typescript
// Get blog schedule for next 30 days
GET /api/blog/schedule?days=30

// Get SEO performance summary
GET /api/seo/monthly-report?month=2025-01

// Assign product to blog post
POST /api/blog/assign-product
{
  blogPostId: "uuid",
  productId: "shopify-handle",
  assignmentType: "featured"
}

// Get product SEO analysis
GET /api/products/:id/seo-analysis

// Generate SEO report email
POST /api/reports/seo-email
{
  month: "2025-01",
  recipients: ["email@example.com"]
}
```

---

## 10. Current Admin Tools (DO NOT REPLACE)

The main KCT app has existing admin tools at `/admin/*`:
- `BlogAdmin.tsx` - Share posts to Twitter/X
- `ProductReview.tsx` - Review Shopify products
- `ProductCategorization.tsx` - Categorize products

These handle **operational tasks**. Atelier Admin should focus on:
- **Analytics & Insights**
- **Content Planning**
- **SEO Strategy**
- **Performance Tracking**

---

## 11. Environment Variables Needed

```
SUPABASE_URL=<already configured>
SUPABASE_ANON_KEY=<already configured>
SUPABASE_SERVICE_ROLE_KEY=<for admin operations>
LOVABLE_API_KEY=<for AI blog image generation>
IFTTT_WEBHOOK_URL=<for social sharing>
```

---

## 12. Quick Start Queries for Atelier Admin

```sql
-- Dashboard: Upcoming content
SELECT title, scheduled_date, status, seo_metrics->>'seo_score' as score
FROM content_queue
WHERE scheduled_date >= NOW()
ORDER BY scheduled_date
LIMIT 10;

-- Dashboard: Top trending keywords
SELECT keyword, search_volume, trend_direction
FROM seo_trends
ORDER BY trend_score DESC
LIMIT 10;

-- Dashboard: Products needing SEO work
SELECT product_id, product_title, priority, description
FROM seo_tasks
WHERE status = 'pending'
ORDER BY priority
LIMIT 10;

-- Dashboard: Best performing blog-product combos
SELECT product_id, SUM(revenue_generated) as total_revenue
FROM blog_product_assignments
WHERE is_active = true
GROUP BY product_id
ORDER BY total_revenue DESC
LIMIT 10;
```

---

## 13. Internal Linking Reference

For complete internal linking coverage, the SEO Blog Agent uses **two link sources**:

### Product Links
- Stored in `blog_product_assignments` table
- Assigned by the Product Tool (Minimax) 
- 2-4 product links per post

### Site Links
- **Reference Document:** `docs/KCT-SITE-LINKS-REFERENCE.md`
- Contains 70+ linkable pages organized by category
- Elegant linking guidelines (subtle, not spammy)
- Topic-to-page mapping
- Seasonal priority calendar

**Key Site Link Categories:**
| Category | Pages | SEO Value |
|----------|-------|-----------|
| Collections | `/suits`, `/blazers`, `/tuxedos`, etc. | High |
| Occasions | `/black-tie`, `/graduations`, `/interview-attire` | Medium-High |
| Wedding | `/wedding`, `/weddings/color-matching`, style pages | High |
| Prom | `/prom`, `/prom/aura-quiz` | Seasonal |
| Resources | `/size-guide`, `/care-guide`, `/tailoring` | Trust-building |
| Trust/Policy | `/locations`, `/shipping`, `/returns` | Conversion support |

**Linking Rules:**
- Maximum 2-3 site links per blog post
- Anchor text must be descriptive (never "click here")
- Links should feel like helpful suggestions
- Never link the same page twice

---

## Summary

| Component | Location | Purpose |
|-----------|----------|---------|
| Static Articles | `src/data/blogArticles.ts` | 60+ curated articles with scheduling |
| Content Queue | `content_queue` table | AI-generated drafts, scheduled posts |
| SEO Analysis | `seo_analysis` table | Product SEO scores & recommendations |
| SEO Trends | `seo_trends` table | Keyword tracking & opportunities |
| SEO Tasks | `seo_tasks` table | Actionable optimization tasks |
| Blog-Product Links | `blog_product_assignments` | Revenue attribution |
| Site Links Reference | `docs/KCT-SITE-LINKS-REFERENCE.md` | 70+ internal linking targets |
| Image Generation | `generate-blog-images` function | AI blog images via Lovable |
| Social Sharing | `share-to-ifttt` function | Auto-post to Twitter/X |

This gives Atelier Admin everything needed to build a powerful SEO command center that complements the existing blog automation system.
