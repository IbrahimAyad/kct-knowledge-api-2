# KCT Images API Documentation

> **Version:** 4.0  
> **Base URL:** `https://kct-images-api.kctmenswear.workers.dev`  
> **Authentication:** Header `X-API-Key: kct-images-2024-secret`

---

## Overview

The KCT Images API is a Cloudflare Worker that provides image management for KCT Menswear. It handles uploads, optimization, AI-powered features, and delivers images in multiple formats optimized for social media and e-commerce.

### Key Features

- **Image Upload** - Single and batch uploads with metadata tagging
- **AI Alt Text** - Automatic SEO-optimized descriptions using Workers AI
- **Background Removal** - AI-powered background removal for product shots
- **Social Media Variants** - Pre-sized images for Instagram, Pinterest, Twitter, Facebook
- **Search & Organization** - Find images by filename, tags, or user ID
- **Secure Authentication** - API key protection on all endpoints

---

## Authentication

All endpoints (except `/` and `/health`) require the `X-API-Key` header:

```javascript
headers: {
  'X-API-Key': 'kct-images-2024-secret'
}
```

---

## Image URL Formats

After uploading, images are available in multiple formats:

### Standard Delivery
```
https://imagedelivery.net/QI-O2U_ayTU_H_Ilcb4c6Q/{image_id}/public
```

### Custom Domain (Better for SEO)
```
https://kctmenswear.com/cdn-cgi/imagedelivery/QI-O2U_ayTU_H_Ilcb4c6Q/{image_id}/public
```

### Social Media Variants

| Variant | Size | Use Case | URL Format |
|---------|------|----------|------------|
| `og` | 1200×630 | Facebook, LinkedIn, Open Graph | `/{image_id}/w=1200,h=630,fit=cover` |
| `twitter` | 1200×675 | Twitter/X cards | `/{image_id}/w=1200,h=675,fit=cover` |
| `instagram` | 1080×1080 | Instagram feed posts | `/{image_id}/w=1080,h=1080,fit=cover` |
| `instagramStory` | 1080×1920 | Instagram/TikTok stories | `/{image_id}/w=1080,h=1920,fit=cover` |
| `pinterest` | 1000×1500 | Pinterest pins | `/{image_id}/w=1000,h=1500,fit=cover` |

### E-commerce Variants

| Variant | Size | Use Case |
|---------|------|----------|
| `product` | 800×800 | Product cards |
| `productLarge` | 1200×1200 | Product detail pages |
| `card` | 400×300 | Small preview cards |
| `zoom` | 2000×2000 | Zoom/detail view |

---

## Endpoints

### Health Check

```
GET /
```

Returns API status and available endpoints. **No authentication required.**

**Response:**
```json
{
  "status": "ok",
  "service": "KCT Images API",
  "version": "4.0",
  "features": ["upload", "batch-upload", "search", "metadata", "social-variants", "background-removal", "ai-alt-text"],
  "variants": ["public", "thumbnail", "og", "twitter", "instagram", "instagramStory", "pinterest", "product", "productLarge", "card", "zoom"]
}
```

---

### Upload Single Image

```
POST /upload
```

Upload an image file or from URL with optional metadata.

#### Option 1: File Upload (multipart/form-data)

```javascript
const formData = new FormData();
formData.append('file', imageFile);
formData.append('id', 'custom-image-id'); // optional
formData.append('metadata', JSON.stringify({
  tag: 'suit-builder',
  user_id: 'user_123',
  product_ids: ['suit_001', 'shirt_002', 'tie_003']
}));

const response = await fetch('https://kct-images-api.kctmenswear.workers.dev/upload', {
  method: 'POST',
  headers: { 'X-API-Key': 'kct-images-2024-secret' },
  body: formData
});

const result = await response.json();
```

#### Option 2: URL Upload (application/json)

```javascript
const response = await fetch('https://kct-images-api.kctmenswear.workers.dev/upload', {
  method: 'POST',
  headers: {
    'X-API-Key': 'kct-images-2024-secret',
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    url: 'https://example.com/image.jpg',
    id: 'custom-image-id', // optional
    tag: 'product-photo',
    user_id: 'user_123',
    metadata: {
      category: 'suits',
      color: 'navy'
    }
  })
});
```

#### Response

```json
{
  "success": true,
  "imageId": "7d203d2a-63b7-46d3-9749-1f203e4ccc00",
  "filename": "image.jpg",
  "uploaded": "2024-12-30T21:30:00.000Z",
  "metadata": {
    "tag": "suit-builder",
    "user_id": "user_123",
    "uploaded_at": "2024-12-30T21:30:00.000Z"
  },
  "urls": {
    "public": "https://imagedelivery.net/QI-O2U_ayTU_H_Ilcb4c6Q/7d203d2a.../public",
    "thumbnail": "https://imagedelivery.net/QI-O2U_ayTU_H_Ilcb4c6Q/7d203d2a.../thumbnail",
    "customDomain": "https://kctmenswear.com/cdn-cgi/imagedelivery/QI-O2U_ayTU_H_Ilcb4c6Q/7d203d2a.../public",
    "og": "https://imagedelivery.net/.../w=1200,h=630,fit=cover",
    "twitter": "https://imagedelivery.net/.../w=1200,h=675,fit=cover",
    "instagram": "https://imagedelivery.net/.../w=1080,h=1080,fit=cover",
    "instagramStory": "https://imagedelivery.net/.../w=1080,h=1920,fit=cover",
    "pinterest": "https://imagedelivery.net/.../w=1000,h=1500,fit=cover",
    "product": "https://imagedelivery.net/.../w=800,h=800,fit=contain,background=white",
    "productLarge": "https://imagedelivery.net/.../w=1200,h=1200,fit=contain,background=white",
    "ogCustom": "https://kctmenswear.com/cdn-cgi/imagedelivery/.../w=1200,h=630,fit=cover"
  },
  "meta": {
    "og": "<meta property=\"og:image\" content=\"https://kctmenswear.com/cdn-cgi/imagedelivery/...\" />",
    "twitter": "<meta name=\"twitter:image\" content=\"...\" />"
  },
  "social": {
    "facebook": "https://kctmenswear.com/cdn-cgi/imagedelivery/.../w=1200,h=630,fit=cover",
    "twitter": "https://kctmenswear.com/cdn-cgi/imagedelivery/.../w=1200,h=675,fit=cover",
    "instagram": "https://kctmenswear.com/cdn-cgi/imagedelivery/.../w=1080,h=1080,fit=cover",
    "pinterest": "https://imagedelivery.net/.../w=1000,h=1500,fit=cover"
  }
}
```

---

### Get Direct Upload URL (Frontend Uploads)

```
POST /upload-url
```

Get a one-time upload URL for secure frontend uploads without exposing API keys.

```javascript
// Step 1: Get upload URL from your backend
const response = await fetch('https://kct-images-api.kctmenswear.workers.dev/upload-url', {
  method: 'POST',
  headers: {
    'X-API-Key': 'kct-images-2024-secret',
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    id: 'suit-builder/user_123/combo_456', // optional custom ID
    tag: 'suit-builder',
    user_id: 'user_123'
  })
});

const { uploadURL, imageId } = await response.json();

// Step 2: Upload directly to Cloudflare from frontend (no API key needed)
const formData = new FormData();
formData.append('file', userSelectedFile);

await fetch(uploadURL, {
  method: 'POST',
  body: formData
});

// Step 3: Image is now available at the returned URLs
```

#### Response

```json
{
  "success": true,
  "uploadURL": "https://upload.imagedelivery.net/...",
  "imageId": "suit-builder/user_123/combo_456",
  "expiresAt": "2024-12-30T22:00:00.000Z",
  "afterUpload": {
    "urls": {
      "public": "https://imagedelivery.net/.../public",
      "og": "https://imagedelivery.net/.../w=1200,h=630,fit=cover"
    }
  }
}
```

---

### Batch Upload

```
POST /batch-upload
```

Upload up to 20 images at once.

```javascript
const response = await fetch('https://kct-images-api.kctmenswear.workers.dev/batch-upload', {
  method: 'POST',
  headers: {
    'X-API-Key': 'kct-images-2024-secret',
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    images: [
      { url: 'https://example.com/suit1.jpg', id: 'suits/navy-001' },
      { url: 'https://example.com/suit2.jpg', id: 'suits/gray-002' },
      { url: 'https://example.com/suit3.jpg', id: 'suits/black-003' }
    ],
    defaultMetadata: {
      tag: 'spring-collection-2025',
      category: 'suits'
    }
  })
});
```

#### Response

```json
{
  "success": true,
  "summary": {
    "total": 3,
    "successful": 3,
    "failed": 0
  },
  "results": [
    {
      "success": true,
      "requestedId": "suits/navy-001",
      "imageId": "suits/navy-001",
      "filename": "suit1.jpg",
      "urls": { ... }
    }
  ],
  "errors": []
}
```

---

### List Images

```
GET /list
GET /list?page=1&limit=50
```

List all images with pagination.

```javascript
const response = await fetch('https://kct-images-api.kctmenswear.workers.dev/list?page=1&limit=20', {
  headers: { 'X-API-Key': 'kct-images-2024-secret' }
});
```

#### Response

```json
{
  "success": true,
  "page": 1,
  "limit": 20,
  "count": 20,
  "images": [
    {
      "id": "7d203d2a-63b7-46d3-9749-1f203e4ccc00",
      "filename": "shoe-image.jpg",
      "uploaded": "2024-07-30T...",
      "metadata": { "tag": "product" },
      "urls": { ... }
    }
  ]
}
```

---

### Search Images

```
GET /search?q={query}
GET /search?tag={tag}
GET /search?user_id={user_id}
```

Search images by filename, tag, user ID, or source.

```javascript
// Search by filename
const response = await fetch('https://kct-images-api.kctmenswear.workers.dev/search?q=wedding', {
  headers: { 'X-API-Key': 'kct-images-2024-secret' }
});

// Search by tag
const response = await fetch('https://kct-images-api.kctmenswear.workers.dev/search?tag=suit-builder', {
  headers: { 'X-API-Key': 'kct-images-2024-secret' }
});

// Search by user
const response = await fetch('https://kct-images-api.kctmenswear.workers.dev/search?user_id=user_123', {
  headers: { 'X-API-Key': 'kct-images-2024-secret' }
});

// Combined search
const response = await fetch('https://kct-images-api.kctmenswear.workers.dev/search?tag=suit-builder&user_id=user_123', {
  headers: { 'X-API-Key': 'kct-images-2024-secret' }
});
```

#### Response

```json
{
  "success": true,
  "search": { "q": "wedding", "tag": null, "user_id": null },
  "page": 1,
  "limit": 50,
  "totalMatches": 5,
  "count": 5,
  "images": [ ... ]
}
```

---

### Get Image Details

```
GET /image/{image_id}
```

Get details for a single image.

```javascript
const response = await fetch('https://kct-images-api.kctmenswear.workers.dev/image/7d203d2a-63b7-46d3-9749-1f203e4ccc00', {
  headers: { 'X-API-Key': 'kct-images-2024-secret' }
});
```

#### Response

```json
{
  "success": true,
  "image": {
    "id": "7d203d2a-63b7-46d3-9749-1f203e4ccc00",
    "filename": "shoe-image.jpg",
    "uploaded": "2024-07-30T...",
    "metadata": { ... },
    "urls": { ... },
    "variants": [ ... ]
  }
}
```

---

### Delete Image

```
DELETE /delete/{image_id}
```

Delete an image.

```javascript
const response = await fetch('https://kct-images-api.kctmenswear.workers.dev/delete/7d203d2a-63b7-46d3-9749-1f203e4ccc00', {
  method: 'DELETE',
  headers: { 'X-API-Key': 'kct-images-2024-secret' }
});
```

#### Response

```json
{
  "success": true,
  "message": "Image 7d203d2a-63b7-46d3-9749-1f203e4ccc00 deleted"
}
```

---

### Generate AI Alt Text

```
POST /generate-alt-text
```

Generate SEO-optimized alt text using AI.

```javascript
// Using image_id
const response = await fetch('https://kct-images-api.kctmenswear.workers.dev/generate-alt-text', {
  method: 'POST',
  headers: {
    'X-API-Key': 'kct-images-2024-secret',
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    image_id: '7d203d2a-63b7-46d3-9749-1f203e4ccc00',
    saveToMetadata: true // optional: save alt text to image metadata
  })
});

// Using direct URL
const response = await fetch('https://kct-images-api.kctmenswear.workers.dev/generate-alt-text', {
  method: 'POST',
  headers: {
    'X-API-Key': 'kct-images-2024-secret',
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    url: 'https://imagedelivery.net/QI-O2U_ayTU_H_Ilcb4c6Q/7d203d2a.../public'
  })
});
```

#### Response

```json
{
  "success": true,
  "imageId": "7d203d2a-63b7-46d3-9749-1f203e4ccc00",
  "imageUrl": "https://imagedelivery.net/.../public",
  "altText": "KCT Menswear - A stylish man in a gray blazer and brown leather shoes sits on a chair, exuding sophistication and elegance.",
  "htmlAlt": "alt=\"KCT Menswear - A stylish man in a gray blazer and brown leather shoes sits on a chair, exuding sophistication and elegance.\"",
  "seoTips": [
    "Include primary keyword (suit, shirt, tie)",
    "Mention color and style",
    "Keep under 125 characters",
    "Avoid \"image of\" or \"picture of\""
  ]
}
```

---

### Remove Background (AI)

```
POST /remove-background
```

Remove background from product images using AI.

```javascript
const response = await fetch('https://kct-images-api.kctmenswear.workers.dev/remove-background', {
  method: 'POST',
  headers: {
    'X-API-Key': 'kct-images-2024-secret',
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    image_id: '7d203d2a-63b7-46d3-9749-1f203e4ccc00'
  })
});
```

---

## Common Use Cases

### Suit Builder - Save Generated Combo Image

When a user creates a suit combination and you generate a preview image:

```javascript
async function saveSuitBuilderImage(imageBlob, userId, products) {
  const formData = new FormData();
  formData.append('file', imageBlob, 'suit-combo.png');
  formData.append('metadata', JSON.stringify({
    tag: 'suit-builder',
    user_id: userId,
    product_ids: products.map(p => p.id),
    product_names: products.map(p => p.name).join(' + '),
    created_at: new Date().toISOString()
  }));

  const response = await fetch('https://kct-images-api.kctmenswear.workers.dev/upload', {
    method: 'POST',
    headers: { 'X-API-Key': 'kct-images-2024-secret' },
    body: formData
  });

  const result = await response.json();
  
  // Save to Supabase
  await supabase.from('suit_combinations').insert({
    user_id: userId,
    image_id: result.imageId,
    image_url: result.urls.customDomain,
    share_url: result.urls.ogCustom, // For social sharing
    products: products
  });

  return result;
}
```

### Social Sharing - Get OG Image URL

```javascript
function getShareUrls(imageId) {
  const base = `https://kctmenswear.com/cdn-cgi/imagedelivery/QI-O2U_ayTU_H_Ilcb4c6Q/${imageId}`;
  
  return {
    facebook: `${base}/w=1200,h=630,fit=cover`,
    twitter: `${base}/w=1200,h=675,fit=cover`,
    instagram: `${base}/w=1080,h=1080,fit=cover`,
    pinterest: `${base}/w=1000,h=1500,fit=cover`
  };
}
```

### Product Page - Generate Alt Text for SEO

```javascript
async function getProductAltText(imageId) {
  const response = await fetch('https://kct-images-api.kctmenswear.workers.dev/generate-alt-text', {
    method: 'POST',
    headers: {
      'X-API-Key': 'kct-images-2024-secret',
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ 
      image_id: imageId,
      saveToMetadata: true 
    })
  });

  const result = await response.json();
  return result.altText;
}
```

### Find User's Saved Combinations

```javascript
async function getUserCombinations(userId) {
  const response = await fetch(`https://kct-images-api.kctmenswear.workers.dev/search?tag=suit-builder&user_id=${userId}`, {
    headers: { 'X-API-Key': 'kct-images-2024-secret' }
  });

  const result = await response.json();
  return result.images;
}
```

---

## Error Handling

All endpoints return consistent error responses:

```json
{
  "error": "Error message",
  "details": { ... }
}
```

### Common HTTP Status Codes

| Status | Meaning |
|--------|---------|
| 200 | Success |
| 400 | Bad request (missing/invalid parameters) |
| 401 | Unauthorized (invalid or missing API key) |
| 404 | Image not found |
| 500 | Server error |

### Example Error Handling

```javascript
async function uploadImage(file) {
  try {
    const response = await fetch('https://kct-images-api.kctmenswear.workers.dev/upload', {
      method: 'POST',
      headers: { 'X-API-Key': 'kct-images-2024-secret' },
      body: formData
    });

    const result = await response.json();

    if (!result.success) {
      console.error('Upload failed:', result.error);
      throw new Error(result.error);
    }

    return result;
  } catch (error) {
    console.error('API error:', error);
    throw error;
  }
}
```

---

## Environment Variables

The worker uses these environment variables (already configured):

| Variable | Description |
|----------|-------------|
| `CF_ACCOUNT_ID` | Cloudflare account ID |
| `CF_IMAGES_TOKEN` | Cloudflare Images API token |
| `ACCOUNT_HASH` | `QI-O2U_ayTU_H_Ilcb4c6Q` |
| `API_SECRET` | `kct-images-2024-secret` |

---

## Rate Limits

- **Cloudflare Images:** 100 requests/second
- **Workers AI:** 100 requests/minute (for alt text, background removal)
- **Batch Upload:** Max 20 images per request

---

## Support

For issues or feature requests, contact the development team or check the Cloudflare Workers logs in the dashboard.
