# URL Routing Map — kctmenswear.com

Every URL that matters, which layer handles it, and what happens.

Last updated: Feb 15, 2026

## Request Flow

```
Request → Cloudflare Edge Cache → Middleware → _redirects → SPA Router
```

A request stops at the first layer that returns a response. If middleware returns, `_redirects` never fires. If `_redirects` matches, the SPA router never sees it.

## Critical Collection Pages (1/3 of search traffic)

These 5 URLs are handled by **three layers simultaneously** — middleware for crawlers, middleware for SPA shell, and React Router for client-side rendering.

| URL | Crawlers (Googlebot) | Regular Users | SPA Router |
|-----|---------------------|---------------|------------|
| `/collections/velvet-blazers` | Pre-rendered HTML (line 1831) | ASSETS.fetch index.html (line 1941) | `<VelvetBlazersCollectionPage />` |
| `/collections/shiny-shirts` | Pre-rendered HTML (line 1831) | ASSETS.fetch index.html (line 1941) | `<ShinyShirtsCollectionPage />` |
| `/collections/blue-prom` | Pre-rendered HTML (line 1831) | ASSETS.fetch index.html (line 1941) | `<BluePromCollectionPage />` |
| `/collections/floral-suits` | Pre-rendered HTML (line 1831) | ASSETS.fetch index.html (line 1941) | `<FloralSuitsCollectionPage />` |
| `/collections/wedding-colors` | Pre-rendered HTML (line 1831) | ASSETS.fetch index.html (line 1941) | `<WeddingColorsCollectionPage />` |

**Why three layers?** Crawlers can't run JavaScript, so middleware serves them pre-rendered HTML with correct canonicals. Regular users get the SPA shell from middleware (not `_redirects`, which would 301 to `/`). React Router then hydrates the page client-side.

## Legacy URL Redirects (middleware, lines 1873-1922)

| Pattern | Redirects To | Type |
|---------|-------------|------|
| `/pages/contact-us`, `/pages/contact`, `/pages/about`, `/pages/about-us` | `/contact` | 301 |
| `/pages/location-and-hours`, `/pages/locations`, `/pages/store-locations` | `/locations` | 301 |
| `/pages/size-guide`, `/pages/sizing-guide`, `/pages/size-chart` | `/size-guide` | 301 |
| `/pages/care-guide`, `/pages/garment-care` | `/care-guide` | 301 |
| `/pages/tailoring`, `/pages/tailoring-services`, `/pages/alterations` | `/tailoring` or `/tailoring-services` | 301 |
| `/pages/wedding`, `/pages/wedding-services` | `/wedding` or `/wedding-services` | 301 |
| `/pages/prom` | `/prom` | 301 |
| `/pages/:slug` (generic) | `/:slug` | 301 |
| `/blogs/news/:slug` | `/blog/:slug` | 301 |
| `/blogs/*` | `/blog` | 301 |
| `/products/:handle` | `/product/:handle` | 301 |
| `/cart/*`, `/checkout/*` | `kctmenswear.myshopify.com/...` | 302 |

## _redirects File (only fires if middleware calls context.next())

### Wedding
| Pattern | Redirects To |
|---------|-------------|
| `/collections/wedding-suits` | `/kalamazoo-wedding-suits` |
| `/collections/wedding-tuxedos` | `/kalamazoo-wedding-suits` |
| `/collections/wedding` | `/kalamazoo-wedding-suits` |
| `/collections/groom-suits` | `/groom-collection` |
| `/collections/groomsmen*` | `/kalamazoo-wedding-suits` |

### Collections Catch-All
| Pattern | Redirects To | Notes |
|---------|-------------|-------|
| `/collections/all` | `/shop` | Explicit |
| `/collections/frontpage` | `/shop` | Explicit |
| `/collections/:slug` | `/shop` | Catches everything not handled above |

### SPA Fallback (last rule)
| Pattern | Rewrites To | Type |
|---------|------------|------|
| `/*` | `/index.html` | 200 rewrite |

## Sitemaps and Feeds (middleware, lines 2043-2174)

| URL | Handler |
|-----|---------|
| `/sitemap.xml` | `generatePagesSitemap()` — index of all sub-sitemaps |
| `/sitemap-pages.xml` | Static pages sitemap |
| `/sitemap-products.xml` | Dynamic product sitemap from Supabase |
| `/sitemap-blog.xml` | Blog posts sitemap |
| `/sitemap-collections.xml` | `generateCollectionsSitemap()` — includes all 5 critical URLs |
| `/robots.txt` | Static robots rules (allows Googlebot, blocks AI bots) |
| `/google-products.xml` | Google Merchant Center product feed |
| `/local-inventory.xml` | Local inventory feed |

## Crawler Detection

| Function | Detects | Used For |
|----------|---------|----------|
| `isSearchCrawler()` line 1021 | Googlebot, Bingbot, DuckDuckBot, etc. | Pre-rendered HTML |
| `isSocialCrawler()` line 1001 | Facebook, Twitter, LinkedIn, WhatsApp, etc. | OG tags HTML |
| `isCrawler()` line 1061 | Both of the above | General bot check |

## Bot Bypasses (skip all middleware processing)

| Bot | User-Agent | Why |
|-----|-----------|-----|
| MoltBot | `moltbot` | Headless Chrome audit tool — causes 100+ requests per page |
| ClawdBot | `clawdbot` | Custom audit bot |
| KCT Automation | `kct-automation` | Internal automation |
| KCT Bot Token | `kct-bot-token` | Internal bot |
