# Wedding Party Issues & Fixes

**Date:** 2026-01-29
**Status:** Ready to apply

## Issues Found

### 1. ❌ Can't Join Wedding When Already Logged In (400 Error)
**Error:** `guest-join-wedding` returns 400 when user is already authenticated
**Cause:** Function requires password field even for logged-in users
**Impact:** Admins/existing users can't test wedding party flow

### 2. ❌ Can't Save Measurements (403 Error)
**Error:** `wedding_measurements` table returns 403 Forbidden
**Cause:** Missing RLS (Row Level Security) policies
**Impact:** Wedding party members can't save their sizes

### 3. ⚠️ Background 403 Errors (Non-Critical)
**Tables:** `ai_style_memory`, `content_queue`, `featured_products`, `ai_style_learning_data`
**Cause:** RLS policies blocking anonymous access
**Impact:** None - these are background queries that fail gracefully

---

## Fix #1: RLS Policies for wedding_measurements

**Apply this SQL in Supabase Dashboard → SQL Editor:**

```sql
-- Enable RLS
ALTER TABLE wedding_measurements ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if any
DROP POLICY IF EXISTS "Users can view their own wedding measurements" ON wedding_measurements;
DROP POLICY IF EXISTS "Users can insert their own wedding measurements" ON wedding_measurements;
DROP POLICY IF EXISTS "Users can update their own wedding measurements" ON wedding_measurements;

-- Allow users to view their own measurements
CREATE POLICY "Users can view their own wedding measurements"
ON wedding_measurements
FOR SELECT
USING (
  auth.uid() IN (
    SELECT user_id
    FROM wedding_party_members
    WHERE id = wedding_measurements.party_member_id
  )
);

-- Allow users to insert their own measurements
CREATE POLICY "Users can insert their own wedding measurements"
ON wedding_measurements
FOR INSERT
WITH CHECK (
  auth.uid() IN (
    SELECT user_id
    FROM wedding_party_members
    WHERE id = wedding_measurements.party_member_id
  )
);

-- Allow users to update their own measurements
CREATE POLICY "Users can update their own wedding measurements"
ON wedding_measurements
FOR UPDATE
USING (
  auth.uid() IN (
    SELECT user_id
    FROM wedding_party_members
    WHERE id = wedding_measurements.party_member_id
  )
);
```

**How to apply:**
1. Go to https://supabase.com/dashboard/project/gvcswimqaxvylgxbklbz/sql/new
2. Paste the SQL above
3. Click "Run"

---

## Fix #2: Allow Logged-In Users to Join Wedding

**Issue:** The `guest-join-wedding` function requires first_name, email, AND password even for authenticated users.

**Options:**

**Option A: Quick Fix** - Always use incognito/private browsing for testing
**Option B: Code Fix** - Modify function to detect authenticated users and skip password requirement

**If you want Option B, we can update the Edge Function to:**
1. Check Authorization header for existing session
2. If authenticated, use that user's info
3. Skip password requirement for logged-in users

---

## Testing Checklist

After applying Fix #1, test this flow:

### Happy Path (New User)
1. ✅ Go to `/weddings/join?code=WHITAKER` (or your wedding code)
2. ✅ Fill in: First Name, Last Name, Email (new), Password
3. ✅ Click "Join Wedding Party"
4. ✅ Should redirect to groomsmen dashboard
5. ✅ Click "Add My Measurements"
6. ✅ Fill in jacket size (e.g., 40R), chest (e.g., 40)
7. ✅ Click "Save Measurements"
8. ✅ Should save successfully without 403 error

### Edge Case (Logged-In User)
1. ⚠️ Log in with existing account (e.g., `kctmenswear@gmail.com`)
2. ⚠️ Try to join a wedding party
3. ⚠️ **Expected:** May still get 400 error (use incognito instead)
4. ✅ **Workaround:** Log out first, or use private browsing

---

## Root Cause Analysis

### Why This Happened

1. **Wedding measurements RLS missing:** Table was created but RLS policies were never added
2. **Logged-in user flow not tested:** Function assumes users are creating new accounts, not using existing ones
3. **Background queries failing silently:** Frontend makes optional queries that fail when not authenticated (acceptable)

### Prevention

- Add RLS policies when creating new tables
- Test with both new and existing users
- Monitor Supabase logs for 403/401 patterns

---

## Status

- [ ] Apply SQL fix for wedding_measurements RLS
- [ ] Test new user flow end-to-end
- [ ] Decide if we need to fix logged-in user flow
- [ ] Document wedding party onboarding for customers

---

**Next:** After applying the SQL fix above, test the flow in private browsing to verify measurements can be saved.
