# KCT Menswear — Admin Product Manager Guide

> **Purpose**: This document is for the Claude Coworker managing products locally for media, content, and marketing. It explains the Admin Product Manager tool, what curation has been done, and the tagging system used to organize the catalog.

---

## 1. What Is the Admin Product Manager?

The Admin Product Manager (`/admin/product-review`) is a custom-built internal tool that connects **directly to the Shopify Admin API** to manage the full KCT Menswear product catalog. It is the single source of truth for product organization.

### Core Capabilities

| Feature | Description |
|---|---|
| **Full Catalog View** | Loads ALL ~870+ Shopify products via paginated Admin API calls |
| **Product Categorization** | Assign products as **New** (priority), **Neutral** (standard), or **Archive** (remove) |
| **Image Upload** | Upload new main product images directly to Shopify |
| **Tag Management** | Apply structured tags for collections, types, and styles |
| **Duplicate Detection** | Auto-identifies products with identical titles, shows handles to distinguish |
| **Bulk Save** | Push all categorization, image, and tag changes to Shopify in one action |
| **Search & Sort** | Filter by title/handle, sort A-Z or Z-A |

### How It Works (Technical)

- **Edge Function**: `supabase/functions/shopify-products-admin/index.ts`
- **API**: Shopify Admin REST API (not Storefront API)
- **Actions**: `list`, `archive`, `updateTags`, `uploadImage`
- **Pagination**: Follows Shopify `Link` header `rel="next"` to fetch all pages (250 products/page)
- **De-duplication**: Tracks seen product IDs to prevent duplicates across pages

---

## 2. Catalog Status Overview

| Metric | Count |
|---|---|
| **Active Shopify Products** | 807 |
| **Archived/Draft Products** | 554 |
| **Products with Tags** | 667 (82.7%) |
| **Untagged Products** | 140 (17.3%) |
| **In-Stock Products (in Google Feed)** | 187 products → 1,776 variants |

---

## 3. The Tagging System

Products are organized using a **3-dimensional tagging hierarchy**:

### Dimension 1: Collection Tags (`kct-*`)
These are the primary storefront collection identifiers:

| Tag | Purpose | Products |
|---|---|---|
| `kct-prom` | Prom season collection | ~102 |
| `kct-wedding` | Wedding collection | Used on wedding-specific items |
| `kct-holiday` | Holiday/seasonal collection | Holiday sparkle items, shoes |

### Dimension 2: Type Tags (`kct-type-*`)
Product type classification:

| Tag | Purpose |
|---|---|
| `kct-type-tuxedo` | Full tuxedo sets |
| `kct-type-shoe` | Dress shoes & loafers |
| `kct-type-shirt` | Dress shirts |
| `kct-type-blazer` | Blazers & sport coats |

### Dimension 3: Style Tags (`kct-style-*`)
Visual/style classification:

| Tag | Purpose |
|---|---|
| `kct-style-fancy` | Sparkle, velvet, crystal, embellished items |
| `kct-style-classic` | Traditional solid colors, clean lines |

### Priority/Status Tags

| Tag | Meaning |
|---|---|
| `NewIN` | Newly added to inventory — display priority |
| `priority` | Admin-flagged for featured placement |
| `new-arrivals` | Part of new arrivals collection |
| `2025-collection` | Current season collection marker |
| `SA-2026` | Spring/Summer 2026 arrivals |
| `prom-2026` | Prom 2026 specific items |

---

## 4. What Has Been Curated — Product-by-Product

### ✅ Fully Curated Tuxedos (Rich Tags Applied)

These products received the most comprehensive tagging with 30-60+ tags each covering collection, occasion, season, style, and SEO keywords:

| Product Name | Key Tags Applied |
|---|---|
| Black 3-Piece Tuxedo \| Shawl Lapel \| Wedding Groom Formal | `kct-prom`, `kct-type-tuxedo`, `NewIN`, `priority`, `SA-2026`, `Prom 2026`, all 4 seasons, `Groom`, `Wedding Tuxedo`, `Gala` |
| Black Damask 3-Piece Tuxedo \| Classic Luxury Brocade | `kct-prom`, `kct-style-fancy`, `NewIN`, `priority`, `Paisley`, `Damask`, `Statement Tuxedo`, `Luxury` |
| White Damask Tuxedo \| White Formal Brocade | `kct-prom`, `kct-style-fancy`, `NewIN`, `priority`, `Holiday`, `Burgundy`, `Wine`, `Christmas` |
| Sand Taupe Three-Piece Tuxedo | `kct-prom`, `kct-type-tuxedo`, `NewIN`, `priority`, `Groomsmen`, `Homecoming`, all seasons |
| Burgundy 3-Piece Tuxedo \| Contemporary Wedding Formal | `kct-prom`, `kct-type-tuxedo`, `NewIN`, `priority`, `Steel Grey`, `Groomsmen` |
| Black Patterned Velvet Tuxedo \| Formal Suit | `kct-prom`, `kct-style-fancy`, `NewIN`, `priority`, `Velvet`, `Sparkle`, `Chambelan`, `Quinceanera` |
| Teal Velvet Chevron 3-Piece Tuxedo \| Prom Luxe Sparkle | `kct-prom`, `kct-style-fancy`, `NewIN`, `priority`, `Teal`, `Turquoise`, `Velvet`, `Sparkle` |
| Emerald Green Velvet Sparkle 3-Piece Tuxedo \| Holiday Luxe | `kct-prom`, `kct-holiday`, `kct-style-fancy`, `NewIN`, `priority`, `Christmas`, `Emerald`, `New Years` |
| Black Velvet Sparkle Tuxedo \| Midnight Gala Luxe | `kct-prom`, `kct-style-fancy`, `NewIN`, `priority`, `Velvet`, `Sparkle`, `Gala` |
| Black Sequin Diamond Tuxedo \| Gala Formal Beaded | `kct-prom`, `kct-style-fancy`, `NewIN`, `priority`, `Sequin`, `Gatsby`, `Glamorous`, `Golden` |

### ✅ Curated European Crystal Collection (Prom 2026)

Brand new premium line with structured tagging:

| Product Name | Key Tags Applied |
|---|---|
| Black & Emerald Green Crystal 3-Piece Tuxedo \| European Made | `kct-prom`, `kct-style-fancy`, `NewIN`, `priority`, `prom-2026`, `crystal`, `embellished`, `european-made`, `rhinestone` |
| Black & Gold Crystal 3-Piece Tuxedo \| European Made | `kct-prom`, `kct-style-fancy`, `NewIN`, `priority`, `prom-2026`, `crystal`, `gold`, `gradient`, `trending` |
| Black & Silver Crystal 3-Piece Tuxedo \| European Made | `kct-prom`, `kct-style-fancy`, `NewIN`, `priority`, `prom-2026`, `crystal`, `silver`, `brocade`, `classic` |

### ✅ Curated New Suits & Blazers

| Product Name | Key Tags Applied |
|---|---|
| Black Pinstripe Shawl Lapel Double-Breasted Suit | `2025-collection`, `double-breasted`, `fall-2025`, `prom`, `prom-2025`, `wedding` |
| Black Strip Shawl Lapel | `2025-collection`, `double-breasted`, `fall-2025`, `prom`, `wedding` |
| Black and Red Floral with Matching Bowtie | `kct-holiday`, `NewIN`, `priority`, `includes-bowtie`, `floral`, `sequin`, `sparkle` |
| Black Ultra Stretch Dress Shirt | `2025-collection`, `NewIN`, `priority`, `dress-shirt` |

### ✅ Curated Shoes

| Product Name | Key Tags Applied |
|---|---|
| 11 Color Velvet Prom Loafers | `kct-prom`, `kct-type-shoe`, `loafer`, `Velvet`, `plaid` |
| Black Patent Leather & Velvet Loafers | `kct-prom`, `kct-type-shoe`, `loafer`, `textured`, `Velvet` |
| Black & Gold Rhinestone Prom Loafers | `kct-prom`, `kct-type-shoe`, `rhinestone`, `Gold`, `velvet` |
| Black on Black Prom Spikes | `kct-holiday`, `kct-prom`, `kct-type-shoe`, `studded` |
| Black Paisley Velvet Loafers | `kct-prom`, `kct-type-shoe`, `Paisley`, `Velvet` |

### ✅ Curated Dress Shirts

| Product Name | Key Tags Applied |
|---|---|
| Aqua Satin Dress Shirt | `kct-prom`, `kct-type-shirt`, `Satin`, `shinnyshirt` |
| Black Collarless Dress Shirt | `2025-collection`, `dress-shirt`, `formal` |
| Black Short Sleeve Moc Neck | `2025-collection`, `dress-shirt`, `formal` |

---

## 5. Top Tag Distribution (All Active Products)

| Tag | Product Count | Notes |
|---|---|---|
| `patterned` | 242 | Most common style attribute |
| `slim-fit` | 224 | Dominant fit type |
| `formal` | 213 | Core category marker |
| `Prom` | 208 | Primary occasion |
| `shiny` | 207 | Sparkle/satin items |
| `New Arrival` | 170 | Newness signal |
| `quinceanera` | 166 | Key demographic |
| `Wedding Suit` | 159 | Wedding occasion |
| `solid` | 151 | Solid color items |
| `Mens prom blazers` | 145 | SEO keyword tag |
| `Black` | 144 | Top color |
| `homecoming` | 139 | Key occasion |
| `Blazer` | 138 | Product type |
| `kct-prom` | 102 | Official prom collection |
| `2025-collection` | 97 | Current season |
| `Blue` | 81 | Second most popular color |

---

## 6. What Still Needs Curation

| Gap | Count | Action Needed |
|---|---|---|
| **Untagged products** | 140 | Need initial tag assignment via Admin tool |
| **Missing `kct-type-*` tags** | ~500+ | Many products have occasion tags but no structured type tag |
| **Missing `kct-style-*` tags** | ~600+ | Style classification incomplete |
| **Tagging history empty** | 0 logged | The learning tracker table exists but has no logged entries yet (500 needed for AI auto-tagging) |

---

## 7. Product Data Flow

```
Shopify (Source of Truth)
    │
    ├──► Admin Product Manager (/admin/product-review)
    │        • Tags, categorizes, uploads images
    │        • Writes back to Shopify via Admin API
    │
    ├──► Supabase products table (Synced Copy)
    │        • 807 active, 554 draft
    │        • Used for: sitemaps, Google Merchant Feed, SEO
    │        • Tags synced from Shopify
    │
    ├──► Storefront API (GraphQL)
    │        • Used for: live product pages, pricing, checkout
    │        • Shopify is authoritative for prices
    │
    └──► Google Merchant Feed (google-products.xml)
             • 187 in-stock products → 1,776 variants
             • Built from Supabase data
             • Links back to Shopify-backed storefront
```

---

## 8. Use Cases for Claude Coworker

### Content & Media Creation
- Use the **tag data** to identify which products belong to which collection for photoshoots
- `kct-style-fancy` products = sparkle/velvet/crystal → high-impact visual content
- `NewIN` + `priority` = products that need immediate media attention
- `prom-2026` = upcoming season products needing fresh content

### Social Media Scheduling
- Products tagged `kct-holiday` = holiday campaign content
- Products tagged `kct-prom` = prom season campaigns
- Products tagged `trending` or `Statement Tuxedo` = viral potential content

### Inventory-Aware Content
- Only 187 of 807 products are in-stock — focus media on what's actually sellable
- Products with high variant counts (tuxedos: 15+ sizes) = broadly available, safe to promote
- Dress shirts with 1 size each = limited, be cautious promoting heavily

### Google Ads Alignment
- Top campaign: **PMax: KCT Menswear (Maps Campaign)** — $744.69 spend, 749 clicks
- **Prom Campaign** — $276.65, highest CTR at 1.96%
- **Wedding Suits** — $267.31, 612 clicks
- Align product media with active ad campaigns for consistency

---

## 9. Important Rules

1. **Shopify is the source of truth** for pricing and checkout — never quote prices from Supabase
2. **Tags use exact array matching** — `'kct-prom' = ANY(tags)`, not fuzzy search
3. **Archived products** (`status: draft`) are hidden from storefront and feeds
4. **The Admin tool writes directly to Shopify** — changes are live immediately after save
5. **140 untagged products** still need curation — coordinate with admin before featuring
