
# Authentication & Authorization Documentation

## Overview

This document covers the authentication and authorization system for the Groomsmen Management System, including user roles, permissions, and security implementation.

---

## Authentication Methods

### JWT Token Authentication
Primary authentication method using JSON Web Tokens.

```javascript
// Token Structure
{
  "iss": "groomsmen-app",
  "sub": "user_uuid",
  "iat": 1642694400,
  "exp": 1642698000,
  "role": "groomsman",
  "wedding_id": "wedding_uuid",
  "permissions": ["read:measurements", "write:own_measurements"]
}
```

### Session-based Authentication (Alternative)
For web applications requiring server-side session management.

---

## User Roles & Permissions

### System Administrator
**Role:** `admin`
**Permissions:**
- Full system access
- Manage all weddings and users
- Access analytics and reports
- System configuration

### Wedding Coordinator
**Role:** `coordinator`
**Permissions:**
- Manage assigned weddings
- Create/edit/delete groomsmen
- Access wedding analytics
- Verify measurements
- Process refunds
- Send notifications

### Groomsman
**Role:** `groomsman`
**Permissions:**
- Access own wedding party
- Claim identity
- Manage own measurements
- Process own payments
- Participate in group chat
- Use AI assistant

---

## Permission System

### Permission Format
Permissions follow the pattern: `action:resource[:scope]`

Examples:
- `read:groomsmen:own` - Read own groomsman data
- `write:measurements:wedding` - Write measurements for wedding party
- `delete:payments:all` - Delete any payment record

### Core Permissions

#### Groomsman Permissions
```json
[
  "read:wedding:own",
  "read:groomsmen:wedding",
  "write:groomsmen:own",
  "read:measurements:own",
  "write:measurements:own",
  "read:payments:own",
  "write:payments:own",
  "read:chat:wedding",
  "write:chat:wedding",
  "read:ai:own",
  "write:ai:own"
]
```

#### Coordinator Permissions
```json
[
  "read:wedding:assigned",
  "write:wedding:assigned",
  "read:groomsmen:wedding",
  "write:groomsmen:wedding",
  "delete:groomsmen:wedding",
  "read:measurements:wedding",
  "write:measurements:wedding",
  "verify:measurements:wedding",
  "read:payments:wedding",
  "refund:payments:wedding",
  "read:chat:wedding",
  "write:chat:wedding",
  "send:notifications:wedding",
  "read:analytics:wedding"
]
```

---

## Authentication Flow

### Registration Flow
1. User provides email, password, and basic info
2. Server validates input and checks for existing accounts
3. Password is hashed using bcrypt (cost factor 12)
4. User record is created with `groomsman` role by default
5. Verification email is sent (optional)
6. JWT tokens are generated and returned

### Login Flow
1. User provides email and password
2. Server validates credentials
3. If valid, JWT access and refresh tokens are generated
4. User permissions are loaded based on role and wedding assignments
5. Tokens and user data are returned

### Token Refresh Flow
1. Client sends refresh token when access token expires
2. Server validates refresh token
3. If valid, new access token is generated
4. New access and refresh tokens are returned

---

## Security Implementation

### Password Requirements
- Minimum 8 characters
- At least one uppercase letter
- At least one lowercase letter
- At least one number
- At least one special character
- Not in common password blacklist

### Password Security
```javascript
const bcrypt = require('bcrypt');
const saltRounds = 12;

// Hash password
const hashPassword = async (password) => {
  return await bcrypt.hash(password, saltRounds);
};

// Verify password
const verifyPassword = async (password, hash) => {
  return await bcrypt.compare(password, hash);
};
```

### JWT Security
```javascript
const jwt = require('jsonwebtoken');

// Generate tokens
const generateTokens = (user) => {
  const payload = {
    sub: user.id,
    role: user.role,
    wedding_id: user.wedding_id,
    permissions: getUserPermissions(user)
  };

  const accessToken = jwt.sign(payload, ACCESS_SECRET, { 
    expiresIn: '15m',
    issuer: 'groomsmen-app'
  });

  const refreshToken = jwt.sign({ sub: user.id }, REFRESH_SECRET, { 
    expiresIn: '7d',
    issuer: 'groomsmen-app'
  });

  return { accessToken, refreshToken };
};
```

---

## Authorization Middleware

### Express.js Middleware
```javascript
const authorize = (requiredPermissions = []) => {
  return async (req, res, next) => {
    try {
      const token = req.headers.authorization?.split(' ')[1];
      if (!token) {
        return res.status(401).json({ error: 'No token provided' });
      }

      const decoded = jwt.verify(token, ACCESS_SECRET);
      const user = await getUserById(decoded.sub);
      
      if (!user) {
        return res.status(401).json({ error: 'Invalid token' });
      }

      // Check permissions
      const hasPermission = requiredPermissions.every(permission => 
        user.permissions.includes(permission)
      );

      if (!hasPermission) {
        return res.status(403).json({ error: 'Insufficient permissions' });
      }

      req.user = user;
      req.permissions = user.permissions;
      next();
    } catch (error) {
      return res.status(401).json({ error: 'Invalid token' });
    }
  };
};

// Usage
app.get('/api/groomsmen/:id', 
  authorize(['read:groomsmen:own']), 
  getGroomsman
);
```

---

## Row Level Security (RLS)

### PostgreSQL RLS Policies
```sql
-- Users can only access their own wedding party
CREATE POLICY "Wedding party access" ON groomsmen FOR ALL USING (
  EXISTS (
    SELECT 1 FROM weddings w 
    JOIN groomsmen g ON w.id = g.wedding_id
    WHERE w.id = wedding_id 
    AND (
      w.coordinator_id = auth.uid() OR 
      g.user_id = auth.uid()
    )
  )
);

-- Measurements are restricted to groomsman and coordinators
CREATE POLICY "Measurement access" ON measurements FOR ALL USING (
  EXISTS (
    SELECT 1 FROM groomsmen g
    JOIN weddings w ON g.wedding_id = w.id
    WHERE g.id = groomsman_id
    AND (
      g.user_id = auth.uid() OR 
      w.coordinator_id = auth.uid()
    )
  )
);

-- Payments are restricted to the groomsman and coordinators
CREATE POLICY "Payment access" ON payments FOR ALL USING (
  EXISTS (
    SELECT 1 FROM groomsmen g
    JOIN weddings w ON g.wedding_id = w.id
    WHERE g.id = groomsman_id
    AND (
      g.user_id = auth.uid() OR 
      w.coordinator_id = auth.uid()
    )
  )
);
```

---

## API Key Authentication

### For AI Services
```javascript
const API_KEYS = {
  OPENAI: process.env.OPENAI_API_KEY,
  STRIPE: process.env.STRIPE_SECRET_KEY,
  SENDGRID: process.env.SENDGRID_API_KEY
};

// Secure API key usage
const callOpenAI = async (prompt) => {
  const response = await fetch('https://api.openai.com/v1/chat/completions', {
    headers: {
      'Authorization': `Bearer ${API_KEYS.OPENAI}`,
      'Content-Type': 'application/json'
    },
    // ... rest of request
  });
};
```

---

## Multi-factor Authentication (Future)

### TOTP Implementation
```javascript
const speakeasy = require('speakeasy');

// Generate secret for user
const generateMFASecret = (user) => {
  const secret = speakeasy.generateSecret({
    name: `Groomsmen App (${user.email})`,
    issuer: 'Groomsmen Management'
  });
  
  // Store secret.base32 encrypted in database
  return secret;
};

// Verify TOTP token
const verifyMFAToken = (token, secret) => {
  return speakeasy.totp.verify({
    secret: secret,
    encoding: 'base32',
    token: token,
    window: 2 // Allow 2 time steps variance
  });
};
```

---

## Session Management

### Redis Session Store
```javascript
const redis = require('redis');
const session = require('express-session');
const RedisStore = require('connect-redis')(session);

const redisClient = redis.createClient();

app.use(session({
  store: new RedisStore({ client: redisClient }),
  secret: SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: {
    secure: process.env.NODE_ENV === 'production',
    httpOnly: true,
    maxAge: 24 * 60 * 60 * 1000 // 24 hours
  }
}));
```

---

## Security Headers

### Express.js Security
```javascript
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');

// Security headers
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", "'unsafe-inline'", "checkout.stripe.com"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      imgSrc: ["'self'", "data:", "https:"],
      connectSrc: ["'self'", "https://api.stripe.com"]
    }
  }
}));

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // limit each IP to 100 requests per windowMs
  message: 'Too many requests from this IP'
});

app.use('/api/', limiter);

// Stricter limit for auth endpoints
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 5,
  skipSuccessfulRequests: true
});

app.use('/api/auth/', authLimiter);
```

---

## Environment Variables

### Required Environment Variables
```bash
# JWT Secrets (generate with: openssl rand -base64 32)
ACCESS_TOKEN_SECRET=your_access_token_secret_here
REFRESH_TOKEN_SECRET=your_refresh_token_secret_here

# Database
DATABASE_URL=postgresql://user:password@localhost:5432/groomsmen_db

# External APIs
OPENAI_API_KEY=sk-your_openai_key
STRIPE_SECRET_KEY=sk_test_your_stripe_key
STRIPE_WEBHOOK_SECRET=whsec_your_webhook_secret

# Email
SENDGRID_API_KEY=SG.your_sendgrid_key
FROM_EMAIL=noreply@yourapp.com

# Redis (for sessions/caching)
REDIS_URL=redis://localhost:6379

# App Settings
APP_URL=https://yourapp.com
NODE_ENV=production
```

This authentication system provides robust security while maintaining good user experience and clear permission boundaries.
