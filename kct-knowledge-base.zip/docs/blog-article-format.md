# Blog Article Format Guide

This document outlines the editorial format and styling conventions for KCT Menswear blog articles.

## Overview

Blog articles use a sophisticated editorial magazine aesthetic with:
- Serif typography (Playfair Display for headings, Cormorant Garamond for body)
- Clean, spacious layouts with intentional whitespace
- Editorial-style callout sections
- Dark accent sections with white text
- Structured content blocks

## Content Structure

### 1. Article Introduction
```html
<div class="article-intro">
  <p class="text-2xl leading-relaxed mb-12">
    Opening paragraph with larger text to draw readers in.
    Sets the tone and establishes the article's value proposition.
  </p>
</div>
```

### 2. Section Headers
```html
<h2 class="text-center mb-16">Main Section Title</h2>
```

### 3. Content Sections with Border Dividers
```html
<div class="border-t border-slate-200 pt-12 mb-20">
  <div class="max-w-3xl mx-auto">
    <!-- Content here -->
  </div>
</div>
```

### 4. Editorial Callout Boxes
```html
<div class="bg-stone-50 p-8 border-l-2 border-slate-900">
  <h3 class="text-xl mb-4">Callout Title</h3>
  <p class="font-editorial text-slate-700">Callout content with additional context or tips.</p>
</div>
```

### 5. Dark Section with White Text (The KCT Standard)
```html
<div class="p-8 bg-slate-900 text-white">
  <h3 class="text-2xl mb-6 font-serif">The KCT Standard</h3>
  <p class="font-editorial text-lg leading-relaxed mb-6">
    Main content paragraph with important brand messaging.
  </p>
  <p class="font-editorial leading-relaxed opacity-90">
    Secondary content with slightly reduced opacity.
  </p>
</div>
```

**Important**: Dark sections require explicit white text styling in CSS:
```css
.article-content .bg-slate-900 h3,
.article-content .bg-slate-900 p {
  color: #ffffff !important;
}
```

### 6. Numbered Lists/Steps
```html
<div class="border-t border-slate-200 pt-12">
  <div class="flex flex-col md:flex-row gap-8 items-start">
    <div class="md:w-1/3">
      <div class="text-6xl font-serif text-slate-200 mb-4">01</div>
      <h3 class="text-3xl mb-4">Section Title</h3>
      <p class="text-sm uppercase tracking-widest text-slate-500 mb-6">Tags • Keywords</p>
    </div>
    <div class="md:w-2/3 space-y-4">
      <p class="font-editorial text-lg text-slate-700">Content description</p>
      <!-- Additional content -->
    </div>
  </div>
</div>
```

### 7. Grid Layouts for Options/Comparisons
```html
<div class="grid md:grid-cols-3 gap-6 mb-8">
  <div class="text-center p-6 border border-slate-200">
    <div class="text-3xl mb-2">✗</div>
    <p class="text-sm uppercase tracking-wider text-slate-500 mb-2">Wrong Option</p>
    <p class="text-xs font-editorial text-slate-600">Description</p>
  </div>
  <div class="text-center p-6 border-2 border-slate-900 bg-slate-50">
    <div class="text-3xl mb-2">✓</div>
    <p class="text-sm uppercase tracking-wider text-slate-900 mb-2">Correct Option</p>
    <p class="text-xs font-editorial text-slate-700">Description</p>
  </div>
  <div class="text-center p-6 border border-slate-200">
    <div class="text-3xl mb-2">✗</div>
    <p class="text-sm uppercase tracking-wider text-slate-500 mb-2">Wrong Option</p>
    <p class="text-xs font-editorial text-slate-600">Description</p>
  </div>
</div>
```

### 8. Author Attribution
```html
<div class="mt-12 text-center">
  <p class="text-sm uppercase tracking-widest text-slate-500 mb-4">— Author Name, Title</p>
</div>
```

### 9. CTAs and Links
```html
<div class="mt-12 text-center">
  <a href="/" class="inline-block px-10 py-4 bg-slate-900 text-white text-sm uppercase tracking-widest hover:bg-slate-800 transition-colors">
    Button Text
  </a>
</div>
```

Inline links:
```html
<a href="/page" class="underline">Link text</a>
```

## Typography Guidelines

### Font Families
- **Headings**: Playfair Display (serif, elegant)
- **Body**: Cormorant Garamond (serif, editorial)
- **Accents**: Use `.font-editorial` class

### Font Sizes
- H2: `text-2xl` to `text-4xl`
- H3: `text-xl` to `text-3xl`
- Body: `text-lg` (default in article content)
- Small text: `text-sm` or `text-xs`

### Text Colors
- Dark text: `text-slate-900`, `text-slate-700`
- Muted text: `text-slate-600`, `text-slate-500`
- White text (dark sections): `text-white`
- Links: Use underline, inherit color or use brand colors

## Spacing Conventions

- Section spacing: `mb-20` (5rem)
- Paragraph spacing: `mb-6` or `mb-8`
- Header bottom margin: `mb-12` or `mb-16`
- Border top padding: `pt-12`
- Max width for readability: `max-w-3xl mx-auto`

## Required CSS Styles

Add to BlogPostPage.tsx:
```css
.article-content .bg-slate-900 h3,
.article-content .bg-slate-900 p {
  color: #ffffff !important;
}
```

This ensures text in dark sections is always white and readable.

## Best Practices

1. **Visual Hierarchy**: Use clear section breaks with borders
2. **Whitespace**: Be generous with spacing between sections
3. **Contrast**: Light backgrounds (stone-50) vs white vs dark (slate-900)
4. **Readability**: Keep body text width constrained (max-w-3xl)
5. **Editorial Feel**: Use italic font-editorial for callouts and emphasis
6. **Brand Voice**: Include "KCT Standard" or brand sections in dark bg-slate-900
7. **Accessibility**: Always ensure sufficient color contrast

## Example Article Structure

```html
<!-- Intro -->
<div class="article-intro">...</div>

<!-- Main sections with borders -->
<h2>Section 1</h2>
<div class="border-t border-slate-200 pt-12 mb-20">
  <div class="max-w-3xl mx-auto">
    <p class="font-editorial text-lg text-slate-700 leading-relaxed mb-8">Content</p>
    
    <!-- Callout -->
    <div class="bg-stone-50 p-8 border-l-2 border-slate-900">
      <h3 class="text-xl mb-4">Key Point</h3>
      <p class="font-editorial text-slate-700">Details</p>
    </div>
  </div>
</div>

<!-- More sections... -->

<!-- Brand section (dark) -->
<div class="p-8 bg-slate-900 text-white">
  <h3 class="text-2xl mb-6 font-serif">The KCT Standard</h3>
  <p class="font-editorial text-lg leading-relaxed">Brand message</p>
</div>

<!-- Author attribution -->
<div class="mt-12 text-center">
  <p class="text-sm uppercase tracking-widest text-slate-500 mb-4">— Author, Title</p>
</div>
```

## Quick Reference: Color Palette

- Background: `bg-white`, `bg-stone-50`, `bg-slate-900`
- Text: `text-slate-900`, `text-slate-700`, `text-slate-600`, `text-slate-500`, `text-white`
- Borders: `border-slate-200`, `border-slate-900`
- Accents: `border-l-2 border-slate-900` for callouts
