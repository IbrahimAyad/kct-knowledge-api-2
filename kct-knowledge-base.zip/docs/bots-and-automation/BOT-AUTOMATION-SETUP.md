# Bot Automation Browser Access Setup

## Overview
This guide explains how to configure your automation bots to access the website while bypassing bot detection.

## Changes Made
✅ Updated bot detection to support whitelisting
✅ Added trusted bot patterns
✅ Implemented bypass token system
✅ Centralized bot detection logic

## Configuration Options

### Option 1: Use Trusted User-Agent Patterns (Recommended)
Configure your bot to use one of these user-agent strings:

```javascript
// For your custom automation
User-Agent: Mozilla/5.0 (compatible; KCT-Automation/1.0)

// For the enhanced size bot
User-Agent: Mozilla/5.0 (compatible; KCT-Size-Bot/1.0)

// For Telegram sales director bot
User-Agent: Mozilla/5.0 (compatible; KCT-Sales-Director/1.0)
```

### Option 2: Use Bypass Token
1. Generate a secure token:
```bash
# Generate a random token
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

2. Add to your `.env` file:
```env
VITE_BOT_BYPASS_TOKEN="your-generated-token-here"
```

3. Include token in your bot's user-agent:
```javascript
User-Agent: Mozilla/5.0 (KCT-BOT-TOKEN:your-generated-token-here)
```

## Implementation Examples

### Playwright Example
```javascript
import { chromium } from 'playwright';

const browser = await chromium.launch();
const context = await browser.newContext({
  userAgent: 'Mozilla/5.0 (compatible; KCT-Automation/1.0)'
});

const page = await context.newPage();
await page.goto('https://kctmenswear.com');
```

### Puppeteer Example
```javascript
import puppeteer from 'puppeteer';

const browser = await puppeteer.launch();
const page = await browser.newPage();

await page.setUserAgent('Mozilla/5.0 (compatible; KCT-Automation/1.0)');
await page.goto('https://kctmenswear.com');
```

### Axios/Fetch Example
```javascript
import axios from 'axios';

const response = await axios.get('https://kctmenswear.com', {
  headers: {
    'User-Agent': 'Mozilla/5.0 (compatible; KCT-Automation/1.0)'
  }
});
```

### Node.js HTTP Request
```javascript
import https from 'https';

const options = {
  hostname: 'kctmenswear.com',
  port: 443,
  path: '/',
  method: 'GET',
  headers: {
    'User-Agent': 'Mozilla/5.0 (compatible; KCT-Automation/1.0)'
  }
};

const req = https.request(options, (res) => {
  // Handle response
});
```

## Security Considerations

### 1. Keep Bypass Token Secret
- Never commit bypass token to version control
- Store in environment variables only
- Rotate token regularly
- Use different tokens for dev/staging/production

### 2. User-Agent Validation
The system validates user-agents in this order:
1. Check if user-agent matches trusted patterns
2. Check if user-agent contains valid bypass token
3. If neither, apply standard bot detection

### 3. Rate Limiting
Even trusted bots should:
- Implement rate limiting (max 10 requests/second)
- Add delays between requests
- Respect robots.txt
- Use proper caching

## Testing Your Setup

### 1. Test with curl
```bash
# Should NOT be blocked
curl -H "User-Agent: Mozilla/5.0 (compatible; KCT-Automation/1.0)" \
  https://kctmenswear.com

# Should be blocked
curl -H "User-Agent: Mozilla/5.0 (compatible; Googlebot/2.1)" \
  https://kctmenswear.com
```

### 2. Test with Node.js Script
```javascript
// test-bot-access.js
import fetch from 'node-fetch';

async function testBotAccess() {
  console.log('Testing trusted bot access...');

  const response = await fetch('https://kctmenswear.com', {
    headers: {
      'User-Agent': 'Mozilla/5.0 (compatible; KCT-Automation/1.0)'
    }
  });

  console.log('Status:', response.status);
  console.log('Access:', response.status === 200 ? 'GRANTED ✅' : 'BLOCKED ❌');
}

testBotAccess();
```

### 3. Check Browser Console
When accessing the site normally, open DevTools and run:
```javascript
// Check if bot detection is working
import { isBotUserAgent, isTrustedBot } from '@/utils/botDetection';

console.log('Is bot?', isBotUserAgent(navigator.userAgent));
console.log('Is trusted?', isTrustedBot(navigator.userAgent));
```

## Common Issues

### Issue 1: Bot Still Blocked
**Solution**: Check user-agent string exactly matches one of the trusted patterns

### Issue 2: Bypass Token Not Working
**Solution**:
1. Verify token is set in `.env` file
2. Restart dev server after adding token
3. Check token is included in user-agent exactly as shown

### Issue 3: TypeScript Import Errors
**Solution**: The functions are exported from `src/utils/botDetection.ts`

## Adding New Trusted Bots

Edit `src/utils/botDetection.ts`:

```typescript
export const TRUSTED_BOT_PATTERNS = [
  /kct-automation/i,
  /kct-size-bot/i,
  /kct-sales-director/i,
  /your-new-bot-name/i,  // Add your pattern here
];
```

## Monitoring

Check Supabase analytics to monitor bot traffic:

```sql
-- View bot access logs
SELECT
  event_type,
  session_id,
  event_data->>'user_agent' as user_agent,
  created_at
FROM analytics_events
WHERE event_data->>'user_agent' LIKE '%KCT-%'
ORDER BY created_at DESC
LIMIT 100;
```

## Production Deployment

Before deploying to production:

1. ✅ Set `VITE_BOT_BYPASS_TOKEN` in production environment
2. ✅ Test automation with production token
3. ✅ Configure rate limiting
4. ✅ Set up monitoring alerts
5. ✅ Document which bots are whitelisted

## Support

If you encounter issues:
1. Check user-agent string format
2. Verify environment variables are loaded
3. Test with curl first to isolate issues
4. Check browser console for errors

---

**Last Updated**: 2026-01-28
**Status**: ✅ Ready for Use
