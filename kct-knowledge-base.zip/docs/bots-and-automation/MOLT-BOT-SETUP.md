# 🦞 Molt Bot Browser Access Configuration

## Overview
Molt Bot (formerly Clawdbot) is now configured to access your KCT Menswear website without being blocked by bot detection.

## What is Molt Bot?
Molt Bot is an AI automation assistant that can control your Chrome browser via the Chrome DevTools Protocol (CDP). It uses a Chrome extension to control tabs you explicitly attach.

**Key Components:**
- Chrome MV3 extension (ships with Molt Bot)
- Local CDP relay server (http://127.0.0.1:18792)
- Chrome debugger API (`chrome.debugger`)

## Configuration Applied

### ✅ Whitelisted Patterns
Your website now trusts these user-agent patterns:
```javascript
/molt.*bot/i     // Matches "MoltBot", "Molt Bot", etc.
/moltbot/i       // Direct match for "moltbot"
/clawdbot/i      // Former name (Clawdbot)
```

### ✅ Chrome DevTools Detection
The system recognizes when Chrome is being controlled via debugger API and allows Molt Bot through.

## How Molt Bot Works with Your Site

### 1. Normal Chrome Session
When Molt Bot controls a Chrome tab:
- Uses your regular Chrome browser
- Same user-agent as normal browsing
- Has `navigator.webdriver = true` (automation flag)
- Our code detects this and allows it

### 2. Extension-Based Control
```
Molt Bot Agent
    ↓
Chrome Extension (MV3)
    ↓
chrome.debugger API
    ↓
Your Website Tab
```

### 3. CDP Relay Server
```
Local relay: http://127.0.0.1:18792
    ↓
Pipes CDP messages
    ↓
Browser Tab
```

## Installation & Usage

### 1. Install Molt Bot
```bash
# Via npm (recommended)
npm install -g @moltbot/moltbot

# Via source
git clone https://github.com/moltbot/moltbot
cd moltbot
npm install
npm run build
```

### 2. Install Chrome Extension
The extension ships inside the Molt Bot package (no separate build needed).

**Load in Chrome:**
1. Open Chrome → `chrome://extensions`
2. Enable "Developer mode"
3. Click "Load unpacked"
4. Select the extension folder from Molt Bot package

### 3. Attach to Website Tab
1. Open your KCT Menswear website in Chrome
2. Click the Molt Bot toolbar button
3. Tab is now controlled by Molt Bot
4. Bot detection automatically allows access ✅

## Custom User-Agent (Optional)

If you want to explicitly identify Molt Bot traffic, you can set a custom user-agent:

### Option 1: Modify Molt Bot User-Agent
```javascript
// In your Molt Bot configuration
{
  browser: {
    userAgent: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36 MoltBot/1.0'
  }
}
```

### Option 2: Use Bypass Token
```javascript
// Add bypass token to user-agent
{
  browser: {
    userAgent: 'Mozilla/5.0 (KCT-BOT-TOKEN:226c818605069db66678a32f175e44ec28be59f79a79a2d559f30e95d9b18d5e) MoltBot/1.0'
  }
}
```

## Testing Molt Bot Access

### Test 1: Check Whitelisting
```javascript
// In Chrome DevTools Console (on your website)
console.log('User Agent:', navigator.userAgent);
console.log('Webdriver?', navigator.webdriver);

// Should show bot is allowed
import { isTrustedBot } from '@/utils/botDetection';
console.log('Trusted?', isTrustedBot(navigator.userAgent));
```

### Test 2: Run Molt Bot Task
```bash
# Example Molt Bot command to test access
molt browse https://kctmenswear.com
```

### Test 3: Automated Test
```bash
# Run our test script
node scripts/test-bot-access.js
```

## Common Molt Bot Use Cases

### 1. Automated Testing
```javascript
// Molt Bot can test your size recommendation tool
await molt.browser.goto('https://kctmenswear.com/size-finder');
await molt.browser.fill('#height', '70');
await molt.browser.fill('#weight', '180');
await molt.browser.click('#calculate');
const result = await molt.browser.text('#result');
```

### 2. Content Monitoring
```javascript
// Monitor product availability
await molt.browser.goto('https://kctmenswear.com/products/tuxedos');
const inStock = await molt.browser.$$('.in-stock');
if (inStock.length < 10) {
  molt.notify('Low stock alert!');
}
```

### 3. Customer Journey Simulation
```javascript
// Simulate customer workflow
await molt.browser.goto('https://kctmenswear.com');
await molt.browser.click('a[href="/wedding-suits"]');
await molt.browser.click('.product-card:first-child');
await molt.browser.click('#add-to-cart');
```

### 4. Analytics Data Collection
```javascript
// Collect performance metrics
await molt.browser.goto('https://kctmenswear.com');
const performance = await molt.browser.evaluate(() => {
  return {
    loadTime: performance.timing.loadEventEnd - performance.timing.navigationStart,
    domReady: performance.timing.domContentLoadedEventEnd - performance.timing.navigationStart
  };
});
```

## Security Considerations

### What's Protected:
✅ Analytics tracking still works
✅ Session tracking enabled for Molt Bot
✅ Only whitelisted automation allowed
✅ Regular bots still blocked

### What's Allowed:
✅ Molt Bot can access all pages
✅ Molt Bot can interact with forms
✅ Molt Bot can trigger events
✅ Molt Bot sessions are tracked (but marked as automation)

### Best Practices:
1. **Rate Limiting**: Molt Bot should respect rate limits
2. **User Context**: Use Molt Bot with proper authentication if testing protected areas
3. **Data Privacy**: Don't use Molt Bot to scrape PII
4. **Resource Usage**: Be mindful of server load

## Troubleshooting

### Issue 1: Molt Bot Still Blocked
**Check:**
```bash
# Verify user-agent includes "molt" or "moltbot"
# Or ensure webdriver flag is set
```

**Solution:**
- Update Molt Bot user-agent to include "MoltBot"
- Or use bypass token method

### Issue 2: Chrome Extension Not Working
**Check:**
- Extension is loaded in `chrome://extensions`
- Extension has necessary permissions
- Clicked toolbar button to attach tab

**Solution:**
- Reload extension
- Check extension console for errors
- Verify CDP relay is running

### Issue 3: Session Tracking Issues
**Check Analytics:**
```sql
-- Check Molt Bot sessions in Supabase
SELECT
  session_id,
  event_data->>'user_agent' as user_agent,
  created_at
FROM analytics_events
WHERE event_data->>'user_agent' LIKE '%molt%'
ORDER BY created_at DESC
LIMIT 10;
```

## Advanced Configuration

### Custom CDP Relay Port
If you change Molt Bot's CDP relay port:
```javascript
// Molt Bot config
{
  cdp: {
    port: 18792  // Default
  }
}
```

### Multiple Molt Bot Instances
Each instance will have its own session:
```javascript
// Bot detection handles multiple concurrent sessions
// No additional configuration needed
```

### Headless Mode
If running Molt Bot headless:
```javascript
{
  browser: {
    headless: true,
    userAgent: 'Mozilla/5.0 MoltBot/1.0 Headless'
  }
}
```

## Monitoring Molt Bot Activity

### Real-time Monitoring
```sql
-- View active Molt Bot sessions
SELECT
  session_id,
  page_url,
  event_type,
  created_at
FROM analytics_events
WHERE
  session_id IN (
    SELECT DISTINCT session_id
    FROM analytics_events
    WHERE event_data->>'user_agent' LIKE '%molt%'
  )
ORDER BY created_at DESC;
```

### Performance Tracking
```sql
-- Molt Bot performance metrics
SELECT
  AVG((event_data->>'duration_ms')::int) as avg_duration,
  COUNT(*) as total_requests,
  page_url
FROM analytics_events
WHERE event_data->>'user_agent' LIKE '%molt%'
GROUP BY page_url
ORDER BY avg_duration DESC;
```

## Documentation Links

**Molt Bot Official Docs:**
- [Getting Started](https://docs.molt.bot/start/getting-started)
- [Browser Tool](https://docs.molt.bot/tools/browser)
- [Chrome Extension](https://docs.molt.bot/tools/chrome-extension)
- [GitHub Repository](https://github.com/moltbot/moltbot)

**Related Resources:**
- [1Password: It's MoltBot](https://1password.com/blog/its-moltbot)
- [DEV Community: MoltBot Guide](https://dev.to/czmilo/moltbot-the-ultimate-personal-ai-assistant-guide-for-2026-d4e)
- [AIMultiple: MoltBot Use Cases](https://research.aimultiple.com/moltbot/)

## Support

If Molt Bot access isn't working:

1. **Check Configuration:**
   - Verify patterns in `src/utils/botDetection.ts`
   - Check `.env` has bypass token
   - Restart dev server

2. **Test Detection:**
   ```bash
   node scripts/test-bot-access.js
   ```

3. **Check Logs:**
   - Chrome DevTools Console
   - Molt Bot logs
   - Supabase analytics_events table

4. **Update Code:**
   - Pull latest changes
   - Verify imports are correct
   - Check TypeScript compilation

---

**Status**: ✅ Molt Bot access enabled
**Last Updated**: 2026-01-28
**Version**: 1.0.0
