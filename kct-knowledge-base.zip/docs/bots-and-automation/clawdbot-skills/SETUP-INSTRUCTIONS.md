# KCT Sales Director - Clawdbot Setup Instructions

This guide walks you through setting up your AI Sales Director on your M1 iMac.

## Prerequisites

- M1 iMac with 16GB RAM (you have this)
- Claude Max subscription (you have this)
- Telegram account (for messaging the bot)
- Shopify store admin access
- Google Ads account access
- Google Analytics access

---

## Step 1: Prepare Your iMac

### Keep it running 24/7
1. Open **System Settings** → **Energy**
2. Turn OFF "Put hard disks to sleep when possible"
3. Turn OFF "Prevent automatic sleeping when the display is off" → make sure it stays ON
4. Set display to turn off after 5 minutes (saves energy, bot keeps running)

### Connect to reliable internet
- Use wired ethernet if possible (more stable than WiFi)
- If WiFi, make sure it auto-reconnects

---

## Step 2: Install Clawdbot

Open Terminal and run:

```bash
# Install Clawdbot
curl -fsSL https://clawd.bot/install.sh | bash

# Run the onboarding wizard
clawdbot onboard --install-daemon
```

The onboarding wizard will ask you to:
1. Choose your AI provider → Select **Anthropic (Claude)**
2. Enter API credentials → Use your Claude Max login
3. Choose a messaging channel → Select **Telegram** (easiest to start)
4. Set your timezone → **America/Detroit** (Eastern)

---

## Step 3: Connect Telegram

1. Open Telegram on your phone
2. Search for **@BotFather**
3. Send `/newbot`
4. Name it "KCT Sales Director"
5. BotFather gives you a token - copy it
6. In Terminal, run:
   ```bash
   clawdbot configure --section telegram
   ```
7. Paste your bot token when prompted
8. Send a message to your new bot in Telegram
9. Clawdbot will pair with your account

---

## Step 4: Install the KCT Skills

Copy the skill files to Clawdbot's workspace:

```bash
# Find your Clawdbot workspace
clawdbot config get workspace.path

# It's usually ~/.clawdbot/workspace
# Copy the skill files there:
cp /Users/ibrahim/Desktop/KCT-Menswear/ACTIVE/kct-viral-looks-shop/docs/clawdbot-skills/*.md ~/.clawdbot/workspace/skills/
```

Or tell Clawdbot to read them:
1. Message your bot on Telegram
2. Say: "Read and memorize the files in /Users/ibrahim/Desktop/KCT-Menswear/ACTIVE/kct-viral-looks-shop/docs/clawdbot-skills/"
3. Clawdbot will ingest the Sales Director personality and knowledge

---

## Step 5: Connect Data Sources

**IMPORTANT:** See `kct-integrations.md` for complete connection details.

### Your Systems At a Glance
```
Supabase URL:     https://gvcswimqaxvylgxbklbz.supabase.co
Shopify Store:    kctmenswear.myshopify.com
Website:          kctmenswear.com
Shopify API:      2024-10
```

### Supabase (Primary Database)
Your Supabase is already set up. Get the Service Role Key:
1. Go to https://supabase.com/dashboard
2. Select your project (gvcswimqaxvylgxbklbz)
3. Settings → API → Copy "service_role" key (secret!)
4. Message your bot: `"Configure Supabase with service key: [your key]"`

### Shopify
Message your bot:
```
"Set up Shopify integration for kctmenswear.myshopify.com"
```

You need TWO tokens from Shopify:
1. **Storefront Access Token** (for reading products)
2. **Admin API Access Token** (for reading orders/customers)

Get them:
1. Shopify Admin → Settings → Apps → Develop Apps
2. Create an app called "Clawdbot Sales Director"
3. Configure API scopes:
   - Storefront: `unauthenticated_read_product_listings`
   - Admin: `read_orders`, `read_customers`, `read_products`
4. Copy both tokens and give to Clawdbot

### Products Catalog API (Already Working)
Your products are accessible at:
```
https://gvcswimqaxvylgxbklbz.supabase.co/functions/v1/products-catalog
```

Test it now - this should return your product catalog.

### Google Analytics
Message your bot:
```
"Set up Google Analytics integration for kctmenswear.com"
```

You'll need to:
1. Create a service account in Google Cloud Console
2. Give it access to your Analytics property
3. Download the JSON credentials
4. Tell Clawdbot where to find them

### Google Ads
Message your bot:
```
"Set up Google Ads integration"
```

You'll need:
1. Google Ads API access (may need to apply)
2. Developer token
3. OAuth credentials

**Note**: Google Ads API setup is more complex. Alternatively, Clawdbot can use browser automation to check your ads dashboard.

---

## Step 6: Set Up Scheduled Tasks

Message your bot:
```
"Set up the daily sales briefing for 8am Eastern every day"
```

Then:
```
"Set up the 5pm accountability check-in"
```

And:
```
"Set up the Sunday weekly review at 7pm"
```

Clawdbot will create cron jobs for each.

Verify with:
```bash
clawdbot jobs list
```

---

## Step 7: Configure Competitor Monitoring

Message your bot:
```
"Set up competitor monitoring for:
- menswearhouse.com (wedding packages)
- josbank.com (suit prices)
- indochino.com (custom suit pricing)
- theblacktux.com (rental prices)

Check every Monday and Thursday at 10am.
Alert me only if prices or promotions change."
```

Clawdbot will set up browser automation to check these sites.

---

## Step 8: Test Everything

### Test the briefing
Message your bot:
```
"Give me today's sales briefing"
```

You should get a full briefing with:
- Revenue numbers
- What's selling
- Abandoned carts
- Action items
- Ad recommendations

### Test accountability
Message your bot:
```
"What were my action items from the last briefing?"
```

### Test competitor check
Message your bot:
```
"Check competitor prices right now"
```

---

## Step 9: Set Your Goals

Message your bot:
```
"My sales goals are:
- Weekly revenue goal: $6,000
- Monthly revenue goal: $25,000
- Target conversion rate: 2.5%
- Target ROAS: 3.0x
- Target AOV: $350"
```

The bot will remember these and grade you against them.

---

## Step 10: Daily Usage

### Morning (after 8am)
- Check Telegram for your briefing
- Review the 3 action items
- Start working on them

### During the day
- Message the bot questions anytime:
  - "What's my ROAS this week?"
  - "Any abandoned carts to follow up?"
  - "Should I increase ad spend?"
  - "Draft an email for [customer]"

### Evening (after 5pm)
- Bot checks in on your tasks
- Reply with what you did/didn't do
- Bot notes for tomorrow

### Sunday evening
- Review weekly report
- Plan next week's priorities

---

## Troubleshooting

### Bot not responding
```bash
clawdbot status
clawdbot logs --follow
```

### Scheduled tasks not running
```bash
clawdbot jobs list
clawdbot jobs run daily-briefing  # manual trigger
```

### Data not pulling
- Check API credentials
- Verify Shopify/Google permissions
- Ask bot: "Test Shopify connection"

### Bot forgot something
- Tell it to re-read the skill files
- Check the MEMORY.md file in workspace

---

## Important Files

| File | Purpose |
|------|---------|
| `kct-sales-director.md` | Sales Director personality, knowledge, and rules |
| `kct-scheduled-tasks.md` | Sales Director automated tasks |
| `kct-market-intelligence.md` | Market Intel Agent personality and research areas |
| `kct-market-intel-tasks.md` | Market Intel scheduled scans and reports |
| `kct-business-config.md` | Shared business data (goals, pricing, competitors) |
| `kct-integrations.md` | **API keys, database connections, and system access** |
| `~/.clawdbot/workspace/MEMORY.md` | Bot's long-term memory |
| `~/.clawdbot/workspace/memory/YYYY-MM-DD.md` | Daily notes |

---

## Multi-Agent Setup

You'll run TWO agents on one Clawdbot installation:

### Agent 1: Sales Director
- **Purpose:** Daily operations, accountability, immediate actions
- **Channel:** Telegram (Chat 1)
- **Schedule:** Daily 8am briefing, 5pm check-in

### Agent 2: Market Intelligence
- **Purpose:** Research, trends, competitor analysis, strategic insights
- **Channel:** Telegram (Chat 2 - separate conversation)
- **Schedule:** Weekly Monday brief, bi-weekly deep dives

### How to Set Up Both Agents

```bash
# Create Sales Director agent
clawdbot agent create sales-director
clawdbot agent configure sales-director --skills ~/kct-skills/kct-sales-director.md

# Create Market Intelligence agent
clawdbot agent create market-intel
clawdbot agent configure market-intel --skills ~/kct-skills/kct-market-intelligence.md

# List your agents
clawdbot agent list

# Each agent gets its own Telegram chat
# Start a new conversation with your bot for each agent
```

### How They Work Together

```
6:00 AM - Market Intel gathers research data
7:00 AM - Market Intel sends Weekly Brief (Mondays)
8:00 AM - Sales Director sends Daily Brief (every day)
          (informed by Market Intel findings)
5:00 PM - Sales Director accountability check-in
```

Market Intel finds opportunity → flags for Sales Director → Sales Director assigns as task

---

## Getting Help

- Clawdbot docs: https://docs.clawd.bot
- Clawdbot Discord: Community support
- Message me (Claude Code) anytime to adjust the skills

---

## What Happens Next

Once set up, your AI Sales Director will:

1. **Every morning at 8am**: Send you a sales briefing with exactly what to do
2. **Every day at 5pm**: Check if you did the tasks
3. **Continuously**: Monitor for abandoned carts, competitor changes, ad performance
4. **Every Sunday**: Give you a weekly grade and set next week's priorities
5. **Anytime you ask**: Answer questions, draft emails, make recommendations

You just have to DO what it tells you.

The bot knows menswear retail. It knows your business. It will tell you exactly what to do to increase sales. Your job is to execute.

Let's go make money.
