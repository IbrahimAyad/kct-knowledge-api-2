# KCT Business Configuration

This file contains KCT-specific data that the Sales Director uses. Update these values as your business changes.

## Business Goals

```yaml
revenue:
  daily_goal: 1200
  weekly_goal: 6000
  monthly_goal: 25000

metrics:
  target_conversion_rate: 2.5
  target_aov: 350
  target_roas: 3.0

current_actuals:
  conversion_rate: 1.4  # Update weekly
  aov: 382  # Update weekly
  roas: 3.2  # Update weekly
```

## Product Catalog

### Complete Packages ($229)
| Product | SKU | Margin | Priority |
|---------|-----|--------|----------|
| Navy 2-Piece Complete | NAV-2P-229 | High | Primary |
| Charcoal 2-Piece Complete | CHR-2P-229 | High | Primary |
| Black 2-Piece Complete | BLK-2P-229 | High | Primary |
| Light Grey 2-Piece Complete | LGR-2P-229 | High | Secondary |
| Tan 2-Piece Complete | TAN-2P-229 | High | Secondary |

### 3-Piece Packages ($279)
| Product | SKU | Margin | Priority |
|---------|-----|--------|----------|
| Navy 3-Piece | NAV-3P-279 | Higher | Upsell |
| Charcoal 3-Piece | CHR-3P-279 | Higher | Upsell |

### Add-ons
| Product | Price | Attach Rate Target |
|---------|-------|-------------------|
| Extra Tie | $25 | 40% |
| Pocket Square | $15 | 30% |
| Dress Shoes | $89 | 20% |
| Belt | $35 | 25% |

## Pricing Reference

### KCT Pricing
- Complete 2-Piece Package: $229
- Complete 3-Piece Package: $279
- Suit Only: $179
- Shirt Only: $39
- Tie/Bow Tie: $25
- Alterations: Included (basic)

### Competitor Pricing (Update monthly)
```yaml
mens_wearhouse:
  wedding_rental: 189-249
  groom_free_threshold: 5
  current_promo: "None"
  last_checked: 2026-01-25

jos_a_bank:
  suit_purchase: 300-500
  current_sale: "Buy 1 Get 2 Free"
  last_checked: 2026-01-25

indochino:
  custom_suit: 399-599
  current_promo: "None"
  last_checked: 2026-01-25

the_black_tux:
  rental: 189
  current_promo: "None"
  last_checked: 2026-01-25

generation_tux:
  rental: 159-199
  current_promo: "None"
  last_checked: 2026-01-25

perfecttux:
  model: purchase  # Same as KCT - not rental
  suit_range: 149-499
  wedding_deal: "Groom 50% off with 5+ party"
  free_shipping: 150
  location: "Santa Clarita, CA + online"
  kct_advantage: "Local Michigan presence, in-store fitting"
  last_checked: 2026-01-28
```

## Customer Segments

### Wedding Parties (70% of revenue)
- **Value**: $800-2000 per party (4-8 suits)
- **Lead time**: 2-4 months before wedding
- **Decision maker**: Usually the bride or groom
- **Key concerns**: Coordination, pricing, fitting logistics
- **Conversion trigger**: In-store appointment

### Prom (20% of revenue)
- **Value**: $150-300 per customer
- **Lead time**: 1-2 months before prom
- **Decision maker**: Parent pays, student chooses
- **Key concerns**: Price, style, fitting on teen body
- **Peak months**: March-May

### Professional (10% of revenue)
- **Value**: $200-400 per customer
- **Lead time**: 1-2 weeks (often urgent)
- **Decision maker**: The customer
- **Key concerns**: Quality, fit, speed
- **Triggers**: Job interview, promotion, event

## Marketing Channels

### Google Ads
```yaml
current_daily_budget: 50
target_daily_budget: 80
current_roas: 3.2
campaigns:
  - name: "Wedding Suits - Search"
    status: active
    priority: high
  - name: "Prom Suits - Search"
    status: paused_until_march
    priority: seasonal
  - name: "Shopping - All Products"
    status: active
    priority: medium
```

### Keywords Performance (Update monthly)
```yaml
high_performers:
  - "wedding suits for groom" # ROAS 4.2x
  - "groomsmen suit packages" # ROAS 3.8x
  - "buy wedding suit michigan" # ROAS 3.5x

low_performers:
  - "cheap suits" # ROAS 1.2x - PAUSE
  - "men's suits" # ROAS 1.8x - Too broad
```

## Inventory Alerts

Set alerts when these sizes run low:
- 40R (most common)
- 42R
- 38R
- Navy (most popular color)
- Charcoal (second most popular)

## Key Dates

### 2026 Calendar
```yaml
engagement_season:
  start: 2026-01-01
  end: 2026-02-28
  action: "Max wedding advertising"

prom_booking:
  start: 2026-02-15
  end: 2026-04-30
  action: "Launch prom campaigns"

spring_wedding_peak:
  start: 2026-04-01
  end: 2026-06-30
  action: "Fulfillment focus"

summer_slow:
  start: 2026-07-01
  end: 2026-08-31
  action: "Reduce spend, clear inventory"

fall_wedding:
  start: 2026-09-01
  end: 2026-11-15
  action: "Second wedding push"

holiday:
  start: 2026-11-15
  end: 2026-12-31
  action: "Gift cards, party suits"
```

## Contact Points

```yaml
shopify_store: kctmenswear.myshopify.com
website: kctmenswear.com
google_ads_account: XXX-XXX-XXXX
google_analytics_property: UA-XXXXXXXX or G-XXXXXXXX

social:
  instagram: @kctmenswear
  facebook: KCT Menswear

review_platforms:
  - Google Business Profile
  - Wedding Wire
  - The Knot
  - Yelp
```

## Update Log

| Date | What Changed | Updated By |
|------|--------------|------------|
| 2026-01-25 | Initial config created | Claude |
| | | |
| | | |

---

**Note**: Update this file monthly or when significant changes occur. The Sales Director uses these values for recommendations.
