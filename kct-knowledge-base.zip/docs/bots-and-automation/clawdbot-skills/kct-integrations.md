# KCT System Integrations

This file documents all the actual system connections for the Sales Director and Market Intelligence agents.

---

## 1. Supabase (Primary Database)

### Connection Details
```yaml
url: https://gvcswimqaxvylgxbklbz.supabase.co
project_ref: gvcswimqaxvylgxbklbz
region: US East

# Clawdbot needs these environment variables:
SUPABASE_URL: https://gvcswimqaxvylgxbklbz.supabase.co
SUPABASE_SERVICE_ROLE_KEY: [Get from Supabase Dashboard → Settings → API]
```

### Key Tables for Sales Data

| Table | Purpose | Used By |
|-------|---------|---------|
| `abandoned_carts` | Track abandoned carts with email, value, cart data | Sales Director |
| `cart_recovery_campaigns` | Email recovery campaigns sent | Sales Director |
| `cart_recovery_analytics` | Daily recovery stats | Sales Director |
| `performance_metrics` | Web vitals and site performance | Market Intel |
| `activities` | User activity log | Both agents |
| `content_queue` | Blog posts and content calendar | Market Intel |
| `outfit_leads` | Style quiz leads | Sales Director |
| `wedding_registrations` | Wedding party orders | Sales Director |

### Edge Functions (API Endpoints)

**Sales Director Uses:**
```
https://gvcswimqaxvylgxbklbz.supabase.co/functions/v1/

cart-recovery-automation     → Trigger cart recovery emails
send-cart-recovery-email     → Send recovery email to specific cart
shopify-order-webhook        → Process new orders
products-catalog             → Get full product catalog
shopify-customer-orders      → Get customer order history
performance-analytics        → Site performance data
```

**Market Intel Uses:**
```
https://gvcswimqaxvylgxbklbz.supabase.co/functions/v1/

products-catalog?format=chatbot    → Product catalog for analysis
performance-analytics              → Site performance trends
auto-publish-blogs                 → Blog content automation
```

### How to Query Data

**Get abandoned carts (last 48 hours):**
```sql
SELECT * FROM abandoned_carts
WHERE is_recovered = false
AND abandoned_at > NOW() - INTERVAL '48 hours'
ORDER BY total_amount DESC;
```

**Get today's revenue (from cart recovery data):**
```sql
SELECT
  SUM(total_amount) as recovered_revenue,
  COUNT(*) as recovered_carts
FROM abandoned_carts
WHERE is_recovered = true
AND recovered_at::date = CURRENT_DATE;
```

**Get cart recovery stats:**
```sql
SELECT * FROM cart_recovery_analytics
WHERE date >= CURRENT_DATE - INTERVAL '7 days'
ORDER BY date DESC;
```

---

## 2. Shopify Store

### Connection Details
```yaml
store_domain: kctmenswear.myshopify.com
storefront_domain: kctmenswear.com
api_version: 2024-10

# Environment variables needed:
SHOPIFY_STOREFRONT_TOKEN: [Get from Shopify Admin → Settings → Apps → Develop Apps]
SHOPIFY_ADMIN_API_KEY: [For admin operations]
SHOPIFY_ADMIN_API_SECRET: [For admin operations]
```

### GraphQL API Access

**Storefront API (read products, collections):**
```
Endpoint: https://kctmenswear.myshopify.com/api/2024-10/graphql.json
Header: X-Shopify-Storefront-Access-Token: [STOREFRONT_TOKEN]
```

**Admin API (read orders, customers):**
```
Endpoint: https://kctmenswear.myshopify.com/admin/api/2024-10/graphql.json
Header: X-Shopify-Access-Token: [ADMIN_TOKEN]
```

### Key Data Points for Agents

**Sales Director needs:**
- Daily/weekly revenue
- Order count
- Average order value
- Top selling products
- Abandoned checkout data (native Shopify)
- Customer inquiries

**Market Intel needs:**
- Product catalog (pricing, inventory)
- Category performance
- Product views vs purchases
- Search terms customers use

### Product Categories
```
Product Types in Catalog:
- Suits (complete packages)
- Blazers
- Dress Shirts
- Ties & Bow Ties
- Vests
- Dress Pants
- Shoes
- Accessories (pocket squares, belts, cufflinks)
```

### Recovery Links Format
```
Cart recovery URL:
https://kctmenswear.myshopify.com/cart?recovery={cart_id}&email={email}&template={template_id}
```

---

## 3. Website Structure

### Domain
```yaml
primary: kctmenswear.com
shopify_checkout: kctmenswear.myshopify.com
```

### Key Pages for Monitoring

**High-Value Pages (Sales Director monitors):**
```
/                           → Homepage (conversion entry)
/custom-bundle             → Custom bundle builder (high AOV)
/wedding-services          → Wedding party landing page
/wedding-collections       → Wedding products
/shop-all                  → Full catalog
/checkout                  → Checkout flow
/product/{handle}          → Individual product pages
```

**Content Pages (Market Intel monitors):**
```
/blog                      → Blog listing
/blog/{slug}               → Individual blog posts
/prom                      → Prom landing page
/about                     → About us
/contact                   → Contact page
/locations                 → Store locations
```

### SEO Landing Pages
```
/wedding-style-summer      → Summer wedding suits
/wedding-style-fall        → Fall wedding suits
/wedding-style-classic     → Classic wedding looks
/wedding-style-beach       → Beach/destination weddings
/local-weddings            → Southwest Michigan weddings
```

---

## 4. Google Analytics

### Setup Required
```yaml
# To be configured:
property_id: G-XXXXXXXX (need to get from GA4)
service_account: [Create in Google Cloud Console]

# What to track:
- Daily sessions
- Conversion rate
- Traffic sources
- Top landing pages
- User flow through checkout
```

### Key Metrics to Pull

**Sales Director (daily):**
- Sessions
- Transactions
- Revenue
- Conversion rate
- Bounce rate on key pages

**Market Intel (weekly):**
- Traffic trends
- Search queries (from Search Console)
- Landing page performance
- Device breakdown
- Geographic data

---

## 5. Google Ads

### Setup Required
```yaml
# Account info:
account_id: XXX-XXX-XXXX (need actual ID)
developer_token: [Apply at Google Ads API Center]

# Alternative: Use browser automation to check dashboard
```

### Campaign Structure
```
Active Campaigns:
1. Wedding Suits - Search
   - Keywords: wedding suits, groomsmen suits, groom attire
   - Budget: ~$50/day

2. Shopping - All Products
   - Feed from Shopify
   - Performance Max

3. Prom Suits - Search (seasonal)
   - Keywords: prom suits, prom outfit
   - Activate: Feb 15 - May 15
```

### Metrics to Track
```
Daily:
- Spend
- Impressions
- Clicks
- Conversions
- ROAS

Alerts when:
- ROAS < 2.0 for 3+ days
- ROAS > 4.0 for 3+ days (opportunity)
- Spend significantly under budget
```

---

## 6. Email System (Resend)

### Configuration
```yaml
# Email service:
provider: Resend (via Supabase Edge Functions)
from_email: noreply@kctmenswear.com
reply_to: support@kctmenswear.com

# Templates stored in:
Supabase table: cart_recovery_email_templates
```

### Email Functions Available
```
send-cart-recovery-email     → Abandoned cart emails
send-appointment-email       → In-store appointment confirmations
send-bundle-order-email      → Custom bundle order confirmations
send-wedding-invitation      → Wedding party invites
send-wedding-order-email     → Wedding order confirmations
send-reminder-email          → General reminders
```

### Recovery Email Sequence
```
Email 1: 1 hour after abandon → "Forgot something?"
Email 2: 24 hours → "Still thinking about it?"
Email 3: 48 hours → "Last chance + discount code"

Max: 3 emails per abandoned cart
```

---

## 7. Product Data Access

### Full Catalog API
```bash
# Get all products (JSON format):
curl https://gvcswimqaxvylgxbklbz.supabase.co/functions/v1/products-catalog

# Get chatbot-optimized format:
curl https://gvcswimqaxvylgxbklbz.supabase.co/functions/v1/products-catalog?format=chatbot

# Filter by category:
curl https://gvcswimqaxvylgxbklbz.supabase.co/functions/v1/products-catalog?category=Suits

# In-stock only:
curl https://gvcswimqaxvylgxbklbz.supabase.co/functions/v1/products-catalog?inStockOnly=true
```

### Product Data Structure
```json
{
  "id": "gid://shopify/Product/...",
  "title": "Navy 2-Piece Complete Package",
  "handle": "navy-2-piece-complete",
  "url": "https://kctmenswear.com/product/navy-2-piece-complete",
  "price": 229,
  "compareAtPrice": 399,
  "category": "Suits",
  "tags": ["wedding", "complete-package", "navy"],
  "inStock": true,
  "colors": ["Navy"],
  "sizes": ["38R", "40R", "42R", "44R", "46R", "48R"]
}
```

---

## 8. Competitor Monitoring

### Sites to Monitor (automated)
```yaml
mens_wearhouse:
  url: https://www.menswearhouse.com
  check: Wedding packages, rentals, current promos

jos_a_bank:
  url: https://www.josbank.com
  check: Sale status, suit pricing

indochino:
  url: https://www.indochino.com
  check: Custom suit pricing, promos

the_black_tux:
  url: https://theblacktux.com
  check: Rental pricing, wedding packages

generation_tux:
  url: https://www.generationtux.com
  check: Rental pricing, group deals
```

### Browser Automation Setup
```
Tool: Playwright or Puppeteer via Clawdbot
Schedule: Monday and Thursday at 10am
Alert if: Price changes >10% or new promotions detected
```

---

## 9. Social Media Accounts

### Profiles to Monitor
```yaml
kct_instagram:
  handle: @kctmenswear
  track: Engagement, comments, DMs

kct_facebook:
  page: KCT Menswear
  track: Reviews, messages, engagement
```

### Competitor Social
```yaml
# Track for Market Intel:
@menswearhouse
@josbank
@indochino
@theblacktux
```

---

## 10. Review Platforms

### Where to Check
```yaml
google_business:
  name: "KCT Menswear"
  location: Portage, MI
  track: New reviews, rating changes

wedding_wire:
  profile: kct-menswear
  track: Wedding reviews

the_knot:
  profile: kct-menswear
  track: Wedding reviews

yelp:
  business: kct-menswear-portage
  track: Reviews
```

### Alert Triggers
```
- New 1-2 star review → IMMEDIATE alert
- New 5 star review → Weekly summary
- Rating drops below 4.5 → Alert
```

---

## Setup Checklist for Clawdbot

### Required API Keys/Tokens

| Service | Variable | Where to Get |
|---------|----------|--------------|
| Supabase | `SUPABASE_SERVICE_ROLE_KEY` | Supabase Dashboard → Settings → API |
| Shopify Storefront | `SHOPIFY_STOREFRONT_TOKEN` | Shopify Admin → Settings → Apps → Develop Apps |
| Shopify Admin | `SHOPIFY_ADMIN_ACCESS_TOKEN` | Shopify Admin → Settings → Apps → Develop Apps |
| Google Analytics | `GA4_CREDENTIALS` | Google Cloud Console → Service Account |
| Google Ads | `GOOGLE_ADS_DEVELOPER_TOKEN` | Google Ads API Center (apply) |

### Environment Variables for Clawdbot
```bash
# Add to ~/.clawdbot/.env or configure via:
# clawdbot configure --section integrations

# Supabase
SUPABASE_URL=https://gvcswimqaxvylgxbklbz.supabase.co
SUPABASE_SERVICE_ROLE_KEY=your-service-role-key

# Shopify
SHOPIFY_STORE=kctmenswear.myshopify.com
SHOPIFY_STOREFRONT_TOKEN=your-storefront-token
SHOPIFY_ADMIN_TOKEN=your-admin-token

# Google (when ready)
GA4_PROPERTY_ID=G-XXXXXXXX
GOOGLE_ADS_ACCOUNT=XXX-XXX-XXXX
```

### Test Commands

After setup, test each integration:

```bash
# Test Supabase connection
clawdbot run "Query abandoned_carts table for last 24 hours"

# Test Shopify product fetch
clawdbot run "Get the top 10 products from Shopify by price"

# Test cart recovery trigger
clawdbot run "Show me unrecovered carts over $200"
```

---

## Daily Data Flow

```
                                    ┌─────────────────┐
                                    │  Google Trends  │
                                    │  Google Ads     │
                                    │  Social Media   │
                                    └────────┬────────┘
                                             │
                                             ▼
┌──────────────┐                   ┌─────────────────┐
│   Shopify    │──────────────────▶│  Market Intel   │
│   (orders,   │                   │     Agent       │
│   products)  │                   └────────┬────────┘
└──────┬───────┘                            │
       │                                    │ Weekly Intel Brief
       │                                    │ (7:00 AM Monday)
       ▼                                    │
┌──────────────┐                            ▼
│   Supabase   │──────────────────▶┌─────────────────┐
│  (carts,     │                   │ Sales Director  │
│   analytics) │                   │     Agent       │
└──────────────┘                   └────────┬────────┘
                                            │
                                            │ Daily Briefing
                                            │ (8:00 AM)
                                            ▼
                                   ┌─────────────────┐
                                   │    Telegram     │
                                   │    (Owner)      │
                                   └─────────────────┘
```

---

## Troubleshooting Connections

### Supabase Not Connecting
```bash
# Check service role key is correct
curl -H "apikey: YOUR_SERVICE_KEY" \
     -H "Authorization: Bearer YOUR_SERVICE_KEY" \
     https://gvcswimqaxvylgxbklbz.supabase.co/rest/v1/abandoned_carts?limit=1
```

### Shopify Products Not Loading
```bash
# Test storefront API
curl -X POST \
  https://kctmenswear.myshopify.com/api/2024-10/graphql.json \
  -H "Content-Type: application/json" \
  -H "X-Shopify-Storefront-Access-Token: YOUR_TOKEN" \
  -d '{"query": "{ shop { name } }"}'
```

### Edge Function Errors
```bash
# Check Supabase function logs
npx supabase functions logs products-catalog --project-ref gvcswimqaxvylgxbklbz
```

---

## Notes

- All API tokens should be stored securely in Clawdbot's credential store
- Never commit tokens to git
- Rotate tokens quarterly for security
- The Supabase anon key (in client.ts) is public and safe - the service role key is secret

**Last Updated:** 2026-01-25
