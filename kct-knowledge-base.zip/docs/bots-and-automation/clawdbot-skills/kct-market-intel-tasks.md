# KCT Market Intelligence - Scheduled Tasks

These are the automated research tasks for the Market Intelligence Agent.

---

## Weekly Intelligence Brief
**Schedule:** Every Monday at 7:00 AM Eastern
**Channel:** Telegram
**Runs before:** Sales Director's 8am briefing (so insights can inform daily actions)

### Tasks to Run:

1. **Google Trends Scan**
   - Query trends for all tracked keywords
   - Compare to last week
   - Identify rising/falling/breakout terms

2. **Competitor Website Check**
   - Screenshot homepages of top 5 competitors
   - Compare to last week's screenshots
   - Note any changes (messaging, pricing, promotions)

3. **Social Media Scan**
   - Check competitor Instagram posts (last 7 days)
   - Check Pinterest trending in "wedding suits" category
   - Note viral content or new trends

4. **Review Scan**
   - New Google Reviews for KCT
   - New Google Reviews for competitors
   - Any themes or patterns

5. **Generate Weekly Brief**
   - Compile findings
   - Prioritize by impact
   - Include recommendations
   - Flag items for Sales Director

---

## Competitor Deep Dive
**Schedule:** 1st and 15th of each month at 6:00 AM
**Channel:** Telegram

### Competitors to Analyze:

**Round 1 (1st of month):** Direct Competitors
- Men's Wearhouse
- Jos A Bank
- Local competitors

**Round 2 (15th of month):** Aspirational Competitors
- Indochino
- Suit Supply
- The Black Tux
- Bonobos

### Analysis Checklist:

```
For each competitor:
□ Homepage messaging and positioning
□ Current promotions/sales
□ New products or collections
□ Pricing changes
□ Website/UX changes
□ Recent blog content
□ Social media activity (last 30 days)
□ Ad campaigns (Facebook Ad Library)
□ Customer reviews (recent themes)
□ Estimated traffic (Similarweb if available)
```

### Output:
Detailed competitor report with:
- What they're doing well
- Their weaknesses
- Opportunities for KCT
- Threats to watch

---

## Google Trends Deep Scan
**Schedule:** Every Wednesday at 6:00 AM
**Channel:** Telegram (only if notable findings)

### Keywords to Track:

**Tier 1 - Core Terms (weekly):**
```
wedding suits
groomsmen suits
prom suits
buy wedding suit
wedding suit colors
navy wedding suit
```

**Tier 2 - Long-tail (weekly):**
```
wedding suits near me
affordable wedding suits
own vs rent wedding suit
groomsmen packages
custom wedding suit
```

**Tier 3 - Local (weekly):**
```
suits kalamazoo
suits michigan
wedding suits grand rapids
menswear michigan
```

**Tier 4 - Seasonal (adjust by season):**
```
Spring/Summer: summer wedding attire, destination wedding suit
Fall: fall wedding suits, autumn wedding colors
Prom Season: prom suits 2026, prom outfit ideas
```

### Report Only If:
- Any term changes >20% week-over-week
- Breakout terms detected
- New related queries appearing
- Geographic shifts

---

## Social Listening Scan
**Schedule:** Tuesday and Friday at 10:00 AM
**Channel:** Telegram (only if notable findings)

### Platforms to Check:

**Reddit:**
- r/weddingplanning (search: suit, groom, groomsmen)
- r/malefashionadvice (search: wedding, suit, formal)
- r/prom (search: suit, outfit)

**Facebook Groups:**
- Wedding planning groups
- Michigan weddings groups

**Pinterest:**
- Trending pins in "Men's Fashion"
- "Wedding" category trends
- Save rates on suit styles

**Instagram:**
- #weddingsuit top posts
- #groomstyle engagement
- Wedding photographer posts

### What to Capture:
- Questions people are asking
- Frustrations expressed
- Praise for any brand
- Complaints about any brand
- Style preferences mentioned
- Budget discussions

---

## SEO Opportunity Scan
**Schedule:** Every other Monday at 6:00 AM (alternating with competitor deep dive)
**Channel:** Telegram

### Data to Pull:

**From Google Search Console:**
- Top queries driving traffic
- Queries with impressions but low clicks (opportunity)
- Position changes
- New queries appearing

**From Google Autocomplete:**
- Run searches for core terms
- Capture "People also ask" questions
- Note autocomplete suggestions

**From Competitor Analysis:**
- Keywords competitors rank for (that KCT doesn't)
- Content gaps
- Backlink opportunities

### Output:
- 3-5 content recommendations with:
  - Suggested title
  - Target keywords
  - Search volume estimate
  - Difficulty assessment
  - Why it matters

---

## Monthly Industry Report
**Schedule:** First Monday of each month at 6:00 AM
**Channel:** Telegram + Save to file

### Sections to Include:

1. **Search Trend Summary**
   - Month-over-month changes
   - Year-over-year comparison
   - Predictions for next month

2. **Competitor Landscape**
   - Who gained/lost ground
   - Major moves made
   - Market positioning shifts

3. **Customer Sentiment**
   - Review themes (positive and negative)
   - Common questions/concerns
   - Unmet needs

4. **Industry News**
   - Wedding industry trends
   - Economic factors
   - Style trends

5. **SEO Performance**
   - Ranking changes
   - Content performance
   - Opportunities

6. **3-Month Forecast**
   - What's coming seasonally
   - Predicted trend shifts
   - Recommended preparations

7. **Strategic Recommendations**
   - Top 3 priorities for the month
   - Quick wins
   - Long-term plays

---

## Seasonal Alerts

### January 1st - Engagement Season Start
```
🎯 SEASONAL ALERT: Engagement Season Begins

The highest engagement period of the year (Dec 24 - Feb 14) is here.

WHAT THIS MEANS:
• Couples are getting engaged NOW
• They'll search for wedding suits in 60-90 days
• This is your lead generation window

MARKET INTEL FOCUS:
• Monitoring wedding suit search spikes
• Tracking competitor wedding campaigns
• Identifying content opportunities

PASS TO SALES DIRECTOR:
• Recommend increasing wedding ad spend
• Suggest wedding-focused homepage
```

### February 15th - Prom Research Starts
```
🎓 SEASONAL ALERT: Prom Season Approaching

High schoolers begin searching for prom outfits.

MARKET INTEL FOCUS:
• Tracking prom suit searches
• Monitoring prom style trends
• Competitor prom pricing

DATA TO WATCH:
• "prom suits" search volume
• Pinterest prom board activity
• TikTok prom content trends
```

### August 1st - Fall Wedding Prep
```
🍂 SEASONAL ALERT: Fall Wedding Season Prep

Second wedding peak approaching (Sept-Nov).

MARKET INTEL FOCUS:
• Fall color trends
• Competitor fall campaigns
• Booking pattern analysis
```

---

## Alert Triggers (Real-time)

These alerts fire immediately when detected:

### Competitor Price Change
**Trigger:** Price change >10% detected on monitored competitor
```
🚨 COMPETITOR PRICE ALERT

[Competitor] changed pricing:
• Product: [what]
• Old price: $X
• New price: $Y
• Change: [%]

ANALYSIS:
[Why they might have done this]

RECOMMENDATION:
[What KCT should consider]

PASS TO SALES DIRECTOR: [Yes/No]
```

### Trending Topic Spike
**Trigger:** Any tracked keyword increases >50% week-over-week
```
📈 TREND SPIKE DETECTED

"[keyword]" searches up [X]% this week

LIKELY CAUSE:
[Analysis]

OPPORTUNITY:
[What KCT should do]

URGENCY: [High/Medium/Low]
```

### Negative Review Alert
**Trigger:** New 1-2 star review for KCT
```
⚠️ NEGATIVE REVIEW ALERT

Platform: [Google/Yelp/etc]
Rating: [X] stars
Content: "[review text]"

SUGGESTED RESPONSE:
"[Draft response]"

PASS TO SALES DIRECTOR: Yes
```

### Competitor Campaign Launch
**Trigger:** New competitor ad detected in Facebook Ad Library or Google Ads
```
📢 COMPETITOR AD DETECTED

Competitor: [Name]
Platform: [Facebook/Google/Instagram]
Message: "[ad copy/image description]"
Targeting: [if detectable]

ANALYSIS:
[What they're pushing and why]

CONSIDERATION:
[Should KCT respond?]
```

---

## Data Storage

All intelligence should be saved for historical analysis:

```
~/.clawdbot/workspace/market-intel/
├── weekly-briefs/
│   └── YYYY-MM-DD-weekly.md
├── monthly-reports/
│   └── YYYY-MM-monthly.md
├── competitor-snapshots/
│   └── YYYY-MM-DD-[competitor].md
├── trend-data/
│   └── YYYY-MM-trends.json
└── alerts/
    └── YYYY-MM-DD-[type].md
```

This allows:
- Historical comparison
- Trend analysis over time
- Pattern recognition
- Strategy validation

---

## Coordination with Sales Director

**Market Intelligence runs BEFORE Sales Director briefings:**

```
6:00 AM - Market Intel gathers data
7:00 AM - Market Intel Weekly Brief sent
8:00 AM - Sales Director Daily Brief (informed by Market Intel)
```

**Handoff Protocol:**

When Market Intel finds something actionable:
1. Include in report: "PASS TO SALES DIRECTOR: Yes"
2. Tag the finding clearly
3. Sales Director incorporates into daily actions

Example:
```
MARKET INTEL: "Competitor launched free shipping promo"
→ SALES DIRECTOR: "Consider matching or counter-messaging. Today's task #2."
```
