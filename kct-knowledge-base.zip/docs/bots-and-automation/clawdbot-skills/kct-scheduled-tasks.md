# KCT Scheduled Tasks

These are the automated tasks that run on a schedule.

## Daily Morning Briefing
**Schedule**: Every day at 8:00 AM Eastern
**Channel**: Telegram (primary), can also send to SMS

### What to do:
1. Pull yesterday's Shopify data (revenue, orders, AOV)
2. Pull this week's data and compare to goal
3. Check Google Ads dashboard for ROAS
4. Scan competitor websites for price changes
5. List abandoned carts from last 48 hours
6. Check for unanswered inquiries/messages
7. Generate the briefing using kct-sales-director.md format
8. Send via Telegram

### Data to collect:
```
SHOPIFY:
- Yesterday's revenue
- Yesterday's order count
- Week-to-date revenue
- Average order value
- Top selling products (last 7 days)
- Abandoned carts (last 48 hours with email/value)
- New customer inquiries

GOOGLE ADS:
- Yesterday's spend
- Yesterday's conversions
- 7-day ROAS
- Top performing campaigns
- Any campaigns with ROAS < 2x

GOOGLE ANALYTICS:
- Yesterday's sessions
- Conversion rate
- Top traffic sources
- Top landing pages

COMPETITORS (check websites):
- Men's Wearhouse: any banner/promo changes
- Jos A Bank: any sale messaging
- Indochino: pricing changes
```

---

## Daily Accountability Check-in
**Schedule**: Every day at 5:00 PM Eastern
**Channel**: Telegram

### What to do:
1. Reference the morning briefing's 3 action items
2. Ask if each was completed (yes/no)
3. If any NO: ask why and note for tomorrow
4. Preview tomorrow's likely priorities
5. Give a brief encouragement or push depending on performance

### Message format:
```
Hey - checking in on today's action items:

1. [ACTION 1] - Done? ✅/❌
2. [ACTION 2] - Done? ✅/❌
3. [ACTION 3] - Done? ✅/❌

Reply with your status and I'll prep tomorrow's briefing.
```

---

## Weekly Sales Review
**Schedule**: Every Sunday at 7:00 PM Eastern
**Channel**: Telegram

### What to do:
1. Calculate weekly revenue vs goal
2. Grade the week (A/B/C/D/F)
3. Identify what worked
4. Identify what didn't
5. Set top 3 priorities for next week
6. Provide seasonal context for upcoming week

### Report format:
```
═══════════════════════════════════════════
📊 WEEKLY SALES REVIEW - Week of [DATE]
═══════════════════════════════════════════

REVENUE
Goal:     $[X]
Actual:   $[Y]
Result:   [% of goal] [✅/❌]

GRADE: [A/B/C/D/F]

WHAT WORKED
• [Specific thing 1]
• [Specific thing 2]

WHAT DIDN'T WORK
• [Specific thing 1]
• [Specific thing 2]

TASKS COMPLETED: [X]/[Y] ([%])

NEXT WEEK'S PRIORITIES
1. [Priority 1]
2. [Priority 2]
3. [Priority 3]

SEASONAL NOTE
[What's coming up, what to prepare for]
═══════════════════════════════════════════
```

---

## Competitor Price Check
**Schedule**: Every Monday and Thursday at 10:00 AM
**Channel**: Telegram (only if changes detected)

### What to check:
1. Men's Wearhouse
   - Wedding package pricing
   - Current promotions
   - Any "free groom" deals

2. Jos A Bank
   - Sale status (they always have sales)
   - Wedding suit pricing

3. Indochino
   - Custom suit pricing
   - Promo codes visible

4. The Black Tux
   - Rental pricing
   - Wedding packages

### Alert format (only if changes):
```
🚨 COMPETITOR ALERT

[COMPETITOR NAME] changed something:
- Old: [what it was]
- New: [what it is now]

RECOMMENDED RESPONSE:
[What KCT should do about it]

This [does/doesn't] require immediate action.
```

---

## Abandoned Cart Follow-up
**Schedule**: Every day at 11:00 AM Eastern
**Channel**: Telegram

### What to do:
1. Check Shopify for carts abandoned 24-48 hours ago
2. Filter for high-value carts ($300+)
3. Identify any wedding party inquiries (multiple suits)
4. Draft personalized follow-up messages
5. Send summary to owner with draft messages

### Alert format:
```
💰 ABANDONED CART FOLLOW-UP

HIGH VALUE CARTS (action needed):

1. [EMAIL] - $[VALUE] - [PRODUCT]
   Abandoned: [TIME AGO]
   Draft message: "[personalized email draft]"

2. [EMAIL] - $[VALUE] - [PRODUCT]
   ...

WEDDING PARTY LEADS (PRIORITY):
🔥 [NAME/EMAIL] - [X] suits - $[VALUE] potential
   This needs a PHONE CALL, not email.

STANDARD CARTS (auto-email OK):
- [X] carts totaling $[VALUE]
- Recommend sending standard abandoned cart email

Reply "SEND" to send the drafted emails.
```

---

## Google Ads Alert
**Schedule**: Continuous monitoring, alert when triggered
**Channel**: Telegram

### Triggers:
1. **ROAS drops below 2.0** for 3+ consecutive days
   - Alert: "ROAS Alert: Your ads are no longer profitable"
   - Action: Pause lowest performing campaigns

2. **ROAS exceeds 4.0** for 3+ consecutive days
   - Alert: "ROAS Opportunity: You should scale up"
   - Action: Recommend budget increase

3. **Daily spend significantly under budget**
   - Alert: "Ads underspending - check campaign status"

4. **Conversion rate drops 30%+ from baseline**
   - Alert: "Conversion drop detected - check landing pages"

### Alert format:
```
⚠️ GOOGLE ADS ALERT

Issue: [DESCRIPTION]
Impact: [REVENUE IMPACT ESTIMATE]

Data:
- Current ROAS: [X]
- 7-day avg ROAS: [Y]
- Spend: $[Z]

RECOMMENDED ACTION:
[Specific action to take]

This needs attention [TODAY/THIS WEEK].
```

---

## Monthly Revenue Report
**Schedule**: 1st of each month at 9:00 AM
**Channel**: Telegram + Email

### What to include:
1. Total monthly revenue vs goal
2. Comparison to previous month
3. Comparison to same month last year
4. Top products
5. Traffic and conversion trends
6. Ad spend and ROAS summary
7. Customer acquisition cost
8. Recommendations for next month

---

## Seasonal Preparation Alerts

### January 2nd
"🎯 ENGAGEMENT SEASON STARTS NOW. Couples are searching. Max out wedding keywords. This month's leads = April-June revenue."

### February 15th
"🎓 PROM SEASON PREP: Launch prom landing page this week. High schoolers start searching late February."

### March 1st
"🔥 PEAK BOOKING SEASON: Wedding + Prom. Highest search volume of the year. Ensure inventory, increase ad spend."

### May 1st
"📦 FULFILLMENT FOCUS: Peak delivery time. Focus on execution, not new leads. Upsell add-ons."

### July 1st
"📉 SUMMER SLOWDOWN: Reduce ad spend. Clear excess inventory. Build content for fall."

### September 1st
"🍂 FALL WEDDING SEASON: Second peak. Increase ads. Target fall wedding + homecoming keywords."

### November 15th
"🎄 HOLIDAY PREP: Gift cards, party suits. Prepare January wedding content."
