# Bundle Component Images System

This document describes the implementation of the bundle component images feature, which allows administrators to assign individual component images (suit, shirt, tie) to bundle products, creating a hover effect that shows all three components in a grid layout.

## Overview

The bundle component images system enables:
- Admins to assign suit, shirt, and tie images to bundle products
- Automatic hover effect on product cards showing all 3 components in a grid
- Image selection from pre-existing R2 cloud storage library
- Storage of component image URLs in Supabase database

## Architecture

### Database Table

**Table: `bundle_component_images`**

| Column | Type | Description |
|--------|------|-------------|
| id | uuid | Primary key |
| shopify_product_id | text | The Shopify product ID (gid://shopify/Product/...) |
| suit_image_url | text | URL to the suit component image |
| shirt_image_url | text | URL to the shirt component image |
| tie_image_url | text | URL to the tie/bowtie component image |
| composite_grid_url | text | (Optional) URL to pre-generated composite image |
| created_at | timestamp | Creation timestamp |
| updated_at | timestamp | Last update timestamp |

### Image Sources

Component images are sourced from Cloudflare R2 storage:
- **Base URL**: `https://pub-46371bda6faf4910b74631159fc2dfd4.r2.dev/kct-prodcuts/`
- **Suits**: `/Suits/` folder (12 options)
- **Shirts**: `/Shirts/` folder (17 options)
- **Ties**: `/Bow:Tie/` folder (76 color options, URL encoded as `Bow%3ATie`)

## Key Files

### Admin Interface
- **`src/pages/admin/BundleComponentManager.tsx`** - Admin page for managing bundle component images

### Data Hooks
- **`src/hooks/useBundleComponentImages.ts`** - React Query hooks for fetching/saving component images
  - `useBundleComponentImages(shopifyProductId)` - Fetch single bundle's images
  - `useAllBundleComponentImages()` - Fetch all component images
  - `useBundleComponentImagesMap()` - Get Map for quick lookups by product ID
  - `useUploadBundleComponentImages()` - Upload new images
  - `useDeleteBundleComponentImages()` - Delete images

### Display Components (with hover effect)
- **`src/components/homepage/BundleTrendingSection.tsx`** - Homepage "Celebration Ready" carousel
- **`src/components/homepage/FeaturedBundlesCarousel.tsx`** - Homepage "Holiday Party Essentials" grid
- **`src/components/ProductCardWithVariants.tsx`** - General product cards (search, collections, etc.)

## Hover Effect Implementation

The hover effect displays all 3 component images in a side-by-side grid:

```tsx
{/* Component Images Grid on Hover - 3 columns side by side */}
{hasComponentImages && (
  <div className={`absolute inset-0 grid grid-cols-3 gap-1 bg-muted/50 p-1 transition-all duration-500 ${
    isHovered ? 'opacity-100' : 'opacity-0'
  }`}>
    {bundleImages?.suit_image_url && (
      <img src={bundleImages.suit_image_url} alt="Suit" 
           className="w-full h-full object-cover object-top rounded-sm" />
    )}
    {bundleImages?.shirt_image_url && (
      <img src={bundleImages.shirt_image_url} alt="Shirt" 
           className="w-full h-full object-cover object-top rounded-sm" />
    )}
    {bundleImages?.tie_image_url && (
      <img src={bundleImages.tie_image_url} alt="Tie" 
           className="w-full h-full object-cover object-left rounded-sm" />
    )}
  </div>
)}
```

### Image Positioning

- **Suit**: `object-top` - Shows upper body/chest area of full-body model shots
- **Shirt**: `object-top` - Shows collar/upper portion of folded shirt images
- **Tie**: `object-left` - Shows the tie/bowtie (positioned on left side of combined tie+bowtie images)

## Admin Workflow

1. Navigate to `/admin/bundle-components`
2. Browse list of all bundles from Shopify
3. Click "Manage Images" on a bundle
4. For each component (suit, shirt, tie):
   - Select from dropdown of available images from R2 storage
   - System auto-matches based on color keywords in product title
5. Click "Save Images" to store URLs in database
6. Component images will now appear on hover for that bundle

## Extending to Other Components

To add this hover effect to other product card components:

1. Import the hook:
```tsx
import { useBundleComponentImagesMap } from '@/hooks/useBundleComponentImages';
```

2. Get the images map:
```tsx
const { data: componentImagesMap } = useBundleComponentImagesMap();
```

3. Look up images by product ID:
```tsx
const bundleImages = componentImagesMap?.get(product.id);
const hasComponentImages = bundleImages && (
  bundleImages.suit_image_url || 
  bundleImages.shirt_image_url || 
  bundleImages.tie_image_url
);
```

4. Add hover state and grid display (see hover effect code above)

## Future Enhancements

- [ ] Add component images to `ProductCardWithVariants` for all product listings
- [ ] Generate composite images server-side for social media sharing
- [ ] Support for additional component types (vest, pocket square, etc.)
- [ ] Bulk assignment of component images by color matching

## Related Documentation

- [R2 Product Images Source](/docs/integrations/r2-product-images-source.md)
- [Bundle Component Picker](/docs/features/bundle-component-picker.md)
