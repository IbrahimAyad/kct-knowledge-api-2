
# Database Schema Documentation

## Overview

This document outlines the complete database schema for the Groomsmen Management System. All tables use PostgreSQL with appropriate indexes and constraints.

---

## Core Tables

### users
```sql
CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email VARCHAR(255) UNIQUE NOT NULL,
  password_hash VARCHAR(255),
  first_name VARCHAR(100),
  last_name VARCHAR(100),
  phone VARCHAR(20),
  role VARCHAR(20) DEFAULT 'groomsman' CHECK (role IN ('admin', 'coordinator', 'groomsman')),
  avatar_url TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_role ON users(role);
```

### weddings
```sql
CREATE TABLE weddings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  bride_name VARCHAR(100) NOT NULL,
  groom_name VARCHAR(100) NOT NULL,
  wedding_date DATE NOT NULL,
  venue VARCHAR(255),
  venue_address TEXT,
  party_code VARCHAR(10) UNIQUE NOT NULL,
  coordinator_id UUID REFERENCES users(id),
  status VARCHAR(20) DEFAULT 'active' CHECK (status IN ('active', 'completed', 'cancelled')),
  theme_colors JSONB DEFAULT '[]',
  settings JSONB DEFAULT '{}',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_weddings_party_code ON weddings(party_code);
CREATE INDEX idx_weddings_date ON weddings(wedding_date);
CREATE INDEX idx_weddings_coordinator ON weddings(coordinator_id);
```

### groomsmen
```sql
CREATE TABLE groomsmen (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  wedding_id UUID REFERENCES weddings(id) ON DELETE CASCADE,
  user_id UUID REFERENCES users(id) ON DELETE SET NULL,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(255),
  phone VARCHAR(20),
  role VARCHAR(50) NOT NULL, -- 'Groom', 'Best Man', 'Groomsman', etc.
  suit_type VARCHAR(10) CHECK (suit_type IN ('2P', '3P')),
  measurement_status VARCHAR(20) DEFAULT 'pending' CHECK (measurement_status IN ('pending', 'scheduled', 'complete')),
  payment_status VARCHAR(20) DEFAULT 'pending' CHECK (payment_status IN ('pending', 'processing', 'paid', 'refunded')),
  claimed BOOLEAN DEFAULT FALSE,
  claimed_at TIMESTAMP WITH TIME ZONE,
  avatar_url TEXT,
  notes TEXT,
  priority_order INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_groomsmen_wedding ON groomsmen(wedding_id);
CREATE INDEX idx_groomsmen_user ON groomsmen(user_id);
CREATE INDEX idx_groomsmen_claimed ON groomsmen(claimed);
CREATE INDEX idx_groomsmen_status ON groomsmen(measurement_status, payment_status);
```

### measurements
```sql
CREATE TABLE measurements (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  groomsman_id UUID REFERENCES groomsmen(id) ON DELETE CASCADE,
  jacket_size VARCHAR(10),
  chest DECIMAL(5,2),
  waist DECIMAL(5,2),
  hips DECIMAL(5,2),
  inseam DECIMAL(5,2),
  outseam DECIMAL(5,2),
  sleeve_length DECIMAL(5,2),
  shoulder_width DECIMAL(5,2),
  neck_size DECIMAL(5,2),
  height_feet INTEGER,
  height_inches INTEGER,
  weight_lbs INTEGER,
  measurement_method VARCHAR(20) DEFAULT 'self' CHECK (measurement_method IN ('self', 'professional', 'ai_assisted')),
  measured_by VARCHAR(100),
  measurement_date DATE DEFAULT CURRENT_DATE,
  notes TEXT,
  alterations_needed TEXT,
  verified BOOLEAN DEFAULT FALSE,
  verified_at TIMESTAMP WITH TIME ZONE,
  verified_by UUID REFERENCES users(id),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_measurements_groomsman ON measurements(groomsman_id);
CREATE INDEX idx_measurements_verified ON measurements(verified);
```

### payments
```sql
CREATE TABLE payments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  groomsman_id UUID REFERENCES groomsmen(id) ON DELETE CASCADE,
  stripe_payment_intent_id VARCHAR(255),
  amount_cents INTEGER NOT NULL,
  currency VARCHAR(3) DEFAULT 'USD',
  status VARCHAR(20) DEFAULT 'pending' CHECK (status IN ('pending', 'processing', 'succeeded', 'failed', 'cancelled', 'refunded')),
  payment_method VARCHAR(50),
  suit_type VARCHAR(10),
  items JSONB DEFAULT '[]', -- Array of items being purchased
  discount_amount_cents INTEGER DEFAULT 0,
  tax_amount_cents INTEGER DEFAULT 0,
  total_amount_cents INTEGER NOT NULL,
  payment_plan VARCHAR(20) DEFAULT 'full' CHECK (payment_plan IN ('full', 'installments')),
  installment_schedule JSONB,
  paid_at TIMESTAMP WITH TIME ZONE,
  refunded_at TIMESTAMP WITH TIME ZONE,
  failure_reason TEXT,
  metadata JSONB DEFAULT '{}',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_payments_groomsman ON payments(groomsman_id);
CREATE INDEX idx_payments_status ON payments(status);
CREATE INDEX idx_payments_stripe ON payments(stripe_payment_intent_id);
```

---

## Communication Tables

### chat_messages
```sql
CREATE TABLE chat_messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  wedding_id UUID REFERENCES weddings(id) ON DELETE CASCADE,
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  message TEXT NOT NULL,
  message_type VARCHAR(20) DEFAULT 'text' CHECK (message_type IN ('text', 'image', 'file', 'system')),
  reply_to_id UUID REFERENCES chat_messages(id),
  file_url TEXT,
  file_name VARCHAR(255),
  file_size INTEGER,
  read_by JSONB DEFAULT '[]', -- Array of user IDs who have read this message
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_chat_messages_wedding ON chat_messages(wedding_id);
CREATE INDEX idx_chat_messages_user ON chat_messages(user_id);
CREATE INDEX idx_chat_messages_created ON chat_messages(created_at);
```

### ai_interactions
```sql
CREATE TABLE ai_interactions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  wedding_id UUID REFERENCES weddings(id) ON DELETE CASCADE,
  session_id VARCHAR(255),
  message_type VARCHAR(20) CHECK (message_type IN ('user', 'assistant')),
  content TEXT NOT NULL,
  context JSONB DEFAULT '{}', -- Additional context like groomsman data, measurements, etc.
  tokens_used INTEGER,
  model_used VARCHAR(50),
  response_time_ms INTEGER,
  satisfaction_rating INTEGER CHECK (satisfaction_rating BETWEEN 1 AND 5),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_ai_interactions_user ON ai_interactions(user_id);
CREATE INDEX idx_ai_interactions_session ON ai_interactions(session_id);
CREATE INDEX idx_ai_interactions_wedding ON ai_interactions(wedding_id);
```

---

## System Tables

### notifications
```sql
CREATE TABLE notifications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  wedding_id UUID REFERENCES weddings(id) ON DELETE CASCADE,
  type VARCHAR(50) NOT NULL, -- 'measurement_reminder', 'payment_due', 'group_message', etc.
  title VARCHAR(255) NOT NULL,
  message TEXT NOT NULL,
  data JSONB DEFAULT '{}', -- Additional notification data
  read BOOLEAN DEFAULT FALSE,
  read_at TIMESTAMP WITH TIME ZONE,
  action_url TEXT,
  priority VARCHAR(20) DEFAULT 'normal' CHECK (priority IN ('low', 'normal', 'high', 'urgent')),
  expires_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_notifications_user ON notifications(user_id);
CREATE INDEX idx_notifications_read ON notifications(read);
CREATE INDEX idx_notifications_type ON notifications(type);
```

### audit_logs
```sql
CREATE TABLE audit_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id),
  wedding_id UUID REFERENCES weddings(id),
  action VARCHAR(100) NOT NULL,
  entity_type VARCHAR(50) NOT NULL, -- 'groomsman', 'measurement', 'payment', etc.
  entity_id UUID,
  old_values JSONB,
  new_values JSONB,
  ip_address INET,
  user_agent TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_audit_logs_user ON audit_logs(user_id);
CREATE INDEX idx_audit_logs_entity ON audit_logs(entity_type, entity_id);
CREATE INDEX idx_audit_logs_action ON audit_logs(action);
```

---

## Views and Functions

### groomsmen_summary_view
```sql
CREATE VIEW groomsmen_summary_view AS
SELECT 
  g.*,
  u.first_name AS user_first_name,
  u.last_name AS user_last_name,
  u.email AS user_email,
  m.id AS measurement_id,
  m.verified AS measurements_verified,
  p.status AS latest_payment_status,
  p.total_amount_cents AS payment_amount
FROM groomsmen g
LEFT JOIN users u ON g.user_id = u.id
LEFT JOIN measurements m ON g.id = m.groomsman_id
LEFT JOIN LATERAL (
  SELECT * FROM payments 
  WHERE groomsman_id = g.id 
  ORDER BY created_at DESC 
  LIMIT 1
) p ON true;
```

### update_timestamp_function
```sql
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Apply to all tables with updated_at column
CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_weddings_updated_at BEFORE UPDATE ON weddings FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_groomsmen_updated_at BEFORE UPDATE ON groomsmen FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_measurements_updated_at BEFORE UPDATE ON measurements FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_payments_updated_at BEFORE UPDATE ON payments FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
```

---

## Security & Row Level Security (RLS)

### Enable RLS on all tables
```sql
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE weddings ENABLE ROW LEVEL SECURITY;
ALTER TABLE groomsmen ENABLE ROW LEVEL SECURITY;
ALTER TABLE measurements ENABLE ROW LEVEL SECURITY;
ALTER TABLE payments ENABLE ROW LEVEL SECURITY;
ALTER TABLE chat_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE ai_interactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;
```

### Example RLS Policies
```sql
-- Users can only see/edit their own profile
CREATE POLICY "Users can view own profile" ON users FOR SELECT USING (auth.uid() = id);
CREATE POLICY "Users can update own profile" ON users FOR UPDATE USING (auth.uid() = id);

-- Groomsmen can only access their wedding party
CREATE POLICY "Groomsmen access" ON groomsmen FOR ALL USING (
  EXISTS (
    SELECT 1 FROM weddings w 
    WHERE w.id = wedding_id 
    AND (w.coordinator_id = auth.uid() OR user_id = auth.uid())
  )
);
```

---

## Indexes for Performance

```sql
-- Composite indexes for common queries
CREATE INDEX idx_groomsmen_wedding_status ON groomsmen(wedding_id, measurement_status, payment_status);
CREATE INDEX idx_payments_groomsman_status ON payments(groomsman_id, status);
CREATE INDEX idx_chat_messages_wedding_created ON chat_messages(wedding_id, created_at DESC);
CREATE INDEX idx_notifications_user_read ON notifications(user_id, read, created_at DESC);

-- Full-text search indexes
CREATE INDEX idx_groomsmen_search ON groomsmen USING GIN(to_tsvector('english', name || ' ' || COALESCE(email, '') || ' ' || role));
```

This schema supports all current frontend features and provides room for future enhancements. All tables include proper constraints, indexes, and audit trails for production use.
