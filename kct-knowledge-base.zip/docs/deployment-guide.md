
# Deployment Guide

## Overview

This guide covers deployment options for the Groomsmen Management System, from development setup to production deployment on various platforms.

---

## Development Setup

### Prerequisites
- Node.js 18+ and npm/yarn
- PostgreSQL 14+
- Redis 6+ (optional, for sessions)
- Git

### Local Development
```bash
# Clone repository
git clone https://github.com/yourorg/groomsmen-management
cd groomsmen-management

# Install dependencies
npm install

# Set up environment variables
cp .env.example .env
# Edit .env with your configuration

# Set up database
npm run db:setup
npm run db:migrate
npm run db:seed

# Start development servers
npm run dev:backend    # API server on :3001
npm run dev:frontend   # React app on :5173
```

### Database Setup
```sql
-- Create database
CREATE DATABASE groomsmen_management;
CREATE USER groomsmen_user WITH PASSWORD 'secure_password';
GRANT ALL PRIVILEGES ON DATABASE groomsmen_management TO groomsmen_user;

-- Enable required extensions
\c groomsmen_management;
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";
```

---

## Production Deployment Options

### Option 1: Supabase (Recommended)
Easiest deployment using Supabase's full-stack platform.

#### Step 1: Set up Supabase Project
1. Create account at [supabase.com](https://supabase.com)
2. Create new project
3. Note your project URL and anon key

#### Step 2: Configure Database
```sql
-- Run the schema from docs/database-schema.md
-- Enable Row Level Security
-- Set up authentication policies
```

#### Step 3: Deploy Frontend
```bash
# Build frontend
npm run build

# Deploy to Supabase
npm install -g supabase
supabase login
supabase init
supabase db push
supabase deploy
```

#### Step 4: Configure Environment
```bash
# In Supabase dashboard > Settings > API
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_ANON_KEY=your-anon-key

# Configure additional services
OPENAI_API_KEY=your-openai-key
STRIPE_SECRET_KEY=your-stripe-key
```

### Option 2: Vercel + PlanetScale
Modern serverless deployment.

#### Frontend (Vercel)
```bash
# Install Vercel CLI
npm install -g vercel

# Deploy
vercel --prod

# Set environment variables in Vercel dashboard
```

#### Database (PlanetScale)
```bash
# Install PlanetScale CLI
# Create database
pscale database create groomsmen-management

# Create development branch
pscale branch create groomsmen-management development

# Connect and run migrations
pscale connect groomsmen-management development --port 3309
# Run schema in separate terminal
```

#### Backend (Vercel Functions)
```javascript
// api/groomsmen.js
import { createConnection } from '@planetscale/database';

const config = {
  host: process.env.DATABASE_HOST,
  username: process.env.DATABASE_USERNAME,
  password: process.env.DATABASE_PASSWORD,
};

export default async function handler(req, res) {
  const conn = createConnection(config);
  // Handle API logic
}
```

### Option 3: Traditional VPS/Cloud
For full control and custom configuration.

#### Server Requirements
- Ubuntu 20.04+ or similar
- 2GB+ RAM
- 20GB+ storage
- Node.js 18+
- PostgreSQL 14+
- Nginx
- SSL certificate

#### Setup Script
```bash
#!/bin/bash
# server-setup.sh

# Update system
sudo apt update && sudo apt upgrade -y

# Install Node.js
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt install -y nodejs

# Install PostgreSQL
sudo apt install -y postgresql postgresql-contrib

# Install Nginx
sudo apt install -y nginx

# Install PM2 for process management
npm install -g pm2

# Install Redis
sudo apt install -y redis-server

# Configure firewall
sudo ufw allow 22
sudo ufw allow 80
sudo ufw allow 443
sudo ufw enable
```

#### Application Deployment
```bash
# Create application user
sudo adduser groomsmen
sudo usermod -aG sudo groomsmen

# Switch to app user
sudo su - groomsmen

# Clone and setup application
git clone https://github.com/yourorg/groomsmen-management
cd groomsmen-management

# Install dependencies
npm ci --production

# Build frontend
npm run build

# Set up environment
cp .env.production .env
# Edit .env with production values

# Start with PM2
pm2 start ecosystem.config.js
pm2 save
pm2 startup
```

#### Nginx Configuration
```nginx
# /etc/nginx/sites-available/groomsmen
server {
    listen 80;
    server_name yourdomain.com www.yourdomain.com;
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    server_name yourdomain.com www.yourdomain.com;

    ssl_certificate /etc/letsencrypt/live/yourdomain.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/yourdomain.com/privkey.pem;

    # Frontend
    location / {
        root /home/groomsmen/groomsmen-management/dist;
        try_files $uri $uri/ /index.html;
    }

    # API
    location /api/ {
        proxy_pass http://localhost:3001;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
}
```

---

## Container Deployment

### Docker Setup
```dockerfile
# Dockerfile
FROM node:18-alpine AS builder

WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production

COPY . .
RUN npm run build

FROM node:18-alpine AS production

WORKDIR /app
COPY --from=builder /app/dist ./dist
COPY --from=builder /app/node_modules ./node_modules
COPY --from=builder /app/package.json ./package.json
COPY --from=builder /app/server ./server

EXPOSE 3001
CMD ["npm", "start"]
```

### Docker Compose
```yaml
# docker-compose.yml
version: '3.8'

services:
  app:
    build: .
    ports:
      - "3001:3001"
    environment:
      - NODE_ENV=production
      - DATABASE_URL=postgresql://user:pass@db:5432/groomsmen
      - REDIS_URL=redis://redis:6379
    depends_on:
      - db
      - redis

  db:
    image: postgres:14
    environment:
      POSTGRES_DB: groomsmen_management
      POSTGRES_USER: groomsmen_user
      POSTGRES_PASSWORD: secure_password
    volumes:
      - postgres_data:/var/lib/postgresql/data
    ports:
      - "5432:5432"

  redis:
    image: redis:6-alpine
    ports:
      - "6379:6379"

  nginx:
    image: nginx:alpine
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx.conf:/etc/nginx/nginx.conf
      - ./ssl:/etc/ssl
    depends_on:
      - app

volumes:
  postgres_data:
```

### Kubernetes Deployment
```yaml
# k8s-deployment.yml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: groomsmen-app
spec:
  replicas: 3
  selector:
    matchLabels:
      app: groomsmen-app
  template:
    metadata:
      labels:
        app: groomsmen-app
    spec:
      containers:
      - name: groomsmen-app
        image: your-registry/groomsmen-management:latest
        ports:
        - containerPort: 3001
        env:
        - name: DATABASE_URL
          valueFrom:
            secretKeyRef:
              name: groomsmen-secrets
              key: database-url
        - name: OPENAI_API_KEY
          valueFrom:
            secretKeyRef:
              name: groomsmen-secrets
              key: openai-api-key
---
apiVersion: v1
kind: Service
metadata:
  name: groomsmen-service
spec:
  selector:
    app: groomsmen-app
  ports:
  - port: 80
    targetPort: 3001
  type: LoadBalancer
```

---

## Environment Configuration

### Production Environment Variables
```bash
# Database
DATABASE_URL=postgresql://user:password@host:5432/groomsmen_production
DATABASE_SSL=true
DATABASE_POOL_SIZE=20

# Authentication
ACCESS_TOKEN_SECRET=your-production-secret-here
REFRESH_TOKEN_SECRET=your-production-refresh-secret
SESSION_SECRET=your-session-secret

# External APIs
OPENAI_API_KEY=sk-your-production-openai-key
STRIPE_SECRET_KEY=sk_live_your-production-stripe-key
STRIPE_WEBHOOK_SECRET=whsec_your-production-webhook-secret
SENDGRID_API_KEY=SG.your-production-sendgrid-key

# App Configuration
NODE_ENV=production
APP_URL=https://yourdomain.com
API_URL=https://api.yourdomain.com
CORS_ORIGIN=https://yourdomain.com

# Redis/Caching
REDIS_URL=redis://your-redis-host:6379
CACHE_TTL=3600

# Monitoring
SENTRY_DSN=your-sentry-dsn
LOG_LEVEL=info

# Rate Limiting
RATE_LIMIT_WINDOW_MS=900000
RATE_LIMIT_MAX_REQUESTS=100
```

---

## SSL/TLS Setup

### Let's Encrypt with Certbot
```bash
# Install Certbot
sudo apt install snapd
sudo snap install --classic certbot
sudo ln -s /snap/bin/certbot /usr/bin/certbot

# Obtain certificate
sudo certbot --nginx -d yourdomain.com -d www.yourdomain.com

# Auto-renewal
sudo crontab -e
# Add: 0 12 * * * /usr/bin/certbot renew --quiet
```

### CloudFlare SSL (Alternative)
1. Add domain to CloudFlare
2. Change nameservers
3. Enable "Full (strict)" SSL mode
4. Use CloudFlare origin certificates

---

## Monitoring & Logging

### Application Monitoring
```javascript
// monitoring.js
const Sentry = require('@sentry/node');

Sentry.init({
  dsn: process.env.SENTRY_DSN,
  environment: process.env.NODE_ENV,
});

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    memory: process.memoryUsage(),
  });
});
```

### Log Management
```javascript
const winston = require('winston');

const logger = winston.createLogger({
  level: process.env.LOG_LEVEL || 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.errors({ stack: true }),
    winston.format.json()
  ),
  transports: [
    new winston.transports.File({ filename: 'error.log', level: 'error' }),
    new winston.transports.File({ filename: 'combined.log' }),
  ],
});

if (process.env.NODE_ENV !== 'production') {
  logger.add(new winston.transports.Console({
    format: winston.format.simple()
  }));
}
```

---

## Backup Strategy

### Database Backups
```bash
#!/bin/bash
# backup-db.sh

DATE=$(date +%Y%m%d_%H%M%S)
BACKUP_DIR="/backups"
DB_NAME="groomsmen_production"

# Create backup
pg_dump $DATABASE_URL > "$BACKUP_DIR/groomsmen_$DATE.sql"

# Compress
gzip "$BACKUP_DIR/groomsmen_$DATE.sql"

# Upload to S3 (optional)
aws s3 cp "$BACKUP_DIR/groomsmen_$DATE.sql.gz" s3://your-backup-bucket/

# Clean old backups (keep 30 days)
find $BACKUP_DIR -name "groomsmen_*.sql.gz" -mtime +30 -delete

# Cron job: 0 2 * * * /home/groomsmen/backup-db.sh
```

### File Backups
```bash
# Backup uploaded files
rsync -av --delete /app/uploads/ /backups/uploads/
aws s3 sync /backups/uploads/ s3://your-backup-bucket/uploads/
```

---

## Performance Optimization

### Database Optimization
```sql
-- Analyze query performance
EXPLAIN ANALYZE SELECT * FROM groomsmen WHERE wedding_id = 'uuid';

-- Add missing indexes
CREATE INDEX CONCURRENTLY idx_groomsmen_wedding_status 
ON groomsmen(wedding_id, measurement_status, payment_status);

-- Vacuum and analyze
VACUUM ANALYZE;
```

### CDN Setup
```javascript
// Configure CDN for static assets
app.use('/assets', express.static('dist/assets', {
  maxAge: '1y',
  setHeaders: (res, path) => {
    res.set('Cache-Control', 'public, immutable');
  }
}));
```

### Redis Caching
```javascript
const redis = require('redis');
const client = redis.createClient(process.env.REDIS_URL);

// Cache frequently accessed data
const cacheGroomsmen = async (weddingId) => {
  const key = `groomsmen:${weddingId}`;
  const cached = await client.get(key);
  
  if (cached) {
    return JSON.parse(cached);
  }
  
  const groomsmen = await getGroomsmenFromDB(weddingId);
  await client.setex(key, 3600, JSON.stringify(groomsmen));
  
  return groomsmen;
};
```

---

## Security Checklist

- [ ] HTTPS enabled with valid SSL certificate
- [ ] Environment variables secured
- [ ] Database connections encrypted
- [ ] API rate limiting implemented
- [ ] Input validation on all endpoints
- [ ] SQL injection protection (parameterized queries)
- [ ] XSS protection headers
- [ ] CSRF protection enabled
- [ ] File upload restrictions
- [ ] Regular security updates applied
- [ ] Access logs monitored
- [ ] Backup encryption enabled

This deployment guide covers various scenarios from simple cloud deployments to complex enterprise setups. Choose the option that best fits your requirements and scale.
