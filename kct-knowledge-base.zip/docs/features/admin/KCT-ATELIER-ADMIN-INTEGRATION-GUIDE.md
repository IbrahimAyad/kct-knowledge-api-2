# KCT Atelier Admin - Integration & Development Guide

## Overview

This document provides comprehensive context for building "KCT Atelier Admin" - an all-in-one intelligent command center for KCT Menswear's e-commerce operation. The goal is to create a bespoke platform that centralizes product organization, real-time inventory tracking, advanced SEO, and sales analytics.

**Important:** This is a SEPARATE admin tool that complements (does NOT replace) the existing product management tools in the main KCT Menswear application.

---

## Existing System Architecture

### Supabase Project Details
- **Project ID:** `gvcswimqaxvylgxbklbz`
- **Project URL:** `https://gvcswimqaxvylgxbklbz.supabase.co`
- **Database:** PostgreSQL with 16,610+ lines of type definitions
- **Edge Functions:** 60+ deployed serverless functions

### Shopify Integration
- **Shopify Domain:** `kctmenswear.myshopify.com`
- **API Version:** `2024-10`
- **Product Count:** ~872 active products (as of December 2024)
- **Two API integrations:**
  1. **Storefront API** (GraphQL) - For customer-facing product data
  2. **Admin API** (REST) - For product management operations

---

## Database Schema Overview

### Total Tables: 180+ tables in public schema

### Key Table Categories:

#### 1. **Product & Inventory Management**
| Table Name | Purpose |
|------------|---------|
| `products` | Core product catalog |
| `inventory` | Stock levels and locations |
| `inventory_variants` | Size/color variant stock |
| `inventory_alerts` | Low stock notifications |
| `inventory_movements` | Stock change history |
| `inventory_reservations` | Reserved stock for orders |
| `enhanced_product_variants` | Extended variant data |
| `bundle_items` | Product bundle components |
| `bundles` | Bundle configurations |
| `bundle_component_images` | Bundle preview images |
| `collection_products` | Product-collection mappings |
| `collections` | Product collections/categories |

#### 2. **Orders & Fulfillment**
| Table Name | Purpose |
|------------|---------|
| `orders` | Main order records |
| `order_items` | Individual line items |
| `order_fulfillment` | Shipping and delivery tracking |
| `order_notes` | Internal order notes |
| `order_notifications` | Customer notification history |
| `order_priority_queue` | Order processing priority |
| `order_exceptions` | Issues/problems with orders |
| `order_refunds` | Refund records |
| `order_returns` | Return requests |
| `custom_orders` | Custom tailoring orders |
| `chat_orders` | Orders from chat interface |

#### 3. **Customer Management**
| Table Name | Purpose |
|------------|---------|
| `customers` | Customer profiles (email, address, preferences) |
| `customer_addresses` | Multiple shipping/billing addresses |
| `customer_segments` | Customer groupings (VIP, repeat, etc.) |
| `customer_loyalty` | Loyalty program data |
| `customer_communication_logs` | Email/SMS history |
| `user_profiles` | Auth user extended profiles |
| `user_roles` | Permission levels |

#### 4. **Analytics & Reporting**
| Table Name | Purpose |
|------------|---------|
| `analytics_sessions` | Website session tracking |
| `analytics_page_views` | Page view metrics |
| `analytics_conversions` | Conversion events |
| `analytics_daily_summary` | Daily aggregated stats |
| `analytics_product_performance` | Per-product metrics |
| `kct_analytics` | Custom KCT metrics |
| `ai_recommendation_analytics` | AI recommendation performance |

#### 5. **AI & Personalization**
| Table Name | Purpose |
|------------|---------|
| `ai_style_memory` | User style preferences |
| `ai_product_matches` | AI-suggested product matches |
| `ai_outfit_combinations` | Outfit recommendation data |
| `ai_search_queries` | Natural language search logs |
| `ai_personalization_insights` | User behavior insights |
| `ai_style_recommendations` | Generated style advice |
| `chat_history` | Chatbot conversation logs |
| `chat_contexts` | Active chat session context |

#### 6. **Wedding Management** (Major Feature)
| Table Name | Purpose |
|------------|---------|
| `weddings` | Wedding event registrations |
| `wedding_orders` | Wedding-specific orders |
| `wedding_party_members` | Groomsmen/party members |
| `wedding_invitations` | Digital invitation tracking |
| `wedding_measurements` | Party member measurements |
| `wedding_outfits` | Selected outfits per member |
| `wedding_payments` | Payment tracking |
| `groomsmen` | Groomsmen profiles |

#### 7. **Admin & Operations**
| Table Name | Purpose |
|------------|---------|
| `admin_users` | Admin user accounts |
| `admin_sessions` | Admin login sessions |
| `admin_notifications` | Admin alerts/notifications |
| `admin_notification_preferences` | Notification settings |
| `admin_2fa_settings` | Two-factor auth config |

#### 8. **Marketing & Discounts**
| Table Name | Purpose |
|------------|---------|
| `discount_codes` | Promo codes |
| `marketing_campaigns` | Campaign management |
| `email_campaigns` | Email marketing |
| `email_templates` | Email template library |
| `cart_recovery_campaigns` | Abandoned cart recovery |
| `abandoned_carts` | Tracked abandoned carts |

---

## Existing Edge Functions

### Product-Related Functions

| Function Name | Purpose | API Used |
|---------------|---------|----------|
| `products-catalog` | Fetch all products with filtering | Shopify Storefront |
| `shopify-products-admin` | Product management (list, archive, update tags, upload images) | Shopify Admin |
| `categorize-products` | AI-powered product categorization | OpenAI |
| `get-product-by-handle` | Fetch single product | Shopify Storefront |
| `fetch-shopify-collection` | Fetch collection products | Shopify Storefront |

### AI/Recommendation Functions

| Function Name | Purpose |
|---------------|---------|
| `ai-style-assistant` | Conversational style recommendations |
| `ai-personalization-engine` | User preference learning |
| `ai-size-recommendation` | Size suggestions based on measurements |
| `kct-recommendations` | Product recommendations |
| `suit-recommendations` | Suit-specific suggestions |
| `shirt-recommendations` | Shirt-specific suggestions |
| `tie-recommendations` | Tie-specific suggestions |
| `generate-coordinated-outfits` | Full outfit generation |
| `wedding-outfit-recommendations` | Wedding-specific suggestions |

### Order & Communication Functions

| Function Name | Purpose |
|---------------|---------|
| `send-confirmation-email` | Order confirmation |
| `send-cart-recovery-email` | Abandoned cart emails |
| `send-pickup-ready-email` | Pickup notifications |
| `cart-recovery-automation` | Automated recovery workflow |
| `send-wedding-invitation` | Wedding party invites |
| `send-measurement-reminder` | Measurement request reminders |

### Checkout Functions

| Function Name | Purpose |
|---------------|---------|
| `create-bundle-checkout` | Bundle purchase checkout |
| `create-wedding-checkout` | Wedding order checkout |
| `stripe-wedding-webhook` | Payment webhook handling |

---

## Existing Admin Tools (DO NOT REPLACE)

### Current Admin Pages in Main App

| Route | File | Purpose |
|-------|------|---------|
| `/admin/product-review` | `src/pages/admin/ProductReview.tsx` | Product categorization, image upload, archiving |
| `/admin/product-categorization` | `src/pages/admin/ProductCategorization.tsx` | AI-powered product tagging |
| `/admin/bundle-component-manager` | `src/pages/admin/BundleComponentManager.tsx` | Bundle image management |
| `/admin/blog-admin` | `src/pages/admin/BlogAdmin.tsx` | Blog content management |
| `/admin/site-enhancements` | `src/pages/admin/SiteEnhancements.tsx` | Site configuration |
| `/admin/wedding-orders` | `src/pages/admin/WeddingOrdersAdmin.tsx` | Wedding order management |
| `/admin/dashboard` | `src/pages/admin/AdminDashboard.tsx` | Overview dashboard |
| `/admin/weddings` | `src/pages/admin/AdminWeddings.tsx` | Wedding management |
| `/admin/coordinators` | `src/pages/admin/AdminCoordinators.tsx` | Coordinator management |
| `/admin/payments` | `src/pages/admin/AdminPayments.tsx` | Payment tracking |
| `/admin/scheduling` | `src/pages/admin/AdminScheduling.tsx` | Appointment scheduling |
| `/account/admin` | `src/pages/account/AccountAdmin.tsx` | Admin account dashboard |

### Existing Admin Components

| Component | File | Purpose |
|-----------|------|---------|
| `ProductReviewCard` | `src/components/admin/ProductReviewCard.tsx` | Product card with status controls |
| `ImageUploadModal` | `src/components/admin/ImageUploadModal.tsx` | Image upload interface |

---

## Shopify Admin API Integration (Existing)

### Edge Function: `shopify-products-admin`

**Location:** `supabase/functions/shopify-products-admin/index.ts`

**Available Actions:**

```typescript
// 1. List all products (with pagination)
{ action: 'list' }
// Returns: { products: [...], totalCount: number }

// 2. Archive a product
{ action: 'archive', productId: string }

// 3. Update product tags
{ action: 'update-tags', productId: string, tags: string[] }

// 4. Upload new product image
{ action: 'upload-image', productId: string, image: string } // base64

// 5. Bulk update tags
{ action: 'bulk-update-tags', productIds: string[], tag: string, addTag: boolean }
```

**Required Secret:** `SHOPIFY_ADMIN_TOKEN`

---

## Product Data Structure

### From Shopify (via `shopify-products-admin`)

```typescript
interface ShopifyProduct {
  id: string;
  handle: string;
  title: string;
  productType: string;
  createdAt: string;
  updatedAt: string;
  status: 'active' | 'archived' | 'draft';
  tags: string[];
  images: Array<{
    url: string;
    alt: string | null;
  }>;
}
```

### From Products Catalog (via `products-catalog`)

```typescript
interface ProductCatalogItem {
  id: string;
  title: string;
  handle: string;
  url: string;
  description: string;
  price: number;
  compareAtPrice?: number;
  image: string;
  category: string;
  tags: string[];
  inStock: boolean;
  colors?: string[];
  sizes?: string[];
}
```

---

## Key Database Functions (RPC)

The Supabase database includes numerous stored procedures. Key ones:

| Function | Purpose |
|----------|---------|
| `setup_initial_admin` | Grant admin privileges to a user |
| `get_order_management_dashboard` | Aggregated order data view |
| `calculate_customer_lifetime_value` | LTV calculation |
| `update_inventory_on_order` | Stock level updates |

---

## Authentication & Authorization

### User Roles System

```typescript
// user_roles table
interface UserRole {
  id: string;
  user_id: string;
  role: 'admin' | 'coordinator' | 'wedding_party' | 'customer';
  permissions: Json;
  created_at: string;
}
```

### Admin Detection Hook (Existing)

```typescript
// src/hooks/useUserRole.ts
export function useUserRole() {
  // Returns { isAdmin, isLoading }
}
```

---

## Recommended Features for KCT Atelier Admin

Based on the existing infrastructure, here are the modules to build:

### 1. **Product Command Center**
- Visual product grid with all 872+ products
- Quick status changes (active/draft/archived)
- Bulk operations (tag, categorize, price update)
- AI-powered product description enhancement
- Image gallery management
- SEO metadata editor

### 2. **Inventory Intelligence**
- Real-time stock levels (use `inventory_variants` table)
- Low stock alerts dashboard
- Reorder recommendations
- Stock movement history
- Reserve tracking

### 3. **Order Operations Hub**
- Unified order view (regular + wedding + custom)
- Status workflow management
- Priority queue visualization
- Exception handling
- Fulfillment tracking
- Return/refund processing

### 4. **Customer Insights**
- Customer segmentation dashboard
- Lifetime value analytics
- Purchase history
- Communication log
- VIP customer management

### 5. **Analytics Dashboard**
- Sales performance charts
- Product performance metrics
- Conversion funnel visualization
- AI recommendation effectiveness
- Search query analysis

### 6. **Wedding Management**
- Wedding calendar view
- Party member status tracking
- Measurement collection progress
- Payment status overview
- Outfit coordination tools

### 7. **Marketing Control**
- Discount code management
- Email campaign builder
- Abandoned cart recovery stats
- A/B test results

---

## API Endpoints Available

### Supabase REST API
All tables are accessible via:
```
https://gvcswimqaxvylgxbklbz.supabase.co/rest/v1/{table_name}
```

### Edge Functions
```
https://gvcswimqaxvylgxbklbz.supabase.co/functions/v1/{function_name}
```

---

## Environment Variables / Secrets

### Required Secrets (Already Configured)
| Secret Name | Purpose |
|-------------|---------|
| `SHOPIFY_ADMIN_TOKEN` | Shopify Admin API access |
| `SHOPIFY_STOREFRONT_TOKEN` | Shopify Storefront API |
| `OPENAI_API_KEY` | AI features |
| `RESEND_API_KEY` | Email sending |
| `STRIPE_SECRET_KEY` | Payment processing |

---

## Technology Stack Compatibility

### Main App Stack (for reference)
- React 18
- TypeScript
- Tailwind CSS
- Vite
- Supabase Client SDK
- TanStack Query

### Atelier Admin Can Use
- Any frontend framework (React recommended for consistency)
- Direct Supabase SDK connection
- Same Edge Functions
- Shared database access

---

## Critical Guidelines

### 1. **Data Source of Truth**
- **Products:** Shopify is the source of truth
- **Orders:** Supabase `orders` table
- **Customers:** Supabase `customers` table
- **Inventory:** Supabase inventory tables (synced from Shopify)

### 2. **Do NOT Duplicate**
- Don't create a separate product database - use Shopify + existing caching
- Don't duplicate the edge functions - call the existing ones
- Don't recreate the auth system - use existing Supabase auth

### 3. **Integration Points**
- Use existing `shopify-products-admin` for all product operations
- Use existing analytics tables for dashboards
- Use existing order tables for order management

### 4. **Permissions**
- Check `admin_users` table for admin status
- Use existing `user_roles` for authorization
- Respect existing RLS policies

---

## Sample Queries

### Get All Active Products
```sql
SELECT * FROM products WHERE status = 'active';
```

### Get Today's Orders
```sql
SELECT * FROM orders 
WHERE created_at >= CURRENT_DATE 
ORDER BY created_at DESC;
```

### Get Low Stock Inventory
```sql
SELECT * FROM inventory_alerts 
WHERE alert_type = 'low_stock' 
AND resolved_at IS NULL;
```

### Get Customer Segments
```sql
SELECT s.*, COUNT(m.customer_id) as member_count
FROM customer_segments s
LEFT JOIN customer_segment_members m ON m.segment_id = s.id
GROUP BY s.id;
```

### Get Wedding Statistics
```sql
SELECT 
  COUNT(*) as total_weddings,
  COUNT(CASE WHEN status = 'active' THEN 1 END) as active,
  SUM(deposit_amount) as total_deposits
FROM weddings;
```

---

## Helpful Links

- **Supabase Dashboard:** https://supabase.com/dashboard/project/gvcswimqaxvylgxbklbz
- **Edge Functions:** https://supabase.com/dashboard/project/gvcswimqaxvylgxbklbz/functions
- **SQL Editor:** https://supabase.com/dashboard/project/gvcswimqaxvylgxbklbz/sql/new
- **Storage:** https://supabase.com/dashboard/project/gvcswimqaxvylgxbklbz/storage/buckets

---

## Next Steps for Development

1. **Set up Atelier Admin project** with Supabase client connected
2. **Implement authentication** using existing admin_users table
3. **Build Product Dashboard** using `shopify-products-admin` edge function
4. **Create Order Management** views using existing order tables
5. **Add Analytics Charts** using existing analytics tables
6. **Implement Customer CRM** using customers and segments tables

---

## Questions to Clarify

1. Will Atelier Admin be a separate deployed app or a new section within the existing app?
2. What authentication flow should it use? (Same Supabase auth or separate admin auth?)
3. Should it have real-time updates via Supabase subscriptions?
4. Are there specific KPIs or reports that are highest priority?
5. Should it integrate with the existing wedding management or focus on retail?

---

*Document created: December 2024*
*Last updated: Auto-generated from KCT Menswear codebase analysis*
