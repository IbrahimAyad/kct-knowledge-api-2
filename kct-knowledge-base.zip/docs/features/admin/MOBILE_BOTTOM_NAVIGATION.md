# Mobile Bottom Navigation & FAB System

## Overview

The King's Court Tailors mobile navigation system provides intuitive bottom-tab navigation and a floating action button (FAB) system optimized for touch devices. It includes:
1. **Main App Navigation** (`MobileBottomNav.tsx`) - Primary site-wide navigation
2. **Wedding Hub Navigation** (`wedding/MobileBottomNav.tsx`) - Context-specific wedding management navigation
3. **Atelier FAB** (`fab/AtelierFAB.tsx`) - Floating action button for AI services

---

## Atelier FAB (Floating Action Button)

### Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                    Atelier FAB System                            │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │              FloatingActionMenu.tsx                       │   │
│  │                                                           │   │
│  │                    ┌─────────┐                            │   │
│  │                    │ Voice   │ ← Burgundy glow            │   │
│  │                    │   AI    │                            │   │
│  │                    └─────────┘                            │   │
│  │                    ┌─────────┐                            │   │
│  │                    │ Style   │ ← Shiny black              │   │
│  │                    │Assistant│                            │   │
│  │                    └─────────┘                            │   │
│  │                    ┌─────────┐                            │   │
│  │                    │ Size    │ ← Midnight navy            │   │
│  │                    │  Bot    │                            │   │
│  │                    └─────────┘                            │   │
│  │                    ┌─────────┐                            │   │
│  │                    │ Needle  │ ← Main trigger (rotates)   │   │
│  │                    │ Thread  │                            │   │
│  │                    └─────────┘                            │   │
│  └──────────────────────────────────────────────────────────┘   │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

### Components

| File | Purpose |
|------|---------|
| `src/components/fab/FloatingActionMenu.tsx` | Core FAB with custom SVG icons |
| `src/components/fab/AtelierFAB.tsx` | Integration wrapper with modals |
| `src/components/fab/index.ts` | Barrel exports |

### Custom SVG Icons

| Icon | Component | Design |
|------|-----------|--------|
| Needle & Thread | `NeedleIcon` | Burgundy background, gold thread, silver needle, AI sparkles |
| Voice AI | `VoiceAIIcon` | Burgundy background, white microphone, pulsing gold sound waves |
| Style Assistant | `StyleAssistantIcon` | Shiny black background, white suit, gold lapels, magic wand |
| Size Bot | `SizeBotIcon` | Midnight navy background, gold measuring tape, platinum figure |

### Props

```typescript
interface FloatingActionMenuProps {
  onVoiceClick?: () => void;    // Opens Voice AI modal
  onStyleClick?: () => void;    // Opens Style Assistant
  onSizeClick?: () => void;     // Opens Size Guide
  className?: string;           // Additional styling
}
```

### Animation Details

```typescript
// Menu item stagger animation
const itemVariants = {
  closed: { opacity: 0, y: 20, scale: 0.8 },
  open: (i: number) => ({
    opacity: 1,
    y: 0,
    scale: 1,
    transition: {
      delay: i * 0.08,           // Staggered entrance
      type: 'spring' as const,
      stiffness: 400,
      damping: 25
    }
  })
};

// Main button rotation on open
animate={{ 
  rotate: isOpen ? 135 : 0,    // Rotates to X pattern
  scale: isOpen ? 1.05 : 1
}}
```

### Color Palette

| Element | Color | CSS |
|---------|-------|-----|
| Burgundy | `#9B2D3F` → `#6B1D28` | `linear-gradient(...)` |
| Gold | `#F5E6D3` → `#D4AF37` → `#B8860B` | Thread, accents |
| Shiny Black | `#3a3a3a` → `#0a0a0a` | Style Assistant bg |
| Midnight Navy | `#1E3A5F` → `#0A1628` | Size Bot bg |
| Silver | `#FFFFFF` → `#C0C0C0` | Needle, platinum |

### Usage

```tsx
import { AtelierFAB } from '@/components/fab';

// In your layout:
function App() {
  return (
    <>
      <MainContent />
      <AtelierFAB />  {/* Auto-handles all modals */}
    </>
  );
}

// Or use the raw FAB with custom handlers:
import { FloatingActionMenu } from '@/components/fab';

function CustomImplementation() {
  return (
    <FloatingActionMenu
      onVoiceClick={() => console.log('Voice clicked')}
      onStyleClick={() => console.log('Style clicked')}
      onSizeClick={() => console.log('Size clicked')}
    />
  );
}
```

---

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                      Mobile Bottom Navigation                    │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │                  MobileBottomNav.tsx                      │   │
│  │  (Main App - E-commerce focused)                          │   │
│  │                                                           │   │
│  │  [Home] [Bundle*] [Cart] [Wedding] [Atelier]              │   │
│  │                           ▲                                │   │
│  │                           │                                │   │
│  │                    ┌──────┴──────┐                         │   │
│  │                    │ Atelier Menu│                         │   │
│  │                    ├─────────────┤                         │   │
│  │                    │ • Live Chat │                         │   │
│  │                    │ • AI Style  │                         │   │
│  │                    │ • Size Guide│                         │   │
│  │                    └─────────────┘                         │   │
│  └──────────────────────────────────────────────────────────┘   │
│                                                                  │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │           wedding/MobileBottomNav.tsx                     │   │
│  │  (Wedding Hub - Role-based navigation)                    │   │
│  │                                                           │   │
│  │  Coordinator: [Home] [Outfit] [Party] [Account]           │   │
│  │  Member:      [Home] [Outfit] [Sizes*] [Account]          │   │
│  │                                                           │   │
│  │  * = Highlighted/Action items                             │   │
│  └──────────────────────────────────────────────────────────┘   │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

---

## Component Details

### 1. Main App Navigation (`src/components/MobileBottomNav.tsx`)

#### Purpose
Primary navigation for the e-commerce experience with integrated Atelier services.

#### Features
- **5 Navigation Items**: Home, Bundle, Cart, Wedding, Atelier
- **Cart Badge**: Shows item count
- **Highlighted Items**: Bundle tab with special styling
- **Atelier Expandable Menu**: Floating action buttons for services
- **Conditional Display**: Hidden on desktop, auth, checkout, and bundle builder pages

#### State Management
```typescript
const [isAtelierOpen, setIsAtelierOpen] = useState(false);
const [isSizeGuideOpen, setIsSizeGuideOpen] = useState(false);
const [isAIAssistantOpen, setIsAIAssistantOpen] = useState(false);
const [isLiveChatOpen, setIsLiveChatOpen] = useState(false);
```

#### Navigation Items Structure
```typescript
interface NavItem {
  icon: LucideIcon;
  label: string;
  path?: string;        // Route navigation
  action?: () => void;  // Custom action (e.g., open cart)
  badge?: number;       // Notification count
  highlight?: boolean;  // Special styling
}

const navItems = [
  { icon: Home, label: 'Home', path: '/' },
  { icon: Sparkles, label: 'Bundle', path: '/custom-bundle', highlight: true },
  { icon: ShoppingBag, label: 'Cart', action: openCart, badge: totalItems },
  { icon: Heart, label: 'Wedding', path: '/wedding-hub' },
];
```

#### Atelier Actions Structure
```typescript
interface AtelierAction {
  id: string;
  icon: LucideIcon;
  label: string;
  gradient: string;  // Background gradient class
}

const atelierActions = [
  { id: 'liveChat', icon: Headphones, label: 'Atelier', gradient: 'bg-[hsl(0_72%_30%)]' },
  { id: 'aiAssistant', icon: Sparkles, label: 'Style Help', gradient: 'bg-gradient-to-br from-[hsl(280_70%_50%)] to-[hsl(260_70%_40%)]' },
  { id: 'sizeGuide', icon: Ruler, label: 'Size Guide', gradient: 'bg-gradient-to-br from-[hsl(350_70%_50%)] to-[hsl(330_70%_40%)]' },
];
```

---

### 2. Wedding Hub Navigation (`src/components/wedding/MobileBottomNav.tsx`)

#### Purpose
Context-aware navigation for wedding party management with role-based items.

#### Props
```typescript
interface MobileBottomNavProps {
  activeTab: string;                 // Current active tab ID
  onTabChange: (tab: string) => void; // Tab change handler
  isCoordinator: boolean;            // Is user a coordinator?
  isMember: boolean;                 // Is user a party member?
  onShareCode?: () => void;          // Optional share action
  onQuickPayment?: () => void;       // Optional payment action
}
```

#### Role-Based Navigation
```typescript
// Coordinator sees management-focused items
const coordinatorItems: NavItem[] = [
  { id: 'overview', label: 'Outfit', icon: ShoppingBag },
  { id: 'party', label: 'Party', icon: Users },
];

// Members see task-focused items
const memberItems: NavItem[] = [
  { id: 'my-outfit', label: 'Outfit', icon: ShoppingBag },
  { id: 'measurements', label: 'Sizes', icon: Ruler, highlight: true },
];

// Fixed edge items (always present)
const allItems: NavItem[] = [
  { id: 'home', label: 'Home', icon: Home, onClick: () => navigate('/') },
  ...roleItems,
  { id: 'account', label: 'Account', icon: User, onClick: () => navigate('/account') },
];
```

---

## Design System

### Color Tokens

| Element | Token/Value | Purpose |
|---------|-------------|---------|
| Active State | `text-primary` | Selected tab text/icon |
| Inactive State | `text-muted-foreground` | Unselected tab |
| Background | `bg-background/98` | Nav bar background |
| Border | `border-border/50` | Top border |
| Highlight Pulse | `bg-primary` | Notification dot |
| Gold Accent | `#D4AF37` | Active state (main nav) |
| Burgundy Badge | `#8B1538` | Cart count badge |

### Spacing & Sizing

| Element | Value | Description |
|---------|-------|-------------|
| Nav Height | `h-16` / `h-[68px]` | Standard height |
| Icon Size | `h-5 w-5` | Navigation icons |
| Label Size | `text-[10px]` | Tab labels |
| Touch Target | `min-w-[60px]` | Minimum tap area |
| Active Scale | `scale-110` | Icon emphasis |
| Badge Size | `min-w-[16px] h-4` | Cart badge |

### Shadows & Effects

```css
/* Wedding nav enhanced shadow */
.nav-shadow {
  box-shadow: 0 -4px 20px rgba(0,0,0,0.08);
}

/* Atelier floating buttons */
.atelier-button {
  box-shadow: 0 10px 25px -5px rgba(0,0,0,0.25);
}
```

### Animation Classes

```typescript
// Atelier menu entrance
className="animate-in fade-in slide-in-from-bottom-4 duration-200"

// Active icon scale
className="transition-all scale-110"

// Highlight pulse
className="animate-pulse"

// Touch feedback
className="active:scale-90 touch-manipulation"
```

---

## Customization Guide

### Adding a New Navigation Item

```typescript
// 1. Add to navItems array
const navItems = [
  { icon: Home, label: 'Home', path: '/' },
  { icon: Sparkles, label: 'Bundle', path: '/custom-bundle', highlight: true },
  { icon: ShoppingBag, label: 'Cart', action: openCart, badge: totalItems },
  { icon: Heart, label: 'Wedding', path: '/wedding-hub' },
  { 
    icon: YourIcon, 
    label: 'New Tab', 
    path: '/new-route',
    highlight: false,  // Set true for special emphasis
    badge: undefined   // Or a number for notifications
  },
];
```

### Creating a New Action Button (Atelier Style)

```typescript
const atelierActions = [
  { id: 'liveChat', icon: Headphones, label: 'Atelier', gradient: 'bg-[hsl(0_72%_30%)]' },
  { id: 'aiAssistant', icon: Sparkles, label: 'Style Help', gradient: 'bg-gradient-to-br from-[hsl(280_70%_50%)] to-[hsl(260_70%_40%)]' },
  { id: 'sizeGuide', icon: Ruler, label: 'Size Guide', gradient: 'bg-gradient-to-br from-[hsl(350_70%_50%)] to-[hsl(330_70%_40%)]' },
  {
    id: 'newFeature',
    icon: NewIcon,
    label: 'Feature Name',
    gradient: 'bg-gradient-to-br from-[hsl(200_70%_50%)] to-[hsl(180_70%_40%)]'
  },
];

// Add handler
const handleAtelierAction = (action: string) => {
  switch (action) {
    case 'liveChat':
      setIsLiveChatOpen(true);
      setIsAtelierOpen(false);
      break;
    case 'aiAssistant':
      setIsAIAssistantOpen(true);
      setIsAtelierOpen(false);
      break;
    case 'sizeGuide':
      setIsSizeGuideOpen(true);
      setIsAtelierOpen(false);
      break;
    case 'newFeature':
      // Handle new feature
      break;
  }
};
```

### Customizing Active States

```typescript
// Main nav - Gold accent
const activeClass = active 
  ? 'text-[#D4AF37]' 
  : 'text-gray-500';

// Wedding nav - Primary color
const activeClass = isActive 
  ? 'text-primary' 
  : 'text-muted-foreground';
```

---

## Alternative UI Designs

### Design A: Floating Pill Navigation

```
┌─────────────────────────────────────────────────────────────────┐
│                                                                  │
│                                                                  │
│                                                                  │
│     ╭──────────────────────────────────────────────────────╮    │
│     │  ○ Home   ◆ Bundle   ○ Cart   ○ Wedding   ○ Atelier  │    │
│     ╰──────────────────────────────────────────────────────╯    │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘

Styling:
- Rounded pill shape with blur backdrop
- Floating above content (bottom: 20px)
- Centered with max-width
- Active item fills with primary color
```

```typescript
// Floating pill implementation
<nav className="fixed bottom-5 left-1/2 -translate-x-1/2 z-50 
  bg-background/90 backdrop-blur-xl rounded-full 
  border border-border/50 shadow-lg px-4 py-2">
  <div className="flex items-center gap-4">
    {navItems.map(item => (
      <button className={cn(
        "flex items-center gap-2 px-4 py-2 rounded-full transition-all",
        isActive ? "bg-primary text-primary-foreground" : "text-muted-foreground"
      )}>
        <Icon className="h-4 w-4" />
        {isActive && <span className="text-sm font-medium">{label}</span>}
      </button>
    ))}
  </div>
</nav>
```

### Design B: Dock-Style Navigation

```
┌─────────────────────────────────────────────────────────────────┐
│                                                                  │
│                                                                  │
│                                                                  │
│  ┌───────────────────────────────────────────────────────────┐  │
│  │                                                            │  │
│  │    ┌──┐    ┌──┐    ┌────┐    ┌──┐    ┌──┐                │  │
│  │    │🏠│    │✨│    │🛒 │    │💒│    │💬│                │  │
│  │    └──┘    └──┘    └────┘    └──┘    └──┘                │  │
│  │   Home   Bundle   CART    Wedding  Atelier               │  │
│  │                   ▲                                       │  │
│  │            (larger/elevated)                              │  │
│  └───────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────┘

Features:
- Center item (Cart) is elevated and larger
- Glass morphism background
- Items "grow" on hover/active
```

```typescript
// Dock-style with elevated center
<nav className="fixed bottom-0 inset-x-0 z-50">
  <div className="flex items-end justify-around pb-4 pt-2 
    bg-gradient-to-t from-background via-background/95 to-transparent">
    {navItems.map((item, index) => {
      const isCenterItem = index === Math.floor(navItems.length / 2);
      return (
        <button className={cn(
          "flex flex-col items-center transition-all",
          isCenterItem && "transform -translate-y-3 scale-110",
          isCenterItem && "bg-primary text-primary-foreground rounded-2xl p-3"
        )}>
          <Icon className={cn("h-5 w-5", isCenterItem && "h-6 w-6")} />
          <span className="text-[10px] mt-1">{label}</span>
        </button>
      );
    })}
  </div>
</nav>
```

### Design C: Minimal Line Navigation

```
┌─────────────────────────────────────────────────────────────────┐
│                                                                  │
│  ═══════════════════════════════════════════════════════════════│
│                      ▲                                           │
│                 (active indicator line)                          │
│                                                                  │
│     🏠        ✨        🛒        💒        💬                 │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘

Features:
- Icons only (labels appear on active)
- Sliding indicator line above active item
- Ultra-minimal aesthetic
```

```typescript
// Minimal with sliding indicator
<nav className="fixed bottom-0 inset-x-0 z-50 bg-background">
  {/* Sliding indicator */}
  <div 
    className="absolute top-0 h-0.5 bg-primary transition-all duration-300"
    style={{ 
      width: `${100 / navItems.length}%`,
      left: `${activeIndex * (100 / navItems.length)}%`
    }}
  />
  
  <div className="flex justify-around py-4">
    {navItems.map(item => (
      <button className="flex flex-col items-center gap-1">
        <Icon className={cn("h-5 w-5", isActive && "text-primary")} />
        <span className={cn(
          "text-[10px] transition-all",
          isActive ? "opacity-100 h-4" : "opacity-0 h-0"
        )}>
          {label}
        </span>
      </button>
    ))}
  </div>
</nav>
```

### Design D: Segmented Control Style

```
┌─────────────────────────────────────────────────────────────────┐
│                                                                  │
│  ┌─────────────────────────────────────────────────────────────┐│
│  │╔═══════════╗                                                 ││
│  ││   Home    │  Bundle  │  Cart  │ Wedding │ Atelier          ││
│  │╚═══════════╝                                                 ││
│  └─────────────────────────────────────────────────────────────┘│
│                                                                  │
└─────────────────────────────────────────────────────────────────┘

Features:
- iOS-style segmented control
- Active segment has filled background
- Smooth sliding animation
```

---

## Safe Area Handling

### iOS Safe Area
```css
/* Add bottom padding for home indicator */
.safe-area-bottom {
  padding-bottom: env(safe-area-inset-bottom);
}

/* Alternative with Tailwind */
.nav-container {
  @apply pb-[env(safe-area-inset-bottom)];
}
```

### Implementation
```typescript
<nav className="fixed bottom-0 left-0 right-0 z-50 
  bg-background border-t border-border 
  safe-area-inset-bottom">
  {/* Navigation content */}
</nav>
```

---

## Accessibility

### Touch Targets
```typescript
// Minimum 44x44px touch targets
<button className="min-w-[60px] min-h-[44px] ...">
```

### Screen Readers
```typescript
<button aria-label={`Navigate to ${label}`} aria-current={isActive ? 'page' : undefined}>
```

### Reduced Motion
```css
@media (prefers-reduced-motion: reduce) {
  .animate-pulse,
  .transition-all {
    animation: none;
    transition: none;
  }
}
```

---

## File Structure

```
src/
├── components/
│   ├── MobileBottomNav.tsx          # Main app navigation
│   ├── wedding/
│   │   └── MobileBottomNav.tsx      # Wedding hub navigation
│   └── mobile/
│       └── MobileOptimizedLayout.tsx # Full mobile layout wrapper
├── hooks/
│   └── use-mobile.tsx               # Mobile detection hook
└── contexts/
    └── CartContext.tsx              # Cart state (for badge)
```

---

## Integration Example

### App Layout Integration
```typescript
import { MobileBottomNav } from '@/components/MobileBottomNav';

function AppLayout({ children }) {
  return (
    <div className="min-h-screen pb-16 md:pb-0"> {/* Space for nav */}
      {children}
      <MobileBottomNav />
    </div>
  );
}
```

### Wedding Hub Integration
```typescript
import { MobileBottomNav } from '@/components/wedding/MobileBottomNav';

function WeddingHub() {
  const [activeTab, setActiveTab] = useState('overview');
  
  return (
    <div className="min-h-screen pb-20"> {/* Extra padding for taller nav */}
      <TabContent activeTab={activeTab} />
      <MobileBottomNav
        activeTab={activeTab}
        onTabChange={setActiveTab}
        isCoordinator={userIsCoordinator}
        isMember={userIsMember}
      />
    </div>
  );
}
```

---

## Dependencies

| Package | Version | Purpose |
|---------|---------|---------|
| `lucide-react` | ^0.462.0 | Icon library |
| `react-router-dom` | ^6.26.2 | Navigation routing |
| `tailwind-merge` | ^2.5.2 | Class merging |
| `clsx` | ^2.1.1 | Conditional classes |

---

## Best Practices

1. **Always provide bottom padding** on page content to prevent nav overlap
2. **Use `touch-manipulation`** for better touch response
3. **Implement `safe-area-inset-bottom`** for iOS devices
4. **Hide on desktop** using responsive classes or window width check
5. **Exclude from certain pages** (auth, checkout) where navigation isn't needed
6. **Keep to 4-5 items max** for comfortable touch targets
7. **Use semantic color tokens** from design system
8. **Add active state feedback** (scale, color, indicator)
