# Admin Product Review System

## Overview

The Admin Product Review page (`/admin/product-review`) provides a centralized interface for managing the Shopify product catalog. It allows administrators to categorize products, upload new images, and archive outdated items directly to Shopify.

## Features

### 1. Product Categorization
Products can be assigned one of three review statuses:
- **New** (Green) - New stock or brand new items, displayed with highest priority in storefront
- **Neutral** (Gray) - Standard products, normal display priority
- **Archive** (Red) - Products to be removed from Shopify, hidden from customers

### 2. Product Image Management
- Upload new main product images directly through the admin interface
- Images are saved directly to Shopify Admin API
- Supports drag-and-drop and file selection
- Preview before upload

### 3. Bulk Operations
- Save all changes at once (categorization + image uploads + archiving)
- Progress feedback with success/error counts
- Detailed error reporting for failed operations

### 4. Duplicate Detection
- Automatically identifies products with identical titles
- Displays orange "Duplicate" badge with count
- Shows product handle to distinguish between similar products
- Helps identify true duplicates vs. variant naming issues

### 5. Search & Sort
- Search by product title or handle
- Sort alphabetically (A-Z or Z-A)
- Filter results in real-time

## Technical Implementation

### Files
- `src/pages/admin/ProductReview.tsx` - Main page component
- `src/components/admin/ProductReviewCard.tsx` - Individual product card
- `src/components/admin/ImageUploadModal.tsx` - Image upload modal
- `supabase/functions/shopify-products-admin/index.ts` - Edge function for Shopify Admin API

### Shopify Admin API Integration
The `shopify-products-admin` edge function handles:

#### Product Listing (`action: 'list'`)
- Fetches ALL active products from Shopify (not just first 250)
- Implements proper pagination using Shopify's `Link` header
- De-duplicates products by ID to prevent duplicate entries
- Transforms product data for frontend consumption

#### Product Archiving (`action: 'archive'`)
- Archives products by setting `status: 'archived'` via PUT request
- Archived products are hidden from storefront

#### Tag Updates (`action: 'updateTags'`)
- Updates product tags for categorization tracking

#### Image Upload (`action: 'uploadImage'`)
- Uploads base64 image data to product
- Sets new image as the main product image

### Pagination Fix (December 2024)
**Problem:** Shopify API returns max 250 products per request. Initial implementation was showing duplicate products due to incorrect pagination handling.

**Solution:**
1. Parse `Link` header to only follow `rel="next"` links
2. Track seen product IDs to prevent duplicates
3. Continue fetching until no more `next` link exists

```typescript
// Correct pagination - only follow "next" links
function getNextPageInfo(linkHeader: string | null): string | null {
  if (!linkHeader) return null;
  const nextMatch = linkHeader.match(/<[^>]*page_info=([^>&]+)[^>]*>;\s*rel="next"/);
  return nextMatch ? nextMatch[1] : null;
}
```

### De-duplication
Products are de-duplicated by ID after fetching to ensure each product appears only once, even if Shopify returns duplicates across paginated requests.

## Product Count Reference
- **Total Products:** ~872 (as of December 2024)
- Products are fetched from Shopify in real-time (not cached in database)
- Shopify remains the source of truth for product data

## Usage

1. Navigate to `/admin/product-review`
2. Products load automatically from Shopify
3. Click status buttons (New/Neutral/Archive) to categorize
4. Click product image to upload a new main image
5. Click "Save All Changes" to sync to Shopify
6. Review success/error feedback

## Related Systems

### Storefront Product Display
The main store uses `supabase/functions/products-catalog/index.ts` which:
- Fetches products via Shopify Storefront API (GraphQL)
- Implements pagination for complete product listing
- Supports filtering by category, stock status
- Returns optimized data for chatbot recommendations

### Product Priority
Products marked as "New" should display first in:
- Product listings
- Search results
- Category pages

Products marked as "Archive" are:
- Hidden from Shopify storefront
- Not returned by products-catalog API
