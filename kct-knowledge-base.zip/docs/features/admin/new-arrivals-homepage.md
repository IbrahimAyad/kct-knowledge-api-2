# New Arrivals Homepage Section

## Overview

The New Arrivals section on the homepage displays products that have been tagged as "priority" in the Admin Product Review page. This creates a direct workflow from admin tagging to homepage display.

## Data Flow

```
Admin Product Review → Tag as "priority" → Shopify Tags API → Homepage Query → New Arrivals Grid
```

### Step-by-Step Process

1. **Admin tags product as "new"** in `/admin/product-review`
   - Admin sets `reviewStatus` to "new" for a product
   - This adds the `priority` tag to the product in Shopify

2. **Shopify stores the tag**
   - Tags are stored directly on the product in Shopify
   - The `shopify-products-admin` edge function handles tag updates

3. **Homepage fetches tagged products**
   - `NewArrivalsShowcase` component queries Shopify for products with `tag:priority`
   - Returns up to 20 products

4. **Products display in grid**
   - Products appear with "NEW" badge
   - Hover effect shows alternate image

## Component Location

**File:** `src/components/homepage/NewArrivalsShowcase.tsx`

## Key Code

### Fetching New Arrivals

```tsx
// src/components/homepage/NewArrivalsShowcase.tsx (line 56-58)
useEffect(() => {
  const fetchNewArrivals = async () => {
    const newProducts = await searchProducts('tag:priority', 20);
    setProducts(newProducts);
  };
  fetchNewArrivals();
}, []);
```

### Search Function

```tsx
// src/lib/shopify-collections.ts (line 140-145)
export async function searchProducts(query: string, count = 12) {
  const data = await shopifyFetch<any>({
    query: SEARCH_PRODUCTS,
    variables: { query, first: count }
  });
  // ... returns mapped products
}
```

### GraphQL Query

```graphql
# src/lib/shopify-collections.ts (line 89-138)
query SearchProducts($query: String!, $first: Int!) {
  products(first: $first, query: $query) {
    edges {
      node {
        id
        title
        handle
        productType
        tags
        priceRange { ... }
        images(first: 2) { ... }
        variants(first: 100) { ... }
      }
    }
  }
}
```

## Tag Mapping

| Admin Status | Shopify Tag | Displayed As |
|--------------|-------------|--------------|
| `new` | `priority` | New Arrivals |
| `approved` | `approved` | Standard product |
| `pending` | `pending` | Not displayed |
| `rejected` | `rejected` | Hidden |

## Visual Components

### Product Card
- **Image**: Primary with hover-to-secondary transition
- **Badge**: "NEW" badge (top-left, primary color)
- **Title**: White text on dark gradient overlay
- **Price**: Below title

### Grid Layout
```
Mobile: 2 columns
Tablet (md): 3 columns
Desktop (lg): 4 columns
```

## Dependencies

| Component/Library | Purpose |
|-------------------|---------|
| `shopify-collections.ts` | `searchProducts()` function |
| `shopify.ts` | `shopifyFetch()` for GraphQL |
| Shopify Storefront API | Product data source |

## Related Files

| File | Purpose |
|------|---------|
| `src/components/homepage/NewArrivalsShowcase.tsx` | Homepage display component |
| `src/lib/shopify-collections.ts` | Search products by tag |
| `src/lib/shopify.ts` | Shopify API connection |
| `supabase/functions/shopify-products-admin/index.ts` | Admin tag updates |
| `src/pages/admin/ProductReviewPage.tsx` | Admin review interface |

## Notes

- The `priority` tag (not `new`) is what triggers display in New Arrivals
- Maximum 20 products are fetched
- Products without images will show placeholder
- Tags are case-sensitive in Shopify queries
