# New to KCT Banner Section

## Overview

The "New to KCT?" banner is a homepage component designed to welcome new visitors and guide them toward creating an account or logging in.

## Component Location

**File:** `src/components/homepage/NewToKctBanner.tsx`

## Visual Elements

### Images
| Position | Source | Alt Text |
|----------|--------|----------|
| Left | `src/assets/new-to-kct-left.jpg` | "Stylish man in black suit" |
| Right | `src/assets/new-to-kct-right.jpg` | "Stylish man in cream suit" |

### Headline
- **Text:** "NEW TO KCT?"
- **Styling:** Large bold white text with drop shadow
- **Responsive sizes:** `text-3xl` → `sm:text-4xl` → `md:text-5xl` → `lg:text-6xl`

### Call to Action Button
- **Text:** "START HERE"
- **Destination:** `/auth` (authentication page)
- **Styling:** White background, black text, large padding with hover effect

## Technical Implementation

### Animation
- Wrapped in `AnimatedSection` component
- Fade-in + slide-up animation (`opacity-0 translate-y-10` → `opacity-1`)

### Responsive Layout
```
Height breakpoints:
- Mobile: base height
- sm: 600px
- md: 700px
```

### Component Structure
```tsx
<AnimatedSection>
  <div className="relative">
    {/* Left Image */}
    {/* Right Image */}
    {/* Overlay with headline + button */}
    <Link to="/auth">
      <Button>START HERE</Button>
    </Link>
  </div>
</AnimatedSection>
```

## Purpose

1. **Welcome new visitors** with visually engaging imagery
2. **Direct users to registration/login** via the auth page
3. **Establish brand identity** through curated suit imagery

## Dependencies

- `react-router-dom` (Link component)
- `@/components/ui/button` (Button component)
- `AnimatedSection` wrapper for entrance animation
