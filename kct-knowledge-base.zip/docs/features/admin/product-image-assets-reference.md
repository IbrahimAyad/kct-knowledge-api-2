# Product Image Assets Reference

Complete reference for all suit, shirt, tie component images and generated outfit sets.

---

## R2 Component Images (Individual Pieces)

**Base URL:** `https://pub-46371bda6faf4910b74631159fc2dfd4.r2.dev/kct-prodcuts/`

### Suits ✅ VERIFIED WORKING
**Pattern:** `suits/{color}/{color}-{piece}-main.jpg`

| Suit | URL |
|------|-----|
| Navy 3-Piece | `https://pub-46371bda6faf4910b74631159fc2dfd4.r2.dev/kct-prodcuts/suits/navy/navy-3-main.jpg` |
| Navy 2-Piece | `https://pub-46371bda6faf4910b74631159fc2dfd4.r2.dev/kct-prodcuts/suits/navy/navy-2-main.jpg` |
| Black 3-Piece | `https://pub-46371bda6faf4910b74631159fc2dfd4.r2.dev/kct-prodcuts/suits/black/black-3-main.jpg` |
| Charcoal 3-Piece | `https://pub-46371bda6faf4910b74631159fc2dfd4.r2.dev/kct-prodcuts/suits/charcoal/charcoal-3-main.jpg` |
| Light Grey 3-Piece | `https://pub-46371bda6faf4910b74631159fc2dfd4.r2.dev/kct-prodcuts/suits/light-grey/light-grey-3-main.jpg` |
| Tan 3-Piece | `https://pub-46371bda6faf4910b74631159fc2dfd4.r2.dev/kct-prodcuts/suits/tan/tan-3-main.jpg` |

**Note:** Folder names are lowercase. Use `{color}-2-main.jpg` for 2-piece, `{color}-3-main.jpg` for 3-piece.

### Shirts (17 options)
| Shirt | URL |
|-------|-----|
| White Shirt | `https://pub-46371bda6faf4910b74631159fc2dfd4.r2.dev/kct-prodcuts/Shirts/White-Shirt.png` |
| Ivory Shirt | `https://pub-46371bda6faf4910b74631159fc2dfd4.r2.dev/kct-prodcuts/Shirts/Ivory-Shirt.png` |
| Light Blue Shirt | `https://pub-46371bda6faf4910b74631159fc2dfd4.r2.dev/kct-prodcuts/Shirts/Light-Blue-Shirt.png` |
| Pink Shirt | `https://pub-46371bda6faf4910b74631159fc2dfd4.r2.dev/kct-prodcuts/Shirts/Pink-Shirt.png` |
| Lavender Shirt | `https://pub-46371bda6faf4910b74631159fc2dfd4.r2.dev/kct-prodcuts/Shirts/Lavender-Shirt.png` |
| Black Shirt | `https://pub-46371bda6faf4910b74631159fc2dfd4.r2.dev/kct-prodcuts/Shirts/Black-Shirt.png` |
| Navy Shirt | `https://pub-46371bda6faf4910b74631159fc2dfd4.r2.dev/kct-prodcuts/Shirts/Navy-Shirt.png` |
| Burgundy Shirt | `https://pub-46371bda6faf4910b74631159fc2dfd4.r2.dev/kct-prodcuts/Shirts/Burgundy-Shirt.png` |
| Grey Shirt | `https://pub-46371bda6faf4910b74631159fc2dfd4.r2.dev/kct-prodcuts/Shirts/Grey-Shirt.png` |
| Charcoal Shirt | `https://pub-46371bda6faf4910b74631159fc2dfd4.r2.dev/kct-prodcuts/Shirts/Charcoal-Shirt.png` |
| Sage Shirt | `https://pub-46371bda6faf4910b74631159fc2dfd4.r2.dev/kct-prodcuts/Shirts/Sage-Shirt.png` |
| Mint Shirt | `https://pub-46371bda6faf4910b74631159fc2dfd4.r2.dev/kct-prodcuts/Shirts/Mint-Shirt.png` |
| Peach Shirt | `https://pub-46371bda6faf4910b74631159fc2dfd4.r2.dev/kct-prodcuts/Shirts/Peach-Shirt.png` |
| Champagne Shirt | `https://pub-46371bda6faf4910b74631159fc2dfd4.r2.dev/kct-prodcuts/Shirts/Champagne-Shirt.png` |
| Dusty Blue Shirt | `https://pub-46371bda6faf4910b74631159fc2dfd4.r2.dev/kct-prodcuts/Shirts/Dusty-Blue-Shirt.png` |
| Dusty Rose Shirt | `https://pub-46371bda6faf4910b74631159fc2dfd4.r2.dev/kct-prodcuts/Shirts/Dusty-Rose-Shirt.png` |
| Cream Shirt | `https://pub-46371bda6faf4910b74631159fc2dfd4.r2.dev/kct-prodcuts/Shirts/Cream-Shirt.png` |

### Ties/Bowties (76 color options)
**Base URL:** `https://pub-46371bda6faf4910b74631159fc2dfd4.r2.dev/kct-prodcuts/Bow%3ATie/`

| Color | URL |
|-------|-----|
| Black | `https://pub-46371bda6faf4910b74631159fc2dfd4.r2.dev/kct-prodcuts/Bow%3ATie/Black.png` |
| Navy | `https://pub-46371bda6faf4910b74631159fc2dfd4.r2.dev/kct-prodcuts/Bow%3ATie/Navy.png` |
| Burgundy | `https://pub-46371bda6faf4910b74631159fc2dfd4.r2.dev/kct-prodcuts/Bow%3ATie/Burgundy.png` |
| White | `https://pub-46371bda6faf4910b74631159fc2dfd4.r2.dev/kct-prodcuts/Bow%3ATie/White.png` |
| Ivory | `https://pub-46371bda6faf4910b74631159fc2dfd4.r2.dev/kct-prodcuts/Bow%3ATie/Ivory.png` |
| Champagne | `https://pub-46371bda6faf4910b74631159fc2dfd4.r2.dev/kct-prodcuts/Bow%3ATie/Champagne.png` |
| Gold | `https://pub-46371bda6faf4910b74631159fc2dfd4.r2.dev/kct-prodcuts/Bow%3ATie/Gold.png` |
| Rose Gold | `https://pub-46371bda6faf4910b74631159fc2dfd4.r2.dev/kct-prodcuts/Bow%3ATie/Rose-Gold.png` |
| Dusty Rose | `https://pub-46371bda6faf4910b74631159fc2dfd4.r2.dev/kct-prodcuts/Bow%3ATie/Dusty-Rose.png` |
| Dusty Blue | `https://pub-46371bda6faf4910b74631159fc2dfd4.r2.dev/kct-prodcuts/Bow%3ATie/Dusty-Blue.png` |
| Sage | `https://pub-46371bda6faf4910b74631159fc2dfd4.r2.dev/kct-prodcuts/Bow%3ATie/Sage.png` |
| Eucalyptus | `https://pub-46371bda6faf4910b74631159fc2dfd4.r2.dev/kct-prodcuts/Bow%3ATie/Eucalyptus.png` |
| Hunter Green | `https://pub-46371bda6faf4910b74631159fc2dfd4.r2.dev/kct-prodcuts/Bow%3ATie/Hunter-Green.png` |
| Emerald | `https://pub-46371bda6faf4910b74631159fc2dfd4.r2.dev/kct-prodcuts/Bow%3ATie/Emerald.png` |
| Terracotta | `https://pub-46371bda6faf4910b74631159fc2dfd4.r2.dev/kct-prodcuts/Bow%3ATie/Terracotta.png` |
| Rust | `https://pub-46371bda6faf4910b74631159fc2dfd4.r2.dev/kct-prodcuts/Bow%3ATie/Rust.png` |
| Burnt Orange | `https://pub-46371bda6faf4910b74631159fc2dfd4.r2.dev/kct-prodcuts/Bow%3ATie/Burnt-Orange.png` |
| Coral | `https://pub-46371bda6faf4910b74631159fc2dfd4.r2.dev/kct-prodcuts/Bow%3ATie/Coral.png` |
| Blush | `https://pub-46371bda6faf4910b74631159fc2dfd4.r2.dev/kct-prodcuts/Bow%3ATie/Blush.png` |
| Mauve | `https://pub-46371bda6faf4910b74631159fc2dfd4.r2.dev/kct-prodcuts/Bow%3ATie/Mauve.png` |
| Lavender | `https://pub-46371bda6faf4910b74631159fc2dfd4.r2.dev/kct-prodcuts/Bow%3ATie/Lavender.png` |
| Plum | `https://pub-46371bda6faf4910b74631159fc2dfd4.r2.dev/kct-prodcuts/Bow%3ATie/Plum.png` |
| Purple | `https://pub-46371bda6faf4910b74631159fc2dfd4.r2.dev/kct-prodcuts/Bow%3ATie/Purple.png` |
| Royal Blue | `https://pub-46371bda6faf4910b74631159fc2dfd4.r2.dev/kct-prodcuts/Bow%3ATie/Royal-Blue.png` |
| Light Blue | `https://pub-46371bda6faf4910b74631159fc2dfd4.r2.dev/kct-prodcuts/Bow%3ATie/Light-Blue.png` |
| Teal | `https://pub-46371bda6faf4910b74631159fc2dfd4.r2.dev/kct-prodcuts/Bow%3ATie/Teal.png` |
| Peacock | `https://pub-46371bda6faf4910b74631159fc2dfd4.r2.dev/kct-prodcuts/Bow%3ATie/Peacock.png` |
| Silver | `https://pub-46371bda6faf4910b74631159fc2dfd4.r2.dev/kct-prodcuts/Bow%3ATie/Silver.png` |
| Charcoal | `https://pub-46371bda6faf4910b74631159fc2dfd4.r2.dev/kct-prodcuts/Bow%3ATie/Charcoal.png` |
| Grey | `https://pub-46371bda6faf4910b74631159fc2dfd4.r2.dev/kct-prodcuts/Bow%3ATie/Grey.png` |
| Tan | `https://pub-46371bda6faf4910b74631159fc2dfd4.r2.dev/kct-prodcuts/Bow%3ATie/Tan.png` |
| Taupe | `https://pub-46371bda6faf4910b74631159fc2dfd4.r2.dev/kct-prodcuts/Bow%3ATie/Taupe.png` |
| Brown | `https://pub-46371bda6faf4910b74631159fc2dfd4.r2.dev/kct-prodcuts/Bow%3ATie/Brown.png` |
| Chocolate | `https://pub-46371bda6faf4910b74631159fc2dfd4.r2.dev/kct-prodcuts/Bow%3ATie/Chocolate.png` |
| Red | `https://pub-46371bda6faf4910b74631159fc2dfd4.r2.dev/kct-prodcuts/Bow%3ATie/Red.png` |
| Wine | `https://pub-46371bda6faf4910b74631159fc2dfd4.r2.dev/kct-prodcuts/Bow%3ATie/Wine.png` |
| Raspberry | `https://pub-46371bda6faf4910b74631159fc2dfd4.r2.dev/kct-prodcuts/Bow%3ATie/Raspberry.png` |
| Hot Pink | `https://pub-46371bda6faf4910b74631159fc2dfd4.r2.dev/kct-prodcuts/Bow%3ATie/Hot-Pink.png` |
| Fuchsia | `https://pub-46371bda6faf4910b74631159fc2dfd4.r2.dev/kct-prodcuts/Bow%3ATie/Fuchsia.png` |
| Magenta | `https://pub-46371bda6faf4910b74631159fc2dfd4.r2.dev/kct-prodcuts/Bow%3ATie/Magenta.png` |

*Note: 76 total tie colors available. See R2 bucket for complete list.*

---

## Generated Outfit Sets (Supabase Storage)

**Bucket:** `outfit-previews` ✅ PUBLIC  
**Base URL:** `https://gvcswimqaxvylgxbklbz.supabase.co/storage/v1/object/public/outfit-previews/`

### Actual Files Available (Recent)

| Filename | Full URL |
|----------|----------|
| `quick-professional_charcoal_white_purple-tie.webp` | `https://gvcswimqaxvylgxbklbz.supabase.co/storage/v1/object/public/outfit-previews/quick-professional_charcoal_white_purple-tie_1767200697523.webp` |
| `quick-formal_black_white-formal_black-tie.webp` | `https://gvcswimqaxvylgxbklbz.supabase.co/storage/v1/object/public/outfit-previews/quick-formal_black_white-formal_black-tie_1767178413764.webp` |
| `quick-casual_olive_chambray_rust.webp` | `https://gvcswimqaxvylgxbklbz.supabase.co/storage/v1/object/public/outfit-previews/quick-casual_olive_chambray_rust_1767115301858.webp` |
| `black_white_black_none_2P_tie.webp` | `https://gvcswimqaxvylgxbklbz.supabase.co/storage/v1/object/public/outfit-previews/black_white_black_none_2P_tie_1767113823802.webp` |
| `quick-wedding_navy-wedding_white-wedding_sage.webp` | `https://gvcswimqaxvylgxbklbz.supabase.co/storage/v1/object/public/outfit-previews/quick-wedding_navy-wedding_white-wedding_sage_1767044703741.webp` |
| `quick-wedding_light-gray_white-wedding_sage.webp` | `https://gvcswimqaxvylgxbklbz.supabase.co/storage/v1/object/public/outfit-previews/quick-wedding_light-gray_white-wedding_sage_1767044596513.webp` |

### Naming Convention
```
{style}_{suit-color}_{shirt-color}_{tie-color}_{timestamp}.webp
```

**Styles:** `quick-professional`, `quick-formal`, `quick-casual`, `quick-wedding`, or `{suit}_{shirt}_{tie}_{vest}_{suitType}_{neckwear}`

---

## Usage in Code

### R2 Component Images (Corrected)
```typescript
const R2_BASE_URL = 'https://pub-46371bda6faf4910b74631159fc2dfd4.r2.dev/kct-prodcuts';

// Suits - lowercase folders with color subfolders
const suitUrl = `${R2_BASE_URL}/suits/${color}/${color}-3-main.jpg`; // 3-piece
const suitUrl2P = `${R2_BASE_URL}/suits/${color}/${color}-2-main.jpg`; // 2-piece

// Shirts - need to verify exact folder structure
// const shirtUrl = `${R2_BASE_URL}/shirts/${color}/${filename}`;

// Ties - need to verify exact folder structure  
// const tieUrl = `${R2_BASE_URL}/ties/${color}/${filename}`;
```

### Supabase Outfit Previews
```typescript
import { supabase } from '@/integrations/supabase/client';

const { data } = supabase.storage
  .from('outfit-previews')
  .getPublicUrl('navy-3piece-white-shirt.png');

const outfitUrl = data.publicUrl;
```

---

## Related Documentation

- [Bundle Component Images System](./bundle-component-images.md)
- [AI Image Generation](./AI_IMAGE_GENERATION.md)
