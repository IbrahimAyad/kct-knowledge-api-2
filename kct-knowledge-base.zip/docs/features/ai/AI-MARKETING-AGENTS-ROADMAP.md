# KCT Menswear - AI Marketing Agents Roadmap

**Document Created:** January 18, 2026
**Purpose:** Strategic roadmap for AI-powered marketing automation agents
**Status:** Planning Phase

---

## Executive Summary

This document outlines realistic AI marketing agents that can be built leveraging KCT Menswear's existing infrastructure. The focus is on agents that will directly impact sales through automated content generation, lead nurturing, and customer engagement.

---

## Current Infrastructure Overview

### What Already Exists

| System | Status | Location |
|--------|--------|----------|
| Blog content queue | ✅ Active | `content_queue` table in Supabase |
| Auto-publish blogs | ✅ Active | `supabase/functions/auto-publish-blogs` |
| Blog image generation | ✅ Active | `supabase/functions/generate-blog-hero-image` |
| IFTTT social posting | ✅ Active | `supabase/functions/share-to-ifttt` |
| Email via Resend | ✅ Active | Multiple edge functions |
| Cart recovery system | ✅ Active | `abandoned_carts` table + automation |
| Wedding lead tracking | ✅ Active | `wedding_outfit_selections` table |
| Analytics tracking | ✅ Active | GA4, Meta Pixel, TikTok, Supabase |
| AI recommendations | ✅ Active | OpenAI + Lovable AI integrations |
| Product reviews | ✅ Active | `product_reviews` table |
| Customer segmentation | ✅ Active | `customer_segments` tables |

### External APIs Available

- **OpenAI API** - Content generation, personalization
- **Lovable AI** - Style recommendations, outfit coordination
- **Resend** - Email delivery
- **Shopify Storefront/Admin API** - Product & order data
- **Railway Knowledge API** - Unified analytics dashboard
- **IFTTT** - Social media automation
- **Meta Conversion API** - Facebook/Instagram tracking

---

## Proposed AI Agents

### Agent #1: Blog Content Generation & Publishing Agent

**Priority:** #1 (Highest)
**Effort:** Low (infrastructure exists)
**Impact:** High

#### Description
Autonomous agent that generates, schedules, and publishes SEO-optimized blog content based on seasonal trends, inventory levels, and upcoming events.

#### Capabilities
- Generate blog posts using existing seasonal calendar data
- Auto-schedule to `content_queue` table
- Generate hero images via `generate-blog-hero-image` function
- Auto-publish via `auto-publish-blogs` function
- Push to social media via IFTTT integration
- A/B test headlines and content formats

#### Data Sources
- `blogMetadataAnalyzer.ts` - Seasonal content calendar
- `products` table - Current inventory/new arrivals
- `trending_searches` - What customers are searching for
- `analytics_product_performance` - Top performing products

#### Seasonal Calendar Reference
```
January:   Winter formal, New Year's Eve recap, winter weddings
February:  Valentine's Day, pink/red suits, transitional styling
March:     Early prom prep, St. Patrick's Day, spring transition
April:     PROM PEAK, Easter formal, spring weddings
May:       Graduation, Kentucky Derby, Memorial Day, wedding prep
June:      Peak wedding season, Father's Day, destination weddings
July:      Summer weddings, outdoor formal events
August:    Fall wedding prep, back-to-school/college
September: Fall weddings, early homecoming
October:   Homecoming peak, Halloween formal, velvet season starts
November:  Holiday party prep, Thanksgiving, velvet/tweed focus
December:  Holiday parties, New Year's Eve, gift guides
```

#### Implementation Approach
1. Create orchestrator edge function
2. Query seasonal calendar + trending data
3. Generate content via OpenAI/Lovable
4. Insert to `content_queue` with scheduled_date
5. Let existing auto-publish handle the rest

#### Success Metrics
- Blog posts published per month
- Organic traffic from blog
- Blog-to-product conversion rate
- Social engagement from auto-posts

---

### Agent #2: Wedding Lead Nurture Agent

**Priority:** #2
**Effort:** Low
**Impact:** High (direct revenue)

#### Description
Intelligent agent that monitors wedding outfit builder leads and sends personalized follow-up sequences to convert them to registered weddings.

#### Capabilities
- Monitor `wedding_outfit_selections` for new/incomplete builds
- Score leads by party size, package tier, completion status
- Send personalized email sequences
- Escalate high-value leads to staff
- Track conversion from lead → registration

#### Lead Scoring Criteria
```
+20 points: Ultimate package ($329)
+15 points: Complete package ($299)
+10 points: Premium package ($229)
+5 points:  Essential package ($199)
+5 points:  Vest included
+5 points:  Shoes included
+3 points per party member (estimated)
+10 points: Completed outfit selection
-10 points: Incomplete for 7+ days
```

#### Email Sequence
| Trigger | Timing | Content |
|---------|--------|---------|
| Incomplete build | 2 hours | "Finish your look" reminder |
| Still incomplete | 24 hours | Benefits of completing + support offer |
| Completed, not registered | 24 hours | "Register your wedding" CTA |
| Still not registered | 48 hours | Testimonial + urgency |
| High-value lead | Immediate | Staff notification for personal outreach |

#### Existing Infrastructure
- `wedding_outfit_selections` table
- `send-outfit-email` function
- `send-reminder-email` function
- `mark-lead-converted` function
- Email templates in `emailTemplateLibrary.ts`

#### Success Metrics
- Lead-to-registration conversion rate
- Average time from lead to registration
- Revenue per lead
- Email open/click rates by sequence step

---

### Agent #3: Smart Cart Recovery Agent

**Priority:** #3
**Effort:** Medium
**Impact:** High

#### Description
AI-powered cart abandonment recovery that personalizes offers based on cart contents, customer history, and optimal timing.

#### Capabilities
- Monitor `abandoned_carts` table in real-time
- Analyze cart contents to personalize messaging
- A/B test subject lines and offers
- Choose optimal send time based on customer behavior
- Gradually escalate offers based on cart value
- Exclude customers who completed purchase elsewhere

#### Recovery Sequence Strategy
```
Email 1 (1 hour):    Reminder only, no discount
Email 2 (24 hours):  10% off OR free accessory (based on cart)
Email 3 (72 hours):  Final reminder + best offer
```

#### Offer Logic
| Cart Value | First Offer | Escalated Offer |
|------------|-------------|-----------------|
| < $100 | Free shipping reminder | 10% off |
| $100-$300 | Free accessory add-on | 15% off |
| $300-$500 | 10% off | 15% off + free alterations |
| > $500 | 10% off + free alterations | 20% off |

#### Existing Infrastructure
- `abandoned_carts` table
- `cart_recovery_email_templates` table
- `cart-recovery-automation` function
- `send-cart-recovery-email` function

#### Success Metrics
- Cart recovery rate (target: 15-20%)
- Revenue recovered per month
- Optimal email timing insights
- Best performing offers by segment

---

### Agent #4: Product Trend & Promotion Agent

**Priority:** #4
**Effort:** Medium
**Impact:** Medium

#### Description
Analyzes sales data, search trends, and inventory to identify hot products and generate timely promotional content.

#### Capabilities
- Identify trending products from analytics
- Cross-reference with inventory levels
- Generate "Trending Now" content blocks
- Create "Almost Gone" alerts for low-stock popular items
- Suggest products for email campaigns
- Identify underperforming products needing promotion

#### Data Sources
- `trending_searches` table
- `analytics_product_performance` table
- `recommendation_engagement` table
- Railway API `/api/analytics/top-products`
- Shopify inventory levels

#### Alert Triggers
```
TRENDING:     Product views up 50%+ week-over-week
LOW STOCK:    Popular item < 10 units remaining
NEW ARRIVAL:  Product added in last 7 days, gaining traction
SLEEPING HIT: High conversion rate, low traffic (needs promotion)
```

#### Output Actions
- Update homepage "Trending" section
- Trigger email campaign suggestions
- Generate social media post content
- Alert staff for inventory decisions

#### Success Metrics
- Trending product conversion rates
- Low-stock alert effectiveness
- Sell-through rate improvements
- Revenue from trend-based promotions

---

### Agent #5: Review Request & UGC Agent

**Priority:** #5
**Effort:** Medium
**Impact:** Medium

#### Description
Automatically solicits reviews from customers post-purchase and aggregates positive reviews for marketing use.

#### Capabilities
- Monitor orders for delivery confirmation
- Send review request emails at optimal timing (7-14 days post-delivery)
- Follow up with non-responders once
- Flag negative reviews for immediate staff attention
- Aggregate positive reviews for social proof
- Generate "Customer Stories" content

#### Review Request Timing
```
Day 7:   First review request (product-specific)
Day 14:  Follow-up if no response
Day 30:  Wedding party group review request (if applicable)
```

#### Content Generation
- Pull 5-star reviews with photos
- Generate social media posts with customer quotes
- Create "Customer of the Month" features
- Aggregate reviews by product for display

#### Existing Infrastructure
- `product_reviews` table
- `order_fulfillment` table (delivery dates)
- Resend email integration
- IFTTT for social posting

#### Success Metrics
- Review submission rate
- Average rating maintained
- UGC content pieces generated per month
- Social engagement on customer content

---

### Agent #6: Seasonal Campaign Planner Agent

**Priority:** #6
**Effort:** Low
**Impact:** Medium

#### Description
Automatically plans and schedules content campaigns 30-60 days ahead based on the seasonal calendar.

#### Capabilities
- Read seasonal calendar data
- Plan blog posts, emails, and social content
- Auto-populate `content_queue` with scheduled items
- Coordinate across channels (blog → email → social)
- Suggest product features for each campaign
- Generate campaign briefs for staff review

#### Campaign Template
```markdown
## [Month] [Year] Campaign Plan

### Key Dates
- [Holiday/Event 1]: [Date]
- [Holiday/Event 2]: [Date]

### Content Schedule
| Date | Type | Topic | Products Featured |
|------|------|-------|-------------------|

### Email Campaigns
- Campaign 1: [Topic] - Send [Date]
- Campaign 2: [Topic] - Send [Date]

### Social Media Themes
- Week 1: [Theme]
- Week 2: [Theme]
- Week 3: [Theme]
- Week 4: [Theme]
```

#### Existing Infrastructure
- `blogMetadataAnalyzer.ts` seasonal data
- `content_queue` table
- Blog calendar docs in `docs/blog-calendar/2026/`

#### Success Metrics
- Campaign completion rate
- Content published on schedule
- Seasonal revenue vs. prior year
- Staff time saved on planning

---

### Agent #7: Customer Reactivation Agent

**Priority:** #7
**Effort:** Medium
**Impact:** Medium

#### Description
Identifies lapsed customers and sends personalized win-back campaigns based on their purchase history.

#### Capabilities
- Query customers by last purchase date (90/180/365 days)
- Segment by previous purchase type (wedding, prom, general)
- Generate personalized product recommendations
- Send win-back email sequences
- Track reactivation success

#### Segmentation Strategy
| Segment | Last Purchase | Message Focus |
|---------|---------------|---------------|
| Wedding Alumni | 1+ year ago | Anniversary, friend referral |
| Prom Graduates | 1 year ago | College formal events |
| Occasional Buyer | 6+ months | New arrivals, seasonal |
| High-Value Lapsed | 90+ days | VIP offer, personal outreach |

#### Win-Back Sequence
```
Email 1: "We miss you" + personalized recommendations
Email 2: Exclusive offer (if no engagement)
Email 3: Final "last chance" offer
```

#### Existing Infrastructure
- `orders` table (purchase history)
- `customer_segments` tables
- `get_customer_lifetime_value` RPC
- Email infrastructure

#### Success Metrics
- Reactivation rate by segment
- Revenue from reactivated customers
- Cost per reactivation
- LTV of reactivated vs. new customers

---

### Agent #8: Social Proof Automation Agent

**Priority:** #8
**Effort:** Low
**Impact:** Low-Medium

#### Description
Automatically generates and posts social proof content from reviews, wedding photos, and customer stories.

#### Capabilities
- Pull recent positive reviews
- Generate social media posts with customer quotes
- Schedule posts via IFTTT
- Create "Customer of the Week" content
- Aggregate wedding party photos (with permission)

#### Content Types
```
1. Review Highlights: "[5-star quote]" - [Customer Name], [City]
2. Wedding Features: "Congrats to [Groom]'s wedding party!"
3. Style Spotlights: Customer outfit photos with product tags
4. Milestone Posts: "1000+ wedding parties served!"
```

#### Existing Infrastructure
- `product_reviews` table
- IFTTT integration
- Wedding party photos in system

#### Success Metrics
- Social engagement rate
- Review-driven traffic
- Brand mention growth
- Customer photo submissions

---

## Implementation Roadmap

### Phase 1: Quick Wins (Weeks 1-2)
- [ ] Agent #1: Blog Content Agent (orchestrator function)
- [ ] Agent #6: Seasonal Campaign Planner (automation script)

### Phase 2: Revenue Drivers (Weeks 3-4)
- [ ] Agent #2: Wedding Lead Nurture (enhanced email logic)
- [ ] Agent #3: Smart Cart Recovery (AI personalization)

### Phase 3: Growth (Weeks 5-8)
- [ ] Agent #4: Product Trend Agent
- [ ] Agent #5: Review Request Agent
- [ ] Agent #7: Customer Reactivation Agent

### Phase 4: Polish (Weeks 9-12)
- [ ] Agent #8: Social Proof Agent
- [ ] Dashboard for monitoring all agents
- [ ] A/B testing infrastructure
- [ ] Performance optimization

---

## Technical Architecture

### Agent Execution Options

**Option A: Supabase Cron + Edge Functions**
```
pg_cron → triggers edge function → executes agent logic → updates database
```
- Pros: Uses existing infrastructure, no new services
- Cons: Limited scheduling flexibility

**Option B: External Orchestrator (Railway/Vercel)**
```
Cron service → API call → agent logic → Supabase/Shopify updates
```
- Pros: More control, better monitoring
- Cons: Additional service to maintain

**Option C: Hybrid Approach (Recommended)**
```
Time-based agents: pg_cron + edge functions
Event-based agents: Database triggers + edge functions
Complex agents: Railway service with Supabase connection
```

### Monitoring & Oversight

Each agent should have:
1. **Activity Log** - All actions recorded in database
2. **Admin Dashboard** - View pending actions, approve/reject
3. **Performance Metrics** - Track effectiveness
4. **Kill Switch** - Ability to disable agent instantly
5. **Rate Limits** - Prevent runaway execution

### Human-in-the-Loop Options

| Agent | Approval Level |
|-------|----------------|
| Blog Content | Review before publish (optional) |
| Wedding Leads | Auto-send, escalate high-value |
| Cart Recovery | Fully automated |
| Promotions | Suggest only, staff approves |
| Reviews | Auto-request, flag negatives |
| Reactivation | Auto-send standard, approve VIP |
| Social Proof | Auto-post reviews, approve photos |

---

## Data Privacy & Compliance

### Email Compliance
- All marketing emails must include unsubscribe
- Honor opt-out within 24 hours
- Track consent status in customer profile

### Data Handling
- PII hashed before analytics (SHA-256)
- Customer data stays in Supabase (US region)
- No third-party data sharing without consent

### Review Usage
- Only use reviews with implicit consent (submitted via site)
- Allow customers to request removal
- Attribute quotes to first name + city only

---

## Success Metrics Summary

| Agent | Primary KPI | Target |
|-------|-------------|--------|
| Blog Content | Organic traffic | +25% in 6 months |
| Wedding Leads | Conversion rate | 15% lead → registration |
| Cart Recovery | Recovery rate | 15-20% of abandoned |
| Product Trends | Trend conversion | 2x standard conversion |
| Review Requests | Review rate | 10% of delivered orders |
| Campaign Planner | On-time content | 95% published on schedule |
| Reactivation | Win-back rate | 5% of lapsed customers |
| Social Proof | Engagement | +50% social engagement |

---

## Next Steps

1. **Prioritize** - Confirm agent priority order
2. **Pilot** - Start with Agent #1 (Blog) as proof of concept
3. **Measure** - Establish baseline metrics before launch
4. **Iterate** - Review performance weekly, adjust logic
5. **Scale** - Roll out additional agents based on results

---

## Appendix: Existing Function Reference

### Blog Functions
- `auto-publish-blogs` - Publishes scheduled content
- `generate-blog-hero-image` - Creates feature images
- `batch-generate-blog-images` - Bulk image generation
- `process-blog-content` - AI content processing
- `share-to-ifttt` - Social media posting

### Email Functions
- `send-newsletter-welcome` - Welcome with 15% discount
- `send-outfit-email` - Outfit builder reminder
- `send-reminder-email` - General reminders
- `send-cart-recovery-email` - Cart abandonment
- `cart-recovery-automation` - Automated recovery flow

### Analytics Functions
- `performance-analytics` - Track page performance
- `facebook-conversion-api` - Meta tracking
- `mark-lead-converted` - Conversion attribution

### Wedding Functions
- `send-wedding-welcome-email` - Party welcome
- `send-wedding-invitation` - Groomsman invites
- `automated-wedding-notifications` - Event reminders
- `check-outfit-followups` - Follow-up triggers

---

*Document maintained by KCT Menswear development team*
