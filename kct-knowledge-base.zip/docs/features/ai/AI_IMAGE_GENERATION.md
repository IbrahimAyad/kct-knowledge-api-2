# AI Image Generation System

## Overview
This system uses Lovable AI's `google/gemini-2.5-flash-image-preview` (Nano Banana) model to generate realistic product preview images with intelligent caching for performance and cost optimization.

## Architecture

### Components
1. **Storage Bucket**: `outfit-previews` - Public bucket for generated images
2. **Cache Table**: `outfit_preview_cache` - Tracks generated images with metadata
3. **Edge Function**: `generate-outfit-preview` - Handles generation and caching logic
4. **Frontend Hook**: Can be integrated into any React component

### Database Schema

```sql
CREATE TABLE public.outfit_preview_cache (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  cache_key TEXT UNIQUE NOT NULL,          -- Deterministic key for lookup
  image_url TEXT NOT NULL,                 -- Supabase Storage URL
  outfit_description TEXT,                 -- Prompt used for generation
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  last_accessed_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);
```

## How It Works

### Flow Diagram
```
Request → Check Cache → Cache Hit? → Return URL (fast)
                      ↓
                   Cache Miss
                      ↓
              Generate with AI
                      ↓
              Upload to Storage
                      ↓
               Save to Cache
                      ↓
                 Return URL
```

### Cache Key Strategy
- Deterministic: Same inputs = Same cache key = Same image
- Format: `{param1}_{param2}_{param3}_{paramN}`
- Example: `jacket123_shirt456_tie789_none_2P`

### Performance
- **First request**: 3-5 seconds (AI generation + upload)
- **Cached requests**: <500ms (database + storage lookup)
- **Cost**: Only pay for AI generation once per unique combination

## Usage Examples

### Example 1: Outfit Preview (Current Implementation)

```typescript
// In OutfitAssemblyPreview.tsx
const [previewImage, setPreviewImage] = useState<string | null>(null);
const [isGenerating, setIsGenerating] = useState(false);

useEffect(() => {
  if (!jacket || !shirt || !tie) return;
  
  const generatePreview = async () => {
    setIsGenerating(true);
    try {
      const { data, error } = await supabase.functions.invoke('generate-outfit-preview', {
        body: {
          jacketId: jacket.id,
          shirtId: shirt.id,
          tieId: tie.id,
          vestId: vest?.id,
          suitType,
          jacketColor: jacket.color,
          jacketName: jacket.name,
          shirtColor: shirt.color,
          shirtName: shirt.name,
          tieColor: tie.color,
          tieName: tie.name,
          vestColor: vest?.color,
          vestName: vest?.name
        }
      });
      
      if (error) throw error;
      setPreviewImage(data.imageUrl);
    } catch (error) {
      console.error('Failed to generate preview:', error);
    } finally {
      setIsGenerating(false);
    }
  };
  
  generatePreview();
}, [jacket, shirt, tie, vest, suitType]);
```

### Example 2: Product Mockup Generation

```typescript
// For generating product mockups in different contexts
const generateProductMockup = async (productId: string, context: string) => {
  const { data } = await supabase.functions.invoke('generate-product-mockup', {
    body: {
      productId,
      context, // "lifestyle", "flat-lay", "mannequin", etc.
      style: "professional"
    }
  });
  return data.imageUrl;
};
```

### Example 3: Seasonal Campaign Images

```typescript
// Generate themed images for marketing
const generateSeasonalImage = async (products: string[], theme: string) => {
  const { data } = await supabase.functions.invoke('generate-seasonal-campaign', {
    body: {
      productIds: products,
      theme, // "spring-wedding", "summer-beach", "winter-formal"
      aspectRatio: "16:9"
    }
  });
  return data.imageUrl;
};
```

## Creating New Image Generation Features

### Step 1: Define Your Cache Key Strategy
```typescript
// Make it deterministic and unique
const cacheKey = `${type}_${param1}_${param2}_${version}`;
```

### Step 2: Create Edge Function
```typescript
// supabase/functions/your-feature/index.ts
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.39.3';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { param1, param2 } = await req.json();
    
    // Initialize Supabase
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    );
    
    // Generate cache key
    const cacheKey = `${param1}_${param2}`;
    
    // Check cache
    const { data: cached } = await supabase
      .from('outfit_preview_cache') // or create your own cache table
      .select('image_url')
      .eq('cache_key', cacheKey)
      .maybeSingle();
    
    if (cached) {
      return new Response(
        JSON.stringify({ imageUrl: cached.image_url, cached: true }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }
    
    // Build your prompt
    const prompt = `Your detailed image generation prompt here`;
    
    // Call Lovable AI
    const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY');
    const aiResponse = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${LOVABLE_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'google/gemini-2.5-flash-image-preview',
        messages: [{ role: 'user', content: prompt }],
        modalities: ['image', 'text']
      })
    });
    
    if (!aiResponse.ok) {
      if (aiResponse.status === 429) {
        return new Response(
          JSON.stringify({ error: 'Rate limit exceeded' }),
          { status: 429, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
      if (aiResponse.status === 402) {
        return new Response(
          JSON.stringify({ error: 'Credits depleted' }),
          { status: 402, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
      throw new Error(`AI API error: ${aiResponse.status}`);
    }
    
    const aiData = await aiResponse.json();
    const base64Image = aiData.choices?.[0]?.message?.images?.[0]?.image_url?.url;
    
    if (!base64Image) throw new Error('No image generated');
    
    // Convert base64 to blob
    const base64Data = base64Image.replace(/^data:image\/\w+;base64,/, '');
    const binaryString = atob(base64Data);
    const bytes = new Uint8Array(binaryString.length);
    for (let i = 0; i < binaryString.length; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }
    const blob = new Blob([bytes], { type: 'image/png' });
    
    // Upload to storage
    const fileName = `${cacheKey}_${Date.now()}.png`;
    const { error: uploadError } = await supabase.storage
      .from('outfit-previews') // or your own bucket
      .upload(fileName, blob, {
        contentType: 'image/png',
        cacheControl: '3600',
      });
    
    if (uploadError) throw uploadError;
    
    // Get public URL
    const { data: { publicUrl } } = supabase.storage
      .from('outfit-previews')
      .getPublicUrl(fileName);
    
    // Save to cache
    await supabase
      .from('outfit_preview_cache')
      .insert({
        cache_key: cacheKey,
        image_url: publicUrl,
        outfit_description: prompt
      });
    
    return new Response(
      JSON.stringify({ imageUrl: publicUrl, cached: false }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
    
  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
```

### Step 3: Add to config.toml
```toml
[functions.your-feature]
verify_jwt = false  # or true if you need auth
```

### Step 4: Create Frontend Hook (Optional)
```typescript
// src/hooks/useImageGeneration.ts
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';

export const useImageGeneration = (params: any, enabled = true) => {
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!enabled) return;

    const generate = async () => {
      setIsGenerating(true);
      setError(null);
      
      try {
        const { data, error } = await supabase.functions.invoke('your-feature', {
          body: params
        });
        
        if (error) throw error;
        setImageUrl(data.imageUrl);
      } catch (err) {
        setError(err.message);
      } finally {
        setIsGenerating(false);
      }
    };

    generate();
  }, [JSON.stringify(params), enabled]);

  return { imageUrl, isGenerating, error };
};
```

## Best Practices

### Prompt Engineering
- Be specific and detailed
- Include style, lighting, composition details
- Add "Ultra high resolution" for quality
- Specify aspect ratio in prompt when needed
- Reference professional photography styles

### Cache Management
- Use deterministic cache keys
- Include version in key if prompts change
- Consider creating separate cache tables for different feature types
- Monitor `last_accessed_at` for cleanup

### Error Handling
- Always handle 429 (rate limit) and 402 (no credits) errors
- Provide user-friendly error messages
- Have fallback UI when generation fails
- Log errors for debugging

### Performance
- Generate images in background when possible
- Show loading states during first generation
- Consider preemptive generation for common combinations
- Use appropriate image formats (PNG for quality, JPEG for size)

## Cost Optimization

1. **Aggressive Caching**: Same inputs always use cached images
2. **Batch Generation**: Generate popular combinations during off-peak
3. **Analytics**: Track usage to identify optimization opportunities
4. **Cleanup**: Remove old, unused images periodically

## Monitoring

### Key Metrics
- Cache hit rate (should be >80% after initial generation)
- Average generation time
- Error rate
- Storage usage
- Cost per generation

### Queries for Analytics
```sql
-- Cache hit rate
SELECT 
  COUNT(*) as total_requests,
  SUM(CASE WHEN created_at < NOW() - INTERVAL '1 hour' THEN 1 ELSE 0 END) as cache_hits
FROM outfit_preview_cache;

-- Most accessed images
SELECT cache_key, image_url, last_accessed_at, 
       AGE(NOW(), created_at) as age
FROM outfit_preview_cache
ORDER BY last_accessed_at DESC
LIMIT 10;

-- Storage cleanup candidates (not accessed in 30 days)
SELECT * FROM outfit_preview_cache
WHERE last_accessed_at < NOW() - INTERVAL '30 days'
ORDER BY created_at ASC;
```

## Troubleshooting

### Issue: Image not generating
- Check LOVABLE_API_KEY is set
- Verify workspace has credits
- Check Lovable AI rate limits
- Review edge function logs

### Issue: Poor image quality
- Improve prompt specificity
- Add more detail about lighting, style
- Reference professional photography
- Use "Ultra high resolution" in prompt

### Issue: Slow performance
- Check if caching is working
- Verify database indexes exist
- Consider preemptive generation
- Monitor Supabase performance

## Future Enhancements

- [ ] Batch generation API
- [ ] Image variation generation
- [ ] A/B testing different prompts
- [ ] Automatic style transfer
- [ ] Video generation support
- [ ] Custom model fine-tuning
