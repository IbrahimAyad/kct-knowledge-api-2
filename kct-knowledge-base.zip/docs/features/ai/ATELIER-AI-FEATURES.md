# Atelier AI Features Documentation

> Complete technical documentation for all AI-powered chat and voice features in the KCT Menswear application.

---

## Table of Contents

1. [Overview](#overview)
2. [Feature 1: Style Assistant (Text Chat)](#feature-1-style-assistant-text-chat)
3. [Feature 2: Size Bot](#feature-2-size-bot)
4. [Feature 3: Voice Assistant](#feature-3-voice-assistant)
5. [Known Issues & Debugging](#known-issues--debugging)
6. [Environment Variables & Secrets](#environment-variables--secrets)
7. [Architecture Diagram](#architecture-diagram)

---

## Overview

The Atelier AI system provides three main AI-powered features:

| Feature | Type | Status | Entry Points |
|---------|------|--------|--------------|
| **Style Assistant** | Text Chat | ✅ Working | FloatingAIAssistant, FAB menu |
| **Size Bot** | Interactive Calculator | ✅ Working | SizeGuideModal, EnhancedSizeGuide |
| **Voice Assistant** | Voice (ElevenLabs) | ⚠️ Issues on Mobile | AtelierFAB, MobileBottomNav |

---

## Feature 1: Style Assistant (Text Chat)

### What It Does
AI-powered text chat that helps customers with:
- Style advice and outfit recommendations
- Product search with Shopify integration
- Color matching and occasion-based suggestions
- Cart completion recommendations
- Navigation assistance

### Components

| Component | File | Purpose |
|-----------|------|---------|
| `FloatingAIAssistant` | `src/components/ai/FloatingAIAssistant.tsx` | Main chat UI with floating button, menu, and chat window |
| `ChatMessage` | `src/components/ai/ChatMessage.tsx` | Individual message rendering with product cards |
| `ChatProductCard` | `src/components/ai/ChatProductCard.tsx` | Product display within chat messages |
| `TypingIndicator` | `src/components/ai/TypingIndicator.tsx` | Loading animation while AI responds |

### Service Layer

**File:** `src/services/atelierChatService.ts`

```typescript
// Primary method - uses Supabase edge function + Shopify
atelierChatService.sendMessageWithShopify(message, sessionId, conversationHistory)

// Fallback - legacy Railway API
atelierChatService.sendMessage(message, sessionId, userId, context)
```

**Flow:**
1. User sends message → `atelierChatService.sendMessageWithShopify()`
2. Edge function `atelier-chat` analyzes intent with AI (Gemini)
3. Returns `searchParams` for product queries
4. Client-side fetches products from Shopify using:
   - `getCollectionProducts()` - for collection searches
   - `collectionSearch()` - for keyword searches
   - `predictiveSearch()` - fast fallback with limited data
5. Products ranked by relevance score and displayed

### Edge Functions

| Function | Purpose |
|----------|---------|
| `atelier-chat` | Main AI chat endpoint (uses Gemini via Lovable AI Gateway) |
| `ai-style-assistant` | Style-specific advice with KCT Knowledge Base integration |

### Features Implemented

- ✅ Context-aware greetings based on page location
- ✅ Proactive tooltip after user scrolls
- ✅ Multi-action menu (Chat, Size, Style buttons)
- ✅ Product recommendations with cards
- ✅ Suggested actions and links
- ✅ Mobile-responsive drawer UI
- ✅ Integration with cart context
- ✅ Session persistence
- ✅ Trending data from KCT Knowledge Base API

### Response Format

```typescript
interface ChatResponse {
  success: boolean;
  response: {
    message: string;           // AI response text
    intent: string;            // Detected intent (browse, sizing, etc.)
    confidence?: number;       // 0-1 confidence score
    products?: ShopifyProduct[];  // Product recommendations
    searchParams?: SearchParams;  // For product fetching
    suggestedActions: Array<{
      type: string;
      label: string;
      data?: Record<string, any>;
    }>;
    suggestedLinks?: SuggestedLink[];
    productRecommendations?: Array<{
      productId: string;
      reason: string;
      relevanceScore: number;
      highlight: string;
    }>;
  };
}
```

---

## Feature 2: Size Bot

### What It Does
AI-powered size recommendation based on:
- Height and weight
- Fit preference (slim, regular, relaxed)
- Body type detection
- Alteration suggestions

### Components

| Component | File | Purpose |
|-----------|------|---------|
| `EnhancedSizeGuide` | `src/components/ai/EnhancedSizeGuide.tsx` | Interactive sliders and recommendation display |
| `SizeGuideModal` | `src/components/SizeGuideModal.tsx` | Modal wrapper with mobile swipe-to-close |
| `CompactSizeGuide` | `src/components/ai/CompactSizeGuide.tsx` | Smaller version for embedding |

### API Endpoints

**Primary:** Railway API
```
POST https://suitsize-ai-production.up.railway.app/api/recommend
```

**Fallback:** Supabase Edge Function → Database Lookup
```
supabase.functions.invoke('ai-size-bot')
→ Falls back to `simple_size_recommendations` table
```

### Request Format

```typescript
{
  height: number;        // Total inches (e.g., 70 for 5'10")
  weight: number;        // Pounds
  fitPreference: 'slim' | 'regular' | 'relaxed';
  bodyType?: string;     // Optional: 'athletic', 'regular', 'broad'
}
```

### Response Format

```typescript
interface SizeRecommendation {
  size: string;            // e.g., "40R", "38L"
  confidence: number;      // 0-1 score
  confidenceLevel: 'high' | 'medium' | 'low';
  bodyType: string;        // Detected body type
  rationale: string;       // Explanation text
  alterations?: string[];  // Suggested alterations
  measurements?: {
    height: number;
    weight: number;
    chest?: number;
    waist?: number;
    drop?: number;
    bmi?: number;
  };
  source: 'railway' | 'database';  // Which API served the response
}
```

### Features Implemented

- ✅ Drag-and-drop sliders for height/weight
- ✅ Touch support for mobile
- ✅ Fit preference toggle
- ✅ Visual confidence indicator
- ✅ Body type detection and display
- ✅ Alteration suggestions
- ✅ Railway API with Supabase database fallback
- ✅ Smooth animations

---

## Feature 3: Voice Assistant

### What It Does
ElevenLabs-powered voice assistant that enables:
- Voice commands for navigation
- Product search by voice
- Cart operations
- Store information queries
- Hands-free shopping experience

### Components

| Component | File | Purpose |
|-----------|------|---------|
| `VoiceAssistant` | `src/components/voice/VoiceAssistant.tsx` | Main voice session manager with ElevenLabs SDK |
| `VoiceFloatingIndicator` | `src/components/voice/VoiceFloatingIndicator.tsx` | Visual feedback during voice session |
| `VoicePermissionModal` | `src/components/voice/VoicePermissionModal.tsx` | Microphone permission request UI |
| `AtelierFAB` | `src/components/fab/AtelierFAB.tsx` | Floating action button with voice entry |
| `FloatingActionMenu` | `src/components/fab/FloatingActionMenu.tsx` | Expandable menu with voice option |
| `MobileBottomNav` | `src/components/MobileBottomNav.tsx` | Mobile nav with voice button |

### Voice Actions (Client Tools)

**File:** `src/hooks/useVoiceActions.ts`

```typescript
// Available voice commands
navigateToPage({ page: string })     // "Take me to suits"
searchProducts({ query, category?, maxPrice? })  // "Show me blue ties under $50"
openCart()                           // "Open my cart"
addToCart({ productName, size? })    // "Add navy suit to cart"
openWeddingRegistration()            // "Register my wedding"
openSizeGuide()                      // "What size should I get?"
showProductDetails({ productId })    // "Tell me more about this"
getStoreInfo({ infoType })           // "What are your hours?"
openVirtualTryOn()                   // "Try on virtually"
```

### Edge Function

**File:** `supabase/functions/elevenlabs-conversation-token/index.ts`

```typescript
// Returns ephemeral token for WebRTC connection
GET https://api.elevenlabs.io/v1/convai/conversation/token?agent_id={AGENT_ID}
→ Returns: { token: string }
```

### ElevenLabs Configuration

The voice agent must be configured in the **ElevenLabs Dashboard** with:

1. **Agent ID** → Stored in `ELEVENLABS_AGENT_ID` env var
2. **Client Tools** → Must match the `clientTools` object in `VoiceAssistant.tsx`:
   - `navigateToPage`
   - `searchProducts`
   - `openCart`
   - `addToCart`
   - `openWeddingRegistration`
   - `openSizeGuide`
   - `showProductDetails`
   - `getStoreInfo`
   - `openVirtualTryOn`

3. **System Prompt** → Configured in ElevenLabs dashboard (not in code)

### Mobile-Specific Implementation

```typescript
// VoiceAssistant.tsx mobile handling

// 1. Detect mobile device
const isMobileDevice = () => {
  return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
};

// 2. Unlock audio context on user gesture (required for iOS/Android)
const unlockAudio = async () => {
  const audioContext = new (window.AudioContext || window.webkitAudioContext)();
  const buffer = audioContext.createBuffer(1, 1, 22050);
  const source = audioContext.createBufferSource();
  source.buffer = buffer;
  source.connect(audioContext.destination);
  source.start(0);
  if (audioContext.state === 'suspended') {
    await audioContext.resume();
  }
};

// 3. SDK options for mobile stability
useConversation({
  preferHeadphonesForIosDevices: true,
  connectionDelay: {
    android: 3000,  // 3 second delay for Android
    ios: 0,
    default: 0,
  },
  // ... callbacks
});

// 4. Imperative handle for parent components to trigger start
useImperativeHandle(ref, () => ({
  start: startConversation,
  end: endConversation,
}));
```

### Voice Session Flow

```
1. User taps voice button (FAB or bottom nav)
   ↓
2. [Mobile] Parent calls voiceRef.current.start() within tap gesture
   ↓
3. [Mobile] unlockAudio() - plays silent sound to unlock AudioContext
   ↓
4. Check microphone permission (getUserMedia)
   ↓
5. Fetch conversation token from edge function
   ↓
6. Start ElevenLabs session (WebRTC)
   ↓
7. Show VoiceFloatingIndicator
   ↓
8. User speaks → Agent responds → clientTools execute
   ↓
9. User or agent ends call → cleanup
```

### Features Implemented

- ✅ ElevenLabs WebRTC integration via `@11labs/react`
- ✅ Conversation token generation (edge function)
- ✅ Client tools for navigation, search, cart
- ✅ Visual speaking/listening indicator
- ✅ Mute/unmute controls
- ✅ Mobile audio context unlock
- ✅ Permission modal with explanation
- ✅ Auto-start on desktop
- ✅ Explicit start within gesture on mobile
- ✅ Connection delay for Android stability
- ✅ Headphone preference for iOS

---

## Known Issues & Debugging

### Issue 1: "silence detected on local audio track" (Mobile)

**Symptoms:**
- Console shows: `publishing track → disconnect → silence detected`
- Voice connects briefly then disconnects
- Mic appears to be silent despite permissions granted

**Possible Causes:**
1. **AudioContext not unlocked** - iOS/Android require audio playback in user gesture before mic works
2. **Another app holding mic** - Camera, other voice app, etc.
3. **Cloudflare Rocket Loader** - Script optimizer interfering with audio
4. **SDK mic capture conflict** - App capturing its own stream before SDK takes over

**Current Mitigations:**
- `unlockAudio()` runs before `startSession()` on mobile
- Parent components call `voiceRef.current?.start()` directly in click handler
- `connectionDelay.android: 3000` gives time for audio to initialize

**Next Steps to Debug:**
1. Add `getInputVolume()` readout to confirm if SDK sees audio
2. Add `onDebug` callback to log ElevenLabs internal events
3. Verify token response is valid JSON (not HTML error page)

### Issue 2: "The script has an unsupported MIME type ('text/html')"

**Symptoms:**
- Console error about MIME type
- May reference non-existent files like `useShopifyProducts.ts`

**Causes:**
1. **Missing file** - Browser requests JS file that doesn't exist, server returns `index.html` (SPA fallback)
2. **Stale build cache** - Old bundle references deleted files
3. **Cloudflare Rocket Loader** - Rewrites script loading, can cause module errors

**Solutions:**
1. Hard refresh + clear cache
2. Disable Cloudflare Rocket Loader for this domain
3. Check Network tab for which file is returning HTML instead of JS

### Issue 3: FAB Menu Not Collapsing on Mobile

**Symptoms:**
- After selecting voice, the 3-button menu stays open

**Fix Applied:**
- `FloatingActionMenu.tsx` now calls `setIsOpen(false)` for all selections including voice

### Debugging Checklist

```
□ Network tab: Check elevenlabs-conversation-token returns JSON with token
□ Console: Look for "ElevenLabs connected" or error messages
□ Permissions: Verify microphone permission is granted (not blocked)
□ HTTPS: Site must be served over HTTPS (or localhost)
□ Other apps: Close any apps that might be using the microphone
□ Rocket Loader: Disable Cloudflare script optimization
□ Cache: Clear site data and hard refresh
□ Mobile gesture: Ensure start is called within tap handler
```

---

## Environment Variables & Secrets

### Required for Voice Assistant

| Variable | Where | Purpose |
|----------|-------|---------|
| `ELEVENLABS_API_KEY` | Supabase Secrets | API authentication |
| `ELEVENLABS_AGENT_ID` | Supabase Secrets | Agent configuration ID |

### Required for Chat/Style Assistant

| Variable | Where | Purpose |
|----------|-------|---------|
| `LOVABLE_API_KEY` | Supabase Secrets | Lovable AI Gateway access |
| `KCT_API_URL` | Supabase Secrets | KCT Knowledge Base (optional) |
| `KCT_API_KEY` | Supabase Secrets | KCT API auth (optional) |

### Required for Size Bot

| Variable | Where | Purpose |
|----------|-------|---------|
| (None - uses Railway API) | - | Railway API is public |
| `SUPABASE_SERVICE_ROLE_KEY` | Auto-provided | For database fallback |

---

## Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────┐
│                        FRONTEND (React)                          │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────────────┐   │
│  │ AtelierFAB   │  │ MobileBottom │  │ FloatingAIAssistant  │   │
│  │              │  │    Nav       │  │                      │   │
│  └──────┬───────┘  └──────┬───────┘  └──────────┬───────────┘   │
│         │                 │                     │                │
│         ▼                 ▼                     ▼                │
│  ┌──────────────────────────────┐  ┌────────────────────────┐   │
│  │     VoiceAssistant           │  │  atelierChatService    │   │
│  │  (ElevenLabs @11labs/react)  │  │                        │   │
│  └──────────────┬───────────────┘  └────────────┬───────────┘   │
│                 │                               │                │
│  ┌──────────────┴───────────────┐               │                │
│  │     useVoiceActions          │               │                │
│  │  (navigate, cart, search)    │               │                │
│  └──────────────────────────────┘               │                │
│                                                 │                │
└─────────────────────────────────────────────────┼────────────────┘
                                                  │
┌─────────────────────────────────────────────────┼────────────────┐
│                    SUPABASE EDGE FUNCTIONS      │                │
├─────────────────────────────────────────────────┼────────────────┤
│                                                 │                │
│  ┌───────────────────────────┐  ┌───────────────┴──────────────┐ │
│  │ elevenlabs-conversation-  │  │        atelier-chat          │ │
│  │        token              │  │  (Gemini via Lovable Gateway)│ │
│  └───────────────┬───────────┘  └───────────────┬──────────────┘ │
│                  │                              │                │
│  ┌───────────────┴───────────┐  ┌───────────────┴──────────────┐ │
│  │      ai-size-bot          │  │    ai-style-assistant        │ │
│  │  (Railway + DB fallback)  │  │  (KCT Knowledge Base)        │ │
│  └───────────────────────────┘  └──────────────────────────────┘ │
│                                                                  │
└──────────────────────────────────────────────────────────────────┘
                                    │
┌───────────────────────────────────┼──────────────────────────────┐
│                    EXTERNAL APIS  │                              │
├───────────────────────────────────┼──────────────────────────────┤
│                                   │                              │
│  ┌────────────────┐  ┌────────────┴─────────────┐                │
│  │   ElevenLabs   │  │    Shopify Storefront    │                │
│  │  (Voice Agent) │  │         API              │                │
│  └────────────────┘  └──────────────────────────┘                │
│                                                                  │
│  ┌────────────────┐  ┌──────────────────────────┐                │
│  │ Railway APIs   │  │   KCT Knowledge Base     │                │
│  │ (Size/Chat)    │  │   (Trends/Validation)    │                │
│  └────────────────┘  └──────────────────────────┘                │
│                                                                  │
└──────────────────────────────────────────────────────────────────┘
```

---

## Summary

| Feature | Status | Works on Desktop | Works on Mobile |
|---------|--------|------------------|-----------------|
| Style Chat | ✅ Complete | ✅ Yes | ✅ Yes |
| Size Bot | ✅ Complete | ✅ Yes | ✅ Yes |
| Voice Assistant | ⚠️ Partial | ✅ Yes | ⚠️ Issues |

**Mobile Voice Issues Remaining:**
1. "Silence detected" - SDK not receiving mic audio
2. Quick connect/disconnect cycle
3. Possible Cloudflare Rocket Loader interference

**Recommended Next Steps:**
1. Add debug overlay to show token status + input volume level
2. Disable Cloudflare Rocket Loader and retest
3. Test on physical device (not emulator) with HTTPS
4. Verify ElevenLabs agent client tools match code exactly
