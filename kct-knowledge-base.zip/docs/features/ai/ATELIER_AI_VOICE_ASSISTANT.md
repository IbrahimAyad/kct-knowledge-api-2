# Atelier AI Voice Assistant - Technical Documentation

## Overview

The Atelier AI Voice Assistant is a conversational AI interface that allows users to interact via voice or text to get style recommendations, sizing help, and product information. It integrates with the KCT Knowledge API for intelligent responses.

---

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    FloatingActionMenu                        │
│  (Entry point - renders mic button in FAB menu)             │
└─────────────────────┬───────────────────────────────────────┘
                      │
                      ▼
┌─────────────────────────────────────────────────────────────┐
│                    VoiceAssistant                            │
│  (Main component - manages chat UI, recording, processing)  │
└──────────┬──────────────────────────────────┬───────────────┘
           │                                  │
           ▼                                  ▼
┌─────────────────────┐          ┌─────────────────────────────┐
│ VoicePermissionModal│          │  KCT Knowledge API          │
│ (Permission request)│          │  (External AI backend)      │
└──────────┬──────────┘          └─────────────────────────────┘
           │
           ▼
┌─────────────────────┐
│ useVoicePermission  │
│ (Permission hook)   │
└─────────────────────┘
```

---

## File Structure

```
src/
├── components/
│   ├── voice/
│   │   ├── VoiceAssistant.tsx      # Main chat interface
│   │   └── VoicePermissionModal.tsx # Permission request modal
│   └── FloatingActionMenu.tsx       # FAB menu (entry point)
└── hooks/
    └── useVoicePermission.ts        # Microphone permission hook
```

---

## Component Details

### 1. useVoicePermission Hook

**Location:** `src/hooks/useVoicePermission.ts`

Manages browser microphone permissions with the following features:

```typescript
interface VoicePermissionHook {
  permissionState: 'prompt' | 'granted' | 'denied' | 'checking';
  error: string | null;
  requestPermission: () => Promise<boolean>;
  checkPermission: () => Promise<void>;
  isGranted: boolean;
  isDenied: boolean;
  isPrompt: boolean;
}
```

**Key Behaviors:**
- Checks permission on mount (with 100ms delay to prevent render blocking)
- Uses `navigator.permissions.query()` when available
- Falls back to 'prompt' state for browsers without Permissions API
- Handles `NotAllowedError`, `PermissionDeniedError`, `NotFoundError`

**Usage:**
```typescript
const { isGranted, isPrompt, isDenied, requestPermission, error } = useVoicePermission();
```

---

### 2. VoicePermissionModal

**Location:** `src/components/voice/VoicePermissionModal.tsx`

A modal dialog that explains voice features and requests microphone permission.

**Props:**
```typescript
interface VoicePermissionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onPermissionGranted: () => void;
}
```

**Design Elements:**
- Purple gradient icon header with Sparkles icon
- Two info cards explaining features and privacy
- Error state display
- "Permission blocked" help text with browser instructions
- Two CTAs: "Maybe Later" (outline) and "Enable Microphone" (primary)

---

### 3. VoiceAssistant

**Location:** `src/components/voice/VoiceAssistant.tsx`

The main chat interface component.

**Props:**
```typescript
interface VoiceAssistantProps {
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
}
```

**State Management:**
```typescript
const [showPermissionModal, setShowPermissionModal] = useState(false);
const [isListening, setIsListening] = useState(false);
const [isProcessing, setIsProcessing] = useState(false);
const [isSpeaking, setIsSpeaking] = useState(false);
const [messages, setMessages] = useState<Message[]>([]);
const [textInput, setTextInput] = useState('');
```

**Message Interface:**
```typescript
interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}
```

---

## Voice Recording Flow

### 1. Start Recording
```typescript
const startListening = async () => {
  // 1. Check permission
  if (!isGranted) {
    setShowPermissionModal(true);
    return;
  }

  // 2. Get audio stream
  const stream = await navigator.mediaDevices.getUserMedia({ 
    audio: {
      echoCancellation: true,
      noiseSuppression: true,
      autoGainControl: true
    } 
  });

  // 3. Create MediaRecorder
  const mediaRecorder = new MediaRecorder(stream, { 
    mimeType: MediaRecorder.isTypeSupported('audio/webm') ? 'audio/webm' : 'audio/mp4'
  });

  // 4. Collect audio chunks
  mediaRecorder.ondataavailable = (e) => {
    audioChunksRef.current.push(e.data);
  };

  // 5. Process on stop
  mediaRecorder.onstop = async () => {
    const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
    await processVoiceInput(audioBlob);
  };

  mediaRecorder.start();
};
```

### 2. Stop Recording
```typescript
const stopListening = () => {
  if (mediaRecorderRef.current?.state === 'recording') {
    mediaRecorderRef.current.stop();
  }
  setIsListening(false);
};
```

### 3. Process Voice Input
```typescript
const processVoiceInput = async (audioBlob: Blob) => {
  const formData = new FormData();
  formData.append('audio', audioBlob, 'recording.webm');
  formData.append('sessionId', getSessionId());
  formData.append('framework', 'atelier_ai');

  const response = await fetch(`${KCT_API_URL}/api/v3/voice/chat`, {
    method: 'POST',
    body: formData
  });

  const data = await response.json();
  
  // Handle transcription, response text, and audio playback
};
```

---

## API Integration

### KCT Knowledge API - Backend Verification Status

| Component                | Status | Details                                   |
|--------------------------|--------|-------------------------------------------|
| Voice Router Import      | ✅     | src/server.ts:61                          |
| Voice Route Registration | ✅     | /api/v3/voice on line 865                 |
| Public Endpoint          | ✅     | Added to public paths (no API key needed) |
| Chat Service Export      | ✅     | chatService exported line 368             |
| processMessage Method    | ✅     | Exists on line 57                         |
| Voice Service Export     | ✅     | voiceService exported line 667            |
| Logger Utility           | ✅     | Exported from src/utils/logger.ts         |
| Router Export            | ✅     | export default router line 309            |
| suggestedNavigation      | ✅     | Added to response metadata                |
| CORS for Lovable         | ✅     | *.lovable.app allowed                     |
| Audio Formats            | ✅     | webm, wav, mp3, ogg, mpeg                 |
| Dependencies             | ✅     | multer, express-rate-limit installed      |
| Env Vars Documented      | ✅     | OPENAI_API_KEY, ELEVEN_LABS_API_KEY       |

### Complete Data Flow

```
Lovable Frontend → POST /api/v3/voice/chat → voice-routes.ts
                                                   ↓
                                            voiceService.transcribe()
                                            (Whisper STT)
                                                   ↓
                                            chatService.processMessage()
                                            (AI Response Generation)
                                                   ↓
                                            voiceService.synthesize()
                                            (ElevenLabs/OpenAI TTS)
                                                   ↓
                                            Response with audio + navigation
```

### Railway Environment Variables Required

| Variable | Purpose |
|----------|---------|
| `OPENAI_API_KEY` | Whisper transcription (STT) + fallback TTS |
| `ELEVEN_LABS_API_KEY` | Primary voice synthesis (TTS) - optional |

### KCT Knowledge API Endpoints

**Base URL:** `https://kct-knowledge-api-2-production.up.railway.app`

#### 1. Voice Chat Endpoint (Primary)
```
POST /api/v3/voice/chat
Content-Type: multipart/form-data

Body:
- audio: Blob (audio/webm, audio/wav, audio/mp3, audio/ogg, audio/mpeg)
- sessionId: string
- framework: string ("atelier_ai")

Response:
{
  success: boolean,
  transcription: {
    text: string,
    intent: string
  },
  response: {
    text: string,
    audio: string (base64),
    format: string ("mp3")
  },
  metadata: {
    suggestedNavigation: string | null
  }
}
```

#### 2. Text Recommendations Endpoint (Fallback)
```
POST /api/recommendations
Content-Type: application/json

Body:
{
  query: string,
  sessionId: string
}

Response:
{
  message: string,
  response: string
}
```

#### 3. Voice Synthesize Endpoint (Optional)
```
POST /api/v3/voice/synthesize
Content-Type: application/json

Body:
{
  text: string,
  sessionId: string,
  framework: string
}
```

---

## Session Management

Sessions maintain conversation continuity:

```typescript
const getSessionId = (): string => {
  let sessionId = localStorage.getItem('kct_voice_session');
  if (!sessionId) {
    sessionId = `voice_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    localStorage.setItem('kct_voice_session', sessionId);
  }
  return sessionId;
};
```

---

## Audio Playback

```typescript
const playAudioResponse = (base64Audio: string, format: string) => {
  const audio = new Audio(`data:audio/${format};base64,${base64Audio}`);
  audioRef.current = audio;
  
  audio.onended = () => setIsSpeaking(false);
  audio.onerror = () => setIsSpeaking(false);
  audio.play();
};

const stopSpeaking = () => {
  if (audioRef.current) {
    audioRef.current.pause();
    audioRef.current.currentTime = 0;
  }
  setIsSpeaking(false);
};
```

---

## Navigation Handling

The API can suggest navigation based on user intent:

```typescript
const handleNavigation = (intent: string | undefined, metadata: any) => {
  if (!metadata?.suggestedNavigation) return;
  
  // Delay navigation so user can hear/read response
  setTimeout(() => {
    navigate(metadata.suggestedNavigation);
    onOpenChange(false);
  }, 2000);
};
```

---

## Design System

### Color Palette

| Element | Color | HSL Value |
|---------|-------|-----------|
| Primary Gradient Start | Purple | `hsl(280, 70%, 50%)` |
| Primary Gradient End | Deep Purple | `hsl(260, 70%, 40%)` |
| Enable Button | Burgundy | `hsl(0, 72%, 30%)` |

### Component Styling

#### Header
```tsx
<DialogHeader className="bg-gradient-to-r from-[hsl(280_70%_50%)] to-[hsl(260_70%_40%)] text-white">
```

#### User Message Bubble
```tsx
<div className="bg-gradient-to-r from-[hsl(280_70%_50%)] to-[hsl(260_70%_40%)] text-white rounded-2xl rounded-br-md">
```

#### Assistant Message Bubble
```tsx
<div className="bg-muted rounded-2xl rounded-bl-md">
```

#### Send Button
```tsx
<Button className="bg-gradient-to-r from-[hsl(280_70%_50%)] to-[hsl(260_70%_40%)]">
```

### Icons Used
- `Sparkles` - Brand icon
- `Mic` / `MicOff` - Voice recording toggle
- `Volume2` - Audio playing indicator
- `Loader2` - Processing state
- `Send` - Submit text message
- `Shield` - Privacy indicator

---

## UI Layout

```
┌─────────────────────────────────────────┐
│  ✨ Atelier AI                     [X]  │ ← Header (gradient)
├─────────────────────────────────────────┤
│                                         │
│  ┌──────────────────────────────────┐   │
│  │ Hi! I'm Atelier AI...            │   │ ← Assistant bubble (left)
│  └──────────────────────────────────┘   │
│                                         │
│         ┌───────────────────────────┐   │
│         │ Show me burgundy suits    │   │ ← User bubble (right)
│         └───────────────────────────┘   │
│                                         │
│  ┌──────────────────────────────────┐   │
│  │ Great choice! Here are some...   │   │ ← Assistant response
│  └──────────────────────────────────┘   │
│                                         │
├─────────────────────────────────────────┤
│ [🎤] [Type or tap mic to speak    ] [➤] │ ← Input area
│                                         │
│      🎤 Listening... tap when done      │ ← Listening indicator
└─────────────────────────────────────────┘
```

---

## Customization Points

### 1. Change Branding
Update these locations:
- `VoiceAssistant.tsx` line ~73: Initial greeting message
- `VoiceAssistant.tsx` line ~319: Header title
- `VoicePermissionModal.tsx` line ~41: Modal title

### 2. Change Colors
Update gradient colors in:
- `VoiceAssistant.tsx`: Lines 315, 348, 403
- `VoicePermissionModal.tsx`: Lines 37, 54, 104

### 3. Change API Endpoint
```typescript
// VoiceAssistant.tsx line 12
const KCT_API_URL = 'https://your-api-url.com';
```

### 4. Modify Audio Settings
```typescript
// VoiceAssistant.tsx lines 86-91
const stream = await navigator.mediaDevices.getUserMedia({ 
  audio: {
    echoCancellation: true,      // Remove echo
    noiseSuppression: true,      // Reduce background noise
    autoGainControl: true,       // Normalize volume
    sampleRate: 16000,           // Add for specific sample rate
    channelCount: 1              // Mono audio
  } 
});
```

### 5. Change Media Format
```typescript
// VoiceAssistant.tsx line 95
const mimeType = MediaRecorder.isTypeSupported('audio/webm') 
  ? 'audio/webm' 
  : MediaRecorder.isTypeSupported('audio/mp4')
    ? 'audio/mp4'
    : 'audio/ogg';
```

---

## Alternative UI Ideas

### 1. Full-Screen Immersive Mode
Replace Dialog with a full-screen overlay for a more immersive experience.

### 2. Floating Bubble
A small floating bubble that expands on tap, similar to Intercom.

### 3. Bottom Sheet (Mobile-First)
Use `vaul` drawer component for a native mobile feel.

### 4. Inline Widget
Embed directly in product pages for contextual assistance.

### 5. Voice-Only Mode
Remove text input, make it purely voice-driven with visual waveform feedback.

---

## Browser Compatibility

| Feature | Chrome | Firefox | Safari | Edge |
|---------|--------|---------|--------|------|
| MediaRecorder | ✅ | ✅ | ✅ (14.1+) | ✅ |
| getUserMedia | ✅ | ✅ | ✅ | ✅ |
| Permissions API | ✅ | ✅ | ❌ | ✅ |
| audio/webm | ✅ | ✅ | ❌ | ✅ |
| audio/mp4 | ✅ | ❌ | ✅ | ✅ |

---

## Error Handling

| Error | User Message | Recovery |
|-------|--------------|----------|
| `NotAllowedError` | "Microphone access was denied" | Show permission modal |
| `NotFoundError` | "No microphone found" | Suggest text input |
| Network failure | "Unable to process your request" | Retry with text fallback |
| API error | "I'm having trouble connecting" | Generic fallback response |

---

## Performance Considerations

1. **Delayed Permission Check**: 100ms delay prevents blocking initial render
2. **Auto-scroll**: Uses `useEffect` with message dependency
3. **Audio Cleanup**: Tracks are stopped after recording ends
4. **Memory Management**: Refs cleared between recordings

---

## Future Enhancements

1. **Push-to-Talk vs Voice Activity Detection**: Add option for automatic speech detection
2. **Conversation History**: Persist across sessions
3. **Multi-language Support**: Add language selection
4. **Offline Mode**: Cache common responses
5. **Haptic Feedback**: For mobile voice interactions
6. **Waveform Visualization**: Show audio levels while speaking
