# Generated Images Pipeline Documentation

> **Single Source of Truth** for AI-generated outfit images at KCT Menswear
> Last Updated: 2024-12-31

## Overview

This document describes the complete pipeline for generating, storing, and managing AI-created outfit preview images used across the KCT Menswear platform.

---

## Architecture

```
┌─────────────────────┐     ┌──────────────────────┐     ┌─────────────────────┐
│   Frontend UI       │────▶│   Edge Functions     │────▶│   Lovable AI API    │
│   (React/Vite)      │     │   (Supabase)         │     │   (Image Gen)       │
└─────────────────────┘     └──────────────────────┘     └─────────────────────┘
                                      │
                                      ▼
                            ┌──────────────────────┐
                            │   Cloudflare R2      │
                            │   (via kct-images-api)│
                            └──────────────────────┘
                                      │
                                      ▼
                            ┌──────────────────────┐
                            │   Supabase Database  │
                            │   (URL + Metadata)   │
                            └──────────────────────┘
```

---

## Edge Functions

### 1. `generate-outfit-preview`

**Purpose**: Generate outfit images for Wedding Builder and Custom Bundle Builder

**Location**: `supabase/functions/generate-outfit-preview/index.ts`

**Input Parameters**:
| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `jacket_id` | string | No | Product ID for jacket |
| `jacket_color` | string | Yes | Color name (e.g., "Navy", "Charcoal") |
| `jacket_name` | string | No | Display name |
| `shirt_id` | string | No | Product ID for shirt |
| `shirt_color` | string | Yes | Color name |
| `shirt_name` | string | No | Display name |
| `tie_id` | string | No | Product ID for tie |
| `tie_color` | string | Yes | Color name |
| `tie_name` | string | No | Display name |
| `vest_id` | string | No | Product ID for vest |
| `vest_color` | string | No | Color name (required for 3P) |
| `vest_name` | string | No | Display name |
| `suit_type` | string | No | "2P" or "3P" (default: "2P") |
| `neckwear_type` | string | No | "tie" or "bowtie" (default: "tie") |

**Output**:
```json
{
  "imageUrl": "https://imagedelivery.net/.../public",
  "cached": false,
  "createdAt": "2024-12-31T12:00:00.000Z",
  "galleryId": "uuid",
  "originalCacheKey": "navy_white_burgundy_none_2P_tie",
  "feedbackStatus": "pending"
}
```

---

### 2. `generate-quick-style`

**Purpose**: Generate outfit images for Quick Style Builder (simplified 3-step flow)

**Location**: `supabase/functions/generate-quick-style/index.ts`

**Input Parameters**:
| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `occasion` | string | Yes | Event type (e.g., "wedding", "business") |
| `suit` | string | Yes | Suit color (e.g., "navy", "charcoal") |
| `shirt` | string | Yes | Shirt color (e.g., "white", "light-blue") |
| `tie` | string | Yes | Tie color (e.g., "burgundy", "gold") |

**Output**:
```json
{
  "imageUrl": "https://imagedelivery.net/.../public",
  "totalPrice": 229.99
}
```

---

## Image Storage (Cloudflare R2)

### API Endpoint

```
POST https://kct-images-api.kctmenswear.workers.dev/batch-upload
Headers: 
  X-API-Key: {KCT_IMAGES_API_KEY}
  Content-Type: application/json
```

### Request Format

```json
{
  "images": [{
    "base64": "{base64-encoded-image-data}",
    "id": "generated-outfits/navy-white-burgundy-2P-tie_1735689600000",
    "filename": "navy_white_burgundy_none_2P_tie.webp",
    "mimeType": "image/webp",
    "metadata": {
      "source": "outfit-builder",
      "suit_color": "Navy",
      "shirt_color": "White",
      "tie_color": "Burgundy",
      "vest_color": null,
      "suit_type": "2P",
      "neckwear_type": "tie",
      "cache_key": "navy_white_burgundy_none_2P_tie",
      "generated_at": "2024-12-31T12:00:00.000Z"
    }
  }]
}
```

### Response Format

```json
{
  "results": [{
    "success": true,
    "imageId": "generated-outfits/navy-white-burgundy-2P-tie_1735689600000",
    "urls": {
      "public": "https://imagedelivery.net/{account}/{id}/public",
      "og": "https://imagedelivery.net/{account}/{id}/w=1200,h=630,fit=cover",
      "thumbnail": "https://imagedelivery.net/{account}/{id}/thumbnail"
    }
  }]
}
```

### Image Naming Convention

```
generated-outfits/{suit}-{shirt}-{tie}-{suitType}-{neckwear}_{timestamp}.webp

Examples:
- generated-outfits/navy-white-burgundy-2P-tie_1735689600000.webp
- generated-outfits/charcoal-light-blue-gold-3P-bowtie_1735689600000.webp
```

### Metadata Structure

| Field | Description |
|-------|-------------|
| `source` | "outfit-builder" or "quick-style-builder" |
| `suit_color` | Original color name from selection |
| `shirt_color` | Original color name from selection |
| `tie_color` | Original color name from selection |
| `vest_color` | Vest color (null for 2P suits) |
| `suit_type` | "2P" or "3P" |
| `neckwear_type` | "tie" or "bowtie" |
| `cache_key` | Normalized key for caching |
| `generated_at` | ISO timestamp |
| `occasion` | (Quick Style only) Event type |

---

## Database Tables

### `outfit_preview_cache`

**Purpose**: Cache generated images by color combination for reuse across weddings/orders

| Column | Type | Description |
|--------|------|-------------|
| `id` | uuid | Primary key |
| `cache_key` | text | Normalized color combination key |
| `image_url` | text | Cloudflare R2 public URL |
| `outfit_description` | text | AI prompt used |
| `source` | text | "wedding_builder" or "quick_style_builder" |
| `feedback_status` | text | "pending", "approved", "rejected" |
| `created_at` | timestamp | When generated |
| `last_accessed_at` | timestamp | Last cache hit |

### `outfit_preview_gallery`

**Purpose**: Complete gallery of all generated images for review/feedback

| Column | Type | Description |
|--------|------|-------------|
| `id` | uuid | Primary key |
| `original_cache_key` | text | Links to cache entry |
| `image_url` | text | Cloudflare R2 public URL |
| `status` | text | Review status |
| `outfit_description` | text | AI prompt used |
| `created_at` | timestamp | When generated |

---

## Caching Strategy

1. **Cache Key Generation**: Based on normalized colors (not product IDs)
   ```
   {suitColor}_{shirtColor}_{tieColor}_{vestColor|none}_{suitType}_{neckwearType}
   ```

2. **Cache Lookup**: Before generating, check `outfit_preview_cache` for existing image

3. **Cross-Wedding Reuse**: Same color combination = same cached image (saves AI credits)

4. **Cache Hit Response**: Returns existing URL + updates `last_accessed_at`

---

## Error Handling

| Error Code | Meaning | User Message |
|------------|---------|--------------|
| 400 | Missing required colors | "Please ensure all outfit items are selected" |
| 402 | AI credits depleted | "Lovable AI credits depleted. Please add credits." |
| 429 | Rate limit exceeded | "Rate limit exceeded. Please try again later." |
| 500 | Internal error | Error details in response |

---

## Environment Variables

| Variable | Location | Description |
|----------|----------|-------------|
| `LOVABLE_API_KEY` | Supabase secrets | For AI image generation |
| `KCT_IMAGES_API_KEY` | Supabase secrets | For Cloudflare R2 uploads |
| `SUPABASE_URL` | Auto-provided | Database connection |
| `SUPABASE_SERVICE_ROLE_KEY` | Auto-provided | Service role access |

---

## Testing Checklist

- [ ] Generate 2-piece suit with tie
- [ ] Generate 3-piece suit with vest
- [ ] Generate outfit with bowtie
- [ ] Verify cache hit on same colors
- [ ] Verify different products with same colors use cache
- [ ] Check Cloudflare R2 metadata is correct
- [ ] Verify gallery entry created
- [ ] Test rate limit handling
- [ ] Test error states (missing colors)

---

## Future Enhancements

1. **Image Quality Feedback Loop**: Use feedback_status to retrain/improve prompts
2. **Batch Regeneration**: Regenerate rejected images with improved prompts
3. **CDN Optimization**: Use Cloudflare Image variants for responsive sizes
4. **Analytics**: Track most popular color combinations
5. **A/B Testing**: Compare different AI models/prompts

---

## Related Files

### Edge Functions (Backend)
- `supabase/functions/generate-outfit-preview/index.ts` - Wedding/Bundle outfit generation
- `supabase/functions/generate-quick-style/index.ts` - Quick Style Builder generation
- `supabase/functions/kct-images-api/index.ts` - Cloudflare R2 API proxy

### Centralized Data (Single Source of Truth)
- `src/data/builderProducts.ts` - **All product data for builders (suits, shirts, ties, vests)**
  - 12 Suits with R2 CDN URLs and additional gallery images
  - 12 Shirts with R2 CDN URLs
  - 74 Tie colors (synced from database) with hex codes and auras
  - 8 Vests with R2 CDN URLs
- `src/config/paymentConfig.ts` - Payment provider configuration

### Builder Components (Frontend) - Using Centralized Data
- `src/components/wedding/ModernOutfitBuilder.tsx` - ✅ Uses `builderProducts.ts`
- `src/components/style/QuickStyleBuilder.tsx` - ✅ Uses `builderProducts.ts`
- `src/components/wedding/OutfitAssemblyPreview.tsx` - Wedding outfit preview
- `src/components/prom/builder/OutfitPreview.tsx` - Prom outfit preview

### Legacy Data (To Be Migrated)
- `src/data/auraBuilderData.ts` - Prom builder placeholder data with Unsplash URLs
- `src/pages/PromAuraBuilder.tsx` - Uses legacy `auraBuilderData.ts`
- `src/components/prom/builder/BuilderSummary.tsx` - Uses legacy data
- `src/components/prom/builder/ProductCarousel.tsx` - Uses legacy data

**Migration Status:**
| Component | Status | Notes |
|-----------|--------|-------|
| ModernOutfitBuilder | ✅ Migrated | Uses SUITS, SHIRTS, TIE_COLORS |
| QuickStyleBuilder | ✅ Migrated | Uses BUILDER_PREVIEW_IMAGES |
| PromAuraBuilder | ⚠️ Pending | Uses legacy auraBuilderData.ts |
| OutfitAssemblyPreview | ⚠️ Pending | May need review |
