# Blog Hero Image Generation System

## Overview

This system automatically generates professional hero images for blog posts using AI (Gemini) and stores them on Cloudflare Images CDN via the `kct-images-api` worker.

## Architecture

```
┌─────────────────┐     ┌──────────────────────────┐     ┌─────────────────────┐
│   BlogAdmin UI  │────▶│ generate-blog-hero-image │────▶│  Gemini Flash Image │
│  /admin/blog    │     │    (Edge Function)       │     │  (AI Generation)    │
└─────────────────┘     └──────────────────────────┘     └─────────────────────┘
                                    │
                                    ▼
                        ┌──────────────────────────┐
                        │   kct-images-api Worker  │
                        │  (Cloudflare Images CDN) │
                        └──────────────────────────┘
                                    │
                                    ▼
                        ┌──────────────────────────┐
                        │  Supabase content_queue  │
                        │  (image_url + scheduled) │
                        └──────────────────────────┘
```

## Components

### 1. Edge Function: `generate-blog-hero-image`

**Location:** `supabase/functions/generate-blog-hero-image/index.ts`

**What it does:**
1. Receives `blogId`, `prompt`, and `slug` from the request
2. Enhances the prompt for professional magazine-quality output
3. Calls Gemini Flash Image Preview via Lovable AI Gateway
4. Converts base64 image to blob
5. Uploads to Cloudflare Images via `kct-images-api` worker
6. Updates Supabase `content_queue` with `image_url` and sets status to `scheduled`

**Endpoint:** POST `/functions/v1/generate-blog-hero-image`

**Request Body:**
```json
{
  "blogId": "uuid",
  "prompt": "Editorial fashion photography of...",
  "slug": "blog-post-slug"
}
```

**Response:**
```json
{
  "success": true,
  "blogId": "uuid",
  "imageUrl": "https://imagedelivery.net/..."
}
```

### 2. Cloudflare Worker: `kct-images-api`

**URL:** `https://kct-images-api.kctmenswear.workers.dev`

**API Key:** `kct-images-2024-secret` (header: `X-API-Key`)

**Upload Endpoint:** POST `/upload`
- Accepts FormData with `file` and `metadata`
- Returns multiple URL variants (public, thumbnail, og, twitter, etc.)

### 3. BlogAdmin UI Component: `BlogImageGenerator`

**Location:** `src/components/admin/BlogImageGenerator.tsx`

**Features:**
- "Load Blogs" - Fetches blogs needing images (have `image_prompts.hero` but no `image_url`)
- Progress tracking with success/failure counts
- Batch processing (10 at a time with 5-second delays)
- Pause/Resume functionality
- Visual status indicators per blog

## Database Schema

### content_queue.seo_metrics (JSONB)

```json
{
  "image_prompts": {
    "hero": "Editorial fashion photography of...",
    "secondary": "...",
    ...
  },
  "image_url": "https://imagedelivery.net/...",
  "image_generated_at": "2025-12-31T07:23:39Z",
  "slug": "blog-post-slug",
  ...
}
```

## Image Prompt Structure

Hero prompts are stored in `seo_metrics->'image_prompts'->'hero'` and should follow this pattern:

```
Editorial fashion photography of [subject description], 
[setting/venue], [lighting conditions], 
[style keywords: luxury menswear magazine style, professional, etc.], 
no text
```

**Example:**
```
Editorial fashion photography of a confident groom wearing a dusty rose 
pink wool suit with white dress shirt and burgundy tie, standing in an 
elegant indoor venue with soft natural lighting, warm tones, shallow 
depth of field, professional menswear magazine style, sophisticated 
and modern, no text
```

## Usage

### Via BlogAdmin UI

1. Navigate to `/admin/blog`
2. Click "Generate Images" button to show the generator panel
3. Click "Load Blogs" to fetch blogs needing images
4. Click "Start Generation" to begin batch processing
5. Monitor progress - can pause/resume as needed

### Via Edge Function Directly

```typescript
const { data, error } = await supabase.functions.invoke('generate-blog-hero-image', {
  body: {
    blogId: 'blog-uuid',
    prompt: 'Editorial fashion photography of...',
    slug: 'blog-post-slug'
  }
});
```

### Via cURL

```bash
curl -X POST \
  https://gvcswimqaxvylgxbklbz.supabase.co/functions/v1/generate-blog-hero-image \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_ANON_KEY" \
  -d '{
    "blogId": "uuid",
    "prompt": "Editorial fashion photography of...",
    "slug": "blog-slug"
  }'
```

## Rate Limits & Best Practices

1. **Batch Size:** 10 images at a time
2. **Delay Between Batches:** 5 seconds
3. **Image Generation Time:** ~10-15 seconds per image
4. **Image Size:** ~1-1.5MB per generated image

### Recommended Approach for Large Batches

For 75+ blogs:
- Use the UI's batch processing (handles delays automatically)
- Can pause and resume if needed
- Process during off-peak hours if concerned about rate limits

## Cloudflare Image URLs

Images are served from Cloudflare's CDN with multiple variants:

| Variant | URL Pattern | Dimensions |
|---------|-------------|------------|
| Public | `/public` | Original |
| Thumbnail | `/thumbnail` | Small |
| OG Image | `/w=1200,h=630,fit=cover` | 1200x630 |
| Twitter | `/w=1200,h=675,fit=cover` | 1200x675 |
| Instagram | `/w=1080,h=1080,fit=cover` | 1080x1080 |
| Pinterest | `/w=1000,h=1500,fit=cover` | 1000x1500 |

**Example URL:**
```
https://imagedelivery.net/QI-O2U_ayTU_H_Ilcb4c6Q/{image-id}/public
```

## Troubleshooting

### Common Errors

| Error | Cause | Solution |
|-------|-------|----------|
| 401 Unauthorized | Wrong API key header | Use `X-API-Key` not `X-API-Secret` |
| No image URL | Response structure mismatch | Check `urls.public` in response |
| Timeout | Image generation takes too long | Normal for ~15s, don't run parallel |
| Rate limit | Too many requests | Add delays between requests |

### Logs

Check edge function logs:
```
https://supabase.com/dashboard/project/gvcswimqaxvylgxbklbz/functions/generate-blog-hero-image/logs
```

## Status Tracking

After image generation, blogs are automatically set to `scheduled` status. The blog scheduler cron will auto-publish them when `scheduled_date` arrives.

## Files Reference

| File | Purpose |
|------|---------|
| `supabase/functions/generate-blog-hero-image/index.ts` | Main edge function |
| `supabase/functions/kct-images-api/index.ts` | Proxy to Cloudflare Images |
| `src/components/admin/BlogImageGenerator.tsx` | Batch processing UI |
| `src/pages/admin/BlogAdmin.tsx` | Admin page with generator toggle |
| `docs/blog-image-generation.md` | This documentation |

## Quick Stats Query

```sql
-- Count blogs with/without images
SELECT 
  COUNT(*) FILTER (WHERE seo_metrics->>'image_url' IS NOT NULL) as with_images,
  COUNT(*) FILTER (WHERE seo_metrics->>'image_url' IS NULL 
    AND seo_metrics->'image_prompts'->'hero' IS NOT NULL) as needing_images
FROM content_queue;
```
