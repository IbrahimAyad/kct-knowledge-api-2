# Homepage Assets & Themes

This folder contains documentation for homepage themes and seasonal updates.

## Current Theme
**Holiday Theme 2025** - [holiday-theme-2025.md](./holiday-theme-2025.md)

## Image Assets Location
- **Hero images**: `public/images/hero/`
- **Component assets**: `src/assets/`

## Available Hero Images
| Image | Format | Purpose | Status |
|-------|--------|---------|--------|
| `holiday-hero-2025.webp` | WebP | Holiday 2025 hero | **Active** |
| `black-friday-hero-banner.jpg` | JPG | Previous bundle theme | Archive |
| `lifestyle-hero-v2.jpg` | JPG | Lifestyle alternative | Archive |
| `premium-hero-left.jpg` | JPG | Split layout left | Archive |
| `premium-hero-right.jpg` | JPG | Split layout right | Archive |

## How to Switch Themes

1. **Update hero image path** in `src/components/homepage/BlackFridayHero.tsx`
2. **Modify messaging** (badge, headline, subheadline, CTA)
3. **Adjust colors** in `src/index.css` CSS variables
4. **Document the new theme** in this folder

## Seasonal Update Checklist

- [ ] Create new hero image (WebP/JPG, 1920x1080)
- [ ] Update BlackFridayHero.tsx with new image and messaging
- [ ] Update promotional banner in Index.tsx
- [ ] Adjust HolidayProductShowcase scoring if needed
- [ ] Document theme in this folder
- [ ] Archive previous theme documentation

## Past Themes
- [Bundle Theme 2024](../themes/bundle-theme-2024.md)
- [Holiday Theme 2025](./holiday-theme-2025.md)
