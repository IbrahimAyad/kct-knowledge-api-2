# Holiday Theme 2025

## Overview
High-end menswear holiday theme for Christmas/New Year 2025 season.

## Color Palette
```css
--holiday-red: 0 72% 45%      /* Rich crimson */
--holiday-green: 150 60% 30%   /* Deep pine */
--holiday-gold: 42 85% 55%     /* Champagne gold */
--holiday-snow: 210 20% 98%    /* Soft white */
--holiday-pine: 150 40% 25%    /* Forest green */
--holiday-champagne: 45 30% 90% /* Light gold */
```

## Hero Section
- **Component**: `src/components/homepage/BlackFridayHero.tsx`
- **Image**: `public/images/hero/holiday-hero-2025.webp`
- **Fallback**: `public/images/hero/black-friday-hero-banner.jpg`

### Messaging
- Badge: "HOLIDAY COLLECTION 2025"
- Headline: "Celebrate in Style"
- Subheadline: "Ring in 2025 with our curated holiday looks. Suits, bundles & savings to make every gathering unforgettable."
- CTA: "Shop Holiday Looks" → /collections/bundles

### Value Props
- 40+ Holiday Styles
- 25+ Gift-Ready Bundles
- 41 Years of Excellence

## Key Components
1. **BlackFridayHero** - Main hero with holiday messaging
2. **AnimatedTrustBadges** - Trust indicators below hero
3. **QuickStyleBuilder** - Build your own suit tool
4. **HolidayProductShowcase** - Curated holiday products (velvet, shoes, accessories)
5. **BundleTrendingSection** - Trending holiday bundles
6. **FeaturedBundlesCarousel** - Featured bundle carousel

## Section Order (Optimized for Conversion)
1. Hero with holiday messaging
2. Promotional banner (15% off + extended hours)
3. Trust badges
4. Quick Style Builder
5. Holiday Product Showcase
6. Trending Bundles
7. Bundle Categories
8. Featured Bundles Carousel
9. New Arrivals
10. Recently Viewed
11. Personalized Recommendations
12. Wedding CTA
13. Featured Products

## Image Assets
| Image | Path | Purpose |
|-------|------|---------|
| Holiday Hero | `public/images/hero/holiday-hero-2025.webp` | Main hero background |
| Previous Hero | `public/images/hero/black-friday-hero-banner.jpg` | Fallback/archive |

## Typography
- Headlines: Playfair Display (serif)
- Body: System font stack
- Badge text: Bold uppercase tracking-wider

## Animations
- CSS-based fade-in and scale-in (no framer-motion for TBT optimization)
- Staggered delays: 0.2s, 0.3s, 0.4s, 0.5s, 0.6s

## How to Update for Next Season
1. Create new hero image in `public/images/hero/`
2. Update image path in `BlackFridayHero.tsx`
3. Modify messaging (badge, headline, subheadline)
4. Adjust color palette in `index.css` if needed
5. Document new theme in `docs/homepage/`

## Archive
- Bundle Theme 2024: `docs/themes/bundle-theme-2024.md`
