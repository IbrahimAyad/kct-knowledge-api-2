# KCT Menswear: Local vs National Page Strategy

## Overview

KCT Menswear operates a dual-targeting strategy: **national brand presence** for broad reach and **localized pages** for Kalamazoo/Southwest Michigan market dominance. This document defines which pages serve which audience and how Google Ads campaigns should align.

---

## Page Architecture

### National Pages (All Customers)

| Route | Purpose | Target Keywords |
|---|---|---|
| `/wedding` | Wedding homepage hub | "wedding suits", "groomsmen suits" |
| `/wedding-collection` | 4 themed wedding style collections | "classic wedding suits", "modern groom looks" |
| `/wedding-services` | Wedding services overview | "wedding suit packages", "groomsmen outfit services" |
| `/groom-collection` | Groom-specific products | "groom suits", "groom wedding outfit" |
| `/suits` | All suits collection | "men's suits", "buy suits online" |
| `/prom` | Prom suits & tuxedos | "prom suits", "prom tuxedos" |
| `/kalamazoo-custom-tailoring` | Tailoring services (brand name = Kalamazoo Custom Tailoring) | "custom tailoring", "suit alterations" |

### Local Pages (Kalamazoo / Southwest Michigan)

| Route | Purpose | Target Keywords |
|---|---|---|
| `/kalamazoo-weddings` | Local wedding lead-gen landing page | "wedding suits Kalamazoo", "groomsmen Kalamazoo MI" |
| `/kalamazoo-wedding-suits` | Local wedding product collection | "wedding suits near me Kalamazoo", "buy wedding suit Kalamazoo" |

---

## Key Differences

### Wedding Pages

| Aspect | National (`/wedding`, `/wedding-collection`) | Local (`/kalamazoo-weddings`, `/kalamazoo-wedding-suits`) |
|---|---|---|
| **Audience** | Nationwide shoppers | Southwest Michigan (25-mile radius) |
| **SEO focus** | Generic wedding keywords | Geo-modified keywords (city + state) |
| **Content** | Brand story, style guides, collections | Local venues, Michigan testimonials, store hours |
| **Pricing** | Product-level pricing | Tiered packages: Essential $229, Groomsmen $249, Groom $329 |
| **CTAs** | "Shop Now", "View Collection" | "Book Appointment", "Visit Our Store" |
| **Trust signals** | Brand quality, nationwide shipping | Local reviews, venue partnerships, "serving Kalamazoo since..." |
| **Structured data** | Product, Organization | ClothingStore (local), Product with local offers |

### Tailoring

| Aspect | Details |
|---|---|
| **Route** | `/kalamazoo-custom-tailoring` |
| **Note** | KCT = "Kalamazoo Custom Tailoring" — the brand name itself is local, so this page serves both national SEO and local identity |
| **Old route** | `/tailoring` → permanent redirect to new path |

---

## Google Ads Campaign Mapping

### National Campaigns

| Campaign | Target Pages | Audience | Budget Priority |
|---|---|---|---|
| **PMax: KCT Menswear (Maps)** | `/wedding`, `/suits`, homepage | All US, brand awareness | High |
| **Prom Campaign** | `/prom` | National, age 15-18 + parents | Seasonal (Feb-May) |
| **Prom Shopping** | `/prom` product feeds | National, shopping intent | Seasonal (Feb-May) |
| **Wedding_Suits** | `/wedding`, `/wedding-collection`, `/groom-collection` | National, engaged couples | Year-round |

### Local Campaigns

| Campaign | Target Pages | Audience | Budget Priority |
|---|---|---|---|
| **Local Campaign_Prom** | `/prom` | Kalamazoo 25-mile radius | Seasonal |
| **kctmenswear (Alteration)** | `/kalamazoo-custom-tailoring` | Kalamazoo 30-mile radius | Year-round |
| **[Recommended] Local Wedding** | `/kalamazoo-weddings`, `/kalamazoo-wedding-suits` | Kalamazoo 25-mile radius, engaged | Year-round |

### Conversion Tracking

| Conversion Action | Label | Value | Applies To |
|---|---|---|---|
| Purchase | `TJxdCOPPkvQbEMX0tMoD` | Dynamic (order value) | All pages |
| Add to Cart | `IZo2CLPEk_QbEMX0tMoD` | Dynamic (product value) | All pages |
| Begin Checkout | `nQCNCK7Lk_QbEMX0tMoD` | Dynamic (cart value) | All pages |
| Phone Call (tel: click) | `nkoLCNWlhvQbEMX0tMoD` | Fixed $50.00 | All pages |
| Wedding Lead / Contact | `XF5xCJSMiPQbEMX0tMoD` | Fixed $500.00 | `/kalamazoo-weddings` primarily |

### Cross-Domain Attribution

- GCLID and UTM parameters captured from landing URLs
- Appended to Shopify checkout links (`kctmenswear.myshopify.com`)
- Cross-domain linking active for: `kctmenswear.com`, `kctmenswear.myshopify.com`

---

## Redirect Map

All legacy Shopify wedding collection URLs redirect to the appropriate local page:

```
/collections/wedding-suits       → /kalamazoo-wedding-suits
/collections/wedding             → /kalamazoo-wedding-suits
/collections/groomsmen-suits     → /kalamazoo-wedding-suits
/collections/wedding-bundles     → /kalamazoo-wedding-suits
/wedding-signup                  → /kalamazoo-weddings
/local-weddings                  → /kalamazoo-weddings
/tailoring                       → /kalamazoo-custom-tailoring
```

---

## Strategy Summary

```
NATIONAL (broad reach)          LOCAL (market dominance)
─────────────────────          ──────────────────────
/wedding                       /kalamazoo-weddings
/wedding-collection            /kalamazoo-wedding-suits
/wedding-services
/groom-collection
/suits
/prom
                               /kalamazoo-custom-tailoring (dual-purpose)
```

**Goal**: National pages capture high-volume generic traffic. Local pages convert Southwest Michigan customers with hyper-relevant content, store info, and appointment booking. Google Ads campaigns should send local budget exclusively to local pages, and national budget to national pages — never mix targeting with wrong landing pages.
