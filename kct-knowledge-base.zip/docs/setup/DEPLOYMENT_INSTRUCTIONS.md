# 🚀 Phase 2 Deployment Instructions

## Current Status

✅ **Code Complete** - All Phase 2 features built and ready
⏳ **Deployment Pending** - Edge Function needs to be deployed to Supabase

---

## Prerequisites

Before deploying, ensure:

1. **Supabase Project Linked**
   - You have a Supabase project created
   - Project is linked locally

2. **Docker Running** (for local testing)
   - Docker Desktop installed and running
   - OR use Supabase remote deployment (recommended)

3. **Supabase CLI Installed**
   - Already installed at `/usr/local/bin/supabase`

---

## Option 1: Remote Deployment (Recommended)

### Step 1: Link Supabase Project

If not already linked:

```bash
cd /Users/ibrahim/kct-viral-looks-shop
supabase link --project-ref <YOUR_PROJECT_REF>
```

**To find your project ref:**
1. Go to [app.supabase.com](https://app.supabase.com)
2. Select your project
3. Go to Settings → General
4. Copy the "Reference ID"

---

### Step 2: Deploy Edge Function

```bash
cd /Users/ibrahim/kct-viral-looks-shop
supabase functions deploy admin-business-chat
```

This will:
- Bundle the Edge Function
- Upload to Supabase
- Make it available at: `https://<project-ref>.supabase.co/functions/v1/admin-business-chat`

---

### Step 3: Set Environment Variables (if needed)

If you want to use Gemini API:

```bash
supabase secrets set GEMINI_API_KEY=your_key_here
```

---

## Option 2: Local Testing First

### Step 1: Start Supabase Locally

```bash
cd /Users/ibrahim/kct-viral-looks-shop

# Start Docker Desktop first!

# Then start Supabase
supabase start
```

---

### Step 2: Serve Edge Function Locally

```bash
supabase functions serve admin-business-chat
```

This will serve the function at:
`http://localhost:54321/functions/v1/admin-business-chat`

---

### Step 3: Update Frontend to Use Local URL

In `src/pages/admin/BusinessChat.tsx`, temporarily change:

```typescript
// Change from:
const { data, error } = await supabase.functions.invoke('admin-business-chat', {
  body: { question: userMessage.content, sessionId: userEmail }
});

// To (for local testing):
const response = await fetch('http://localhost:54321/functions/v1/admin-business-chat', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${session?.access_token}`
  },
  body: JSON.stringify({
    question: userMessage.content,
    sessionId: userEmail
  })
});
const data = await response.json();
```

---

## Option 3: Manual Deployment via Supabase Dashboard

### Step 1: Go to Supabase Dashboard

1. Visit [app.supabase.com](https://app.supabase.com)
2. Select your project
3. Go to **Edge Functions** in sidebar

---

### Step 2: Create New Function

1. Click **"New function"**
2. Name: `admin-business-chat`
3. Copy contents of `/supabase/functions/admin-business-chat/index.ts`
4. Paste into editor
5. Click **"Deploy"**

---

## Testing After Deployment

### Step 1: Start Development Server

```bash
cd /Users/ibrahim/kct-viral-looks-shop
npm run dev
```

---

### Step 2: Navigate to Business Chat

1. Open `http://localhost:5173`
2. Log in as `kctmenswear@gmail.com`
3. Go to `/account/admin`
4. Click **"Business Chat"** card

---

### Step 3: Test Phase 2 Questions

Try these questions in order:

```
1. "Show me sales metrics for this month"
   → Should return: Total orders, revenue, AOV

2. "What are our top 10 products?"
   → Should return: Product list with units sold and revenue

3. "What's low in stock?"
   → Should return: Products with quantity ≤ 5 OR "All adequately stocked"

4. "How many weddings do we have?"
   → Should return: Total weddings, average party size

5. "What are customers searching for?"
   → Should return: Top search queries from last 7 days
```

---

## Troubleshooting

### Error: "Cannot find project ref"

**Solution**: Link your Supabase project

```bash
supabase link --project-ref <YOUR_PROJECT_REF>
```

---

### Error: "Docker daemon not running"

**Solution**: Start Docker Desktop, then retry

```bash
# Check Docker status
docker --version

# If installed, start Docker Desktop app
open -a Docker
```

---

### Error: "Permission denied" in Edge Function

**Solution**: Check environment variables

```bash
# List current secrets
supabase secrets list

# Verify these exist:
# - SUPABASE_URL
# - SUPABASE_SERVICE_ROLE_KEY
```

---

### No Data Returned from Queries

**Possible causes**:

1. **No data in database**
   - Check if `orders`, `order_items`, `inventory` tables have data
   - Run: `SELECT COUNT(*) FROM orders;` in SQL Editor

2. **Timeframe too narrow**
   - Default is last 30 days
   - Check `created_at` dates in your tables

3. **RLS policies blocking**
   - Edge Function uses `SUPABASE_SERVICE_ROLE_KEY` to bypass RLS
   - Verify key is set correctly

---

## Deployment Checklist

- [ ] Supabase project created
- [ ] Project linked locally (`supabase link`)
- [ ] Edge Function deployed (`supabase functions deploy`)
- [ ] Environment variables set (if using Gemini)
- [ ] Database tables exist with data
- [ ] RLS policies configured
- [ ] Frontend running (`npm run dev`)
- [ ] Can access `/admin/business-chat`
- [ ] Test questions return real data
- [ ] Conversation saved to `admin_chat_conversations` table

---

## Next Steps After Successful Deployment

1. **Test all Phase 2 questions** (see PHASE_2_TESTING.md)
2. **Verify data accuracy** (compare query results to database)
3. **Check performance** (response time < 3 seconds)
4. **Monitor costs** (track token usage in logs)
5. **Optional**: Add Gemini API key for smarter responses

---

## Files Reference

**Edge Function**:
- `/supabase/functions/admin-business-chat/index.ts` - Main function
- `/supabase/functions/admin-business-chat-v2/index.ts` - Alternative V2 version

**Frontend**:
- `/src/pages/admin/BusinessChat.tsx` - Chat UI
- `/src/services/adminChatQueries.ts` - SQL query templates
- `/src/services/blogMetadataAnalyzer.ts` - Blog intelligence

**Documentation**:
- `/docs/ADMIN_CHAT_DATA_AUDIT.md` - Phase 0 audit
- `/docs/PHASE_1_POC_TESTING.md` - Phase 1 testing
- `/docs/PHASE_2_TESTING.md` - Phase 2 testing
- `/docs/DEPLOYMENT_INSTRUCTIONS.md` - This file

---

## Support

If deployment fails, provide:
1. Exact error message
2. Supabase CLI version (`supabase --version`)
3. Docker status (`docker --version`)
4. Project ref (from Supabase dashboard)

---

**Ready to deploy!** Choose your preferred option above and follow the steps.
