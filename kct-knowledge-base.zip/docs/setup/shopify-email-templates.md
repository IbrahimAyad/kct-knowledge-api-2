# Custom Shopify Email Templates

These are enhanced, branded email templates for your headless Shopify store. Copy each template into your Shopify Admin → Settings → Notifications.

**Your domain:** `kctmenswear.com` (already configured in all templates below)

---

## 1. Order Confirmation (Enhanced with Full Shopify Logic)

**Location:** Shopify Admin → Settings → Notifications → Order confirmation

This template keeps Shopify's robust handling for:
- ✅ Bundle products with nested items
- ✅ Split fulfillment (shipping vs in-store pickup)
- ✅ Multiple discount types (product, order, shipping)
- ✅ "You saved" calculation
- ✅ Pending payment handling
- ✅ Estimated delivery dates

```liquid
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Order Confirmation - {{ shop.name }}</title>
  <style>
    body { margin: 0; padding: 0; background-color: #f8f8f8; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; }
    .container { max-width: 600px; margin: 0 auto; background-color: #ffffff; }
    .header { background-color: #000000; padding: 30px 40px; text-align: center; }
    .header img { max-height: 40px; }
    .header h1 { color: #ffffff; font-size: 24px; font-weight: 300; letter-spacing: 2px; margin: 0; }
    .content { padding: 40px; }
    .hero { text-align: center; padding-bottom: 30px; border-bottom: 1px solid #e5e5e5; margin-bottom: 30px; }
    .hero h2 { font-size: 28px; font-weight: 600; color: #1a1a1a; margin: 0 0 10px 0; }
    .hero p { color: #666666; font-size: 16px; margin: 0; }
    .order-number { display: inline-block; background-color: #f5f5f5; padding: 8px 16px; border-radius: 4px; font-family: monospace; font-size: 14px; color: #333; margin-top: 15px; }
    .pending-notice { background-color: #fff3cd; border: 1px solid #ffc107; padding: 15px 20px; border-radius: 8px; margin-bottom: 25px; }
    .pending-notice p { margin: 0; color: #856404; font-size: 14px; }
    .section { margin-bottom: 30px; }
    .section-title { font-size: 14px; font-weight: 600; text-transform: uppercase; letter-spacing: 1px; color: #999999; margin-bottom: 15px; border-bottom: 1px solid #eee; padding-bottom: 10px; }
    .fulfillment-group { margin-bottom: 25px; }
    .fulfillment-label { font-size: 13px; font-weight: 600; color: #333; margin-bottom: 10px; background-color: #f5f5f5; padding: 8px 12px; border-radius: 4px; }
    .item { display: table; width: 100%; padding: 15px 0; border-bottom: 1px solid #f0f0f0; }
    .item:last-child { border-bottom: none; }
    .item-image-cell { display: table-cell; width: 80px; vertical-align: top; }
    .item-image { width: 70px; height: 90px; object-fit: cover; border-radius: 4px; background-color: #f5f5f5; border: 1px solid #eee; }
    .item-details-cell { display: table-cell; vertical-align: top; padding-left: 15px; }
    .item-price-cell { display: table-cell; width: 100px; vertical-align: top; text-align: right; }
    .item-title { font-size: 15px; font-weight: 500; color: #1a1a1a; margin: 0 0 5px 0; }
    .item-variant { font-size: 13px; color: #666666; margin: 0 0 3px 0; }
    .item-qty { font-size: 13px; color: #999999; }
    .item-discount { display: inline-flex; align-items: center; font-size: 12px; color: #2e7d32; margin-top: 5px; }
    .item-discount svg { width: 14px; height: 14px; margin-right: 4px; }
    .item-original-price { font-size: 13px; color: #999; text-decoration: line-through; }
    .item-final-price { font-size: 15px; font-weight: 500; color: #1a1a1a; }
    .bundle-children { margin-left: 20px; padding-left: 15px; border-left: 2px solid #e5e5e5; margin-top: 10px; }
    .bundle-child-item { display: table; width: 100%; padding: 8px 0; }
    .bundle-child-image { width: 40px; height: 50px; object-fit: cover; border-radius: 3px; background-color: #f5f5f5; }
    .bundle-child-title { font-size: 13px; color: #666; }
    .summary { background-color: #fafafa; padding: 20px; border-radius: 8px; }
    .summary-row { display: table; width: 100%; padding: 8px 0; font-size: 14px; color: #666666; }
    .summary-label { display: table-cell; text-align: left; }
    .summary-value { display: table-cell; text-align: right; }
    .summary-row.discount { color: #2e7d32; }
    .discount-code { display: inline-flex; align-items: center; font-size: 12px; color: #666; margin-top: 2px; }
    .discount-code svg { width: 12px; height: 12px; margin-right: 4px; }
    .summary-row.total { border-top: 2px solid #e5e5e5; margin-top: 10px; padding-top: 15px; font-size: 18px; font-weight: 600; color: #1a1a1a; }
    .summary-row.savings { font-size: 14px; color: #2e7d32; font-weight: 500; }
    .address-grid { display: table; width: 100%; }
    .address-box { display: table-cell; width: 50%; vertical-align: top; padding-right: 15px; }
    .address-box:last-child { padding-right: 0; padding-left: 15px; }
    .address-box h4 { font-size: 14px; font-weight: 600; text-transform: uppercase; letter-spacing: 1px; color: #999999; margin: 0 0 10px 0; }
    .address-box p { margin: 0; font-size: 14px; line-height: 1.6; color: #333333; }
    .payment-info { background-color: #f5f5f5; padding: 15px; border-radius: 6px; margin-top: 20px; }
    .payment-info h4 { font-size: 14px; font-weight: 600; color: #333; margin: 0 0 10px 0; }
    .payment-info p { font-size: 13px; color: #666; margin: 0; }
    .shipping-method { margin-top: 20px; padding: 15px; background-color: #f9f9f9; border-radius: 6px; }
    .shipping-method h4 { font-size: 14px; font-weight: 600; color: #333; margin: 0 0 5px 0; }
    .shipping-method p { font-size: 13px; color: #666; margin: 0; }
    .track-order { background-color: #f8f5f0; padding: 30px; text-align: center; border-radius: 8px; margin: 30px 0; }
    .track-order h3 { font-size: 18px; font-weight: 600; color: #1a1a1a; margin: 0 0 10px 0; }
    .track-order p { font-size: 14px; color: #666666; margin: 0 0 20px 0; }
    .btn { display: inline-block; background-color: #000000; color: #ffffff; padding: 14px 32px; text-decoration: none; border-radius: 4px; font-weight: 600; font-size: 14px; letter-spacing: 0.5px; }
    .btn:hover { background-color: #333333; }
    .btn-secondary { display: inline-block; color: #000000; padding: 10px 20px; text-decoration: none; font-size: 14px; }
    .footer { background-color: #1a1a1a; padding: 40px; text-align: center; }
    .footer p { color: #999999; font-size: 12px; margin: 5px 0; }
    .footer a { color: #cccccc; text-decoration: none; }
    .social-links { margin: 20px 0; }
    .social-links a { display: inline-block; margin: 0 10px; color: #ffffff; text-decoration: none; }
  </style>
</head>
<body>
  <div class="container">
    <!-- Header -->
    <div class="header">
      {% if shop.email_logo_url %}
        <img src="{{ shop.email_logo_url }}" alt="{{ shop.name }}">
      {% else %}
        <h1>{{ shop.name | upcase }}</h1>
      {% endif %}
    </div>

    <!-- Content -->
    <div class="content">
      <!-- Hero Section -->
      <div class="hero">
        <h2>Thank You for Your Order!</h2>
        {% if requires_shipping and fulfillment_aborted %}
          <p>Your order has been updated.</p>
        {% elsif pending %}
          <p>Your order is confirmed. Payment is pending.</p>
        {% else %}
          <p>We're preparing your items with care.</p>
        {% endif %}
        <div class="order-number">Order {{ order_name }}</div>
      </div>

      <!-- Pending Payment Notice -->
      {% if pending %}
      <div class="pending-notice">
        <p><strong>Payment Pending:</strong> We'll start processing your order once payment is received. 
        {% if gateway == 'ShopifyPayments' and payment_terms and payment_terms.type == 'receipt' %}
          Payment is due upon receipt.
        {% endif %}
        </p>
      </div>
      {% endif %}

      <!-- View Order Button -->
      <div style="text-align: center; margin-bottom: 30px;">
        <a href="https://kctmenswear.com/order-lookup?order={{ order_name | url_encode }}&email={{ email | url_encode }}" class="btn">View Your Order</a>
        <br>
        <a href="https://kctmenswear.com" class="btn-secondary">or Visit Our Store</a>
      </div>

      <!-- Order Items - Grouped by Fulfillment Type -->
      <div class="section">
        <div class="section-title">Order Summary</div>
        
        {% assign shipping_items = line_items | where: "requires_shipping" %}
        {% assign pickup_items = line_items | where: "requires_shipping", false %}
        
        <!-- Shipping Items -->
        {% if shipping_items.size > 0 %}
        <div class="fulfillment-group">
          {% if pickup_items.size > 0 %}
            <div class="fulfillment-label">📦 Shipping Items</div>
          {% endif %}
          {% for line in shipping_items %}
          <div class="item">
            <div class="item-image-cell">
              {% if line.image %}
                <img src="{{ line | img_url: 'compact_cropped' }}" alt="{{ line.title }}" class="item-image">
              {% else %}
                <div class="item-image" style="display: flex; align-items: center; justify-content: center; color: #ccc;">
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="m21 15-5-5L5 21"/></svg>
                </div>
              {% endif %}
            </div>
            <div class="item-details-cell">
              <p class="item-title">{{ line.title }}{% if line.quantity > 1 %} × {{ line.quantity }}{% endif %}</p>
              {% if line.variant_title and line.variant_title != 'Default Title' %}
                <p class="item-variant">{{ line.variant_title }}</p>
              {% endif %}
              {% for discount in line.discount_allocations %}
                {% if discount.discount_application.title %}
                <div class="item-discount">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"/><line x1="7" y1="7" x2="7.01" y2="7"/></svg>
                  {{ discount.discount_application.title }} (-{{ discount.amount | money }})
                </div>
                {% endif %}
              {% endfor %}
              <!-- Bundle Children -->
              {% if line.line_components.size > 0 %}
              <div class="bundle-children">
                {% for component in line.line_components %}
                <div class="bundle-child-item">
                  <div style="display: table-cell; width: 50px; vertical-align: middle;">
                    {% if component.image %}
                      <img src="{{ component | img_url: 'thumb' }}" alt="{{ component.title }}" class="bundle-child-image">
                    {% endif %}
                  </div>
                  <div style="display: table-cell; vertical-align: middle; padding-left: 10px;">
                    <span class="bundle-child-title">{{ component.quantity }} × {{ component.title }}</span>
                  </div>
                </div>
                {% endfor %}
              </div>
              {% endif %}
            </div>
            <div class="item-price-cell">
              {% if line.original_line_price != line.final_line_price %}
                <span class="item-original-price">{{ line.original_line_price | money }}</span><br>
              {% endif %}
              <span class="item-final-price">{{ line.final_line_price | money }}</span>
            </div>
          </div>
          {% endfor %}
        </div>
        {% endif %}

        <!-- In-Store Pickup Items -->
        {% if pickup_items.size > 0 %}
        <div class="fulfillment-group">
          <div class="fulfillment-label">🏪 In-Store Pickup Items</div>
          {% for line in pickup_items %}
          <div class="item">
            <div class="item-image-cell">
              {% if line.image %}
                <img src="{{ line | img_url: 'compact_cropped' }}" alt="{{ line.title }}" class="item-image">
              {% else %}
                <div class="item-image" style="display: flex; align-items: center; justify-content: center; color: #ccc;">
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="m21 15-5-5L5 21"/></svg>
                </div>
              {% endif %}
            </div>
            <div class="item-details-cell">
              <p class="item-title">{{ line.title }}{% if line.quantity > 1 %} × {{ line.quantity }}{% endif %}</p>
              {% if line.variant_title and line.variant_title != 'Default Title' %}
                <p class="item-variant">{{ line.variant_title }}</p>
              {% endif %}
              {% for discount in line.discount_allocations %}
                {% if discount.discount_application.title %}
                <div class="item-discount">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"/><line x1="7" y1="7" x2="7.01" y2="7"/></svg>
                  {{ discount.discount_application.title }} (-{{ discount.amount | money }})
                </div>
                {% endif %}
              {% endfor %}
              <!-- Bundle Children -->
              {% if line.line_components.size > 0 %}
              <div class="bundle-children">
                {% for component in line.line_components %}
                <div class="bundle-child-item">
                  <div style="display: table-cell; width: 50px; vertical-align: middle;">
                    {% if component.image %}
                      <img src="{{ component | img_url: 'thumb' }}" alt="{{ component.title }}" class="bundle-child-image">
                    {% endif %}
                  </div>
                  <div style="display: table-cell; vertical-align: middle; padding-left: 10px;">
                    <span class="bundle-child-title">{{ component.quantity }} × {{ component.title }}</span>
                  </div>
                </div>
                {% endfor %}
              </div>
              {% endif %}
            </div>
            <div class="item-price-cell">
              {% if line.original_line_price != line.final_line_price %}
                <span class="item-original-price">{{ line.original_line_price | money }}</span><br>
              {% endif %}
              <span class="item-final-price">{{ line.final_line_price | money }}</span>
            </div>
          </div>
          {% endfor %}
        </div>
        {% endif %}
      </div>

      <!-- Order Summary Totals -->
      <div class="section">
        <div class="summary">
          <div class="summary-row">
            <span class="summary-label">Subtotal</span>
            <span class="summary-value">{{ subtotal_price | money }}</span>
          </div>
          
          <!-- Order-level Discounts -->
          {% for discount_application in discount_applications %}
            {% if discount_application.target_selection == 'all' or discount_application.target_selection == 'entitled' %}
              {% if discount_application.type != 'shipping_discount' %}
              <div class="summary-row discount">
                <span class="summary-label">
                  <span class="discount-code">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"/><line x1="7" y1="7" x2="7.01" y2="7"/></svg>
                    {{ discount_application.title }}
                  </span>
                </span>
                <span class="summary-value">-{{ discount_application.total_allocated_amount | money }}</span>
              </div>
              {% endif %}
            {% endif %}
          {% endfor %}
          
          <!-- Shipping -->
          <div class="summary-row">
            <span class="summary-label">Shipping</span>
            <span class="summary-value">
              {% if original_shipping_price != shipping_price %}
                <span style="text-decoration: line-through; color: #999;">{{ original_shipping_price | money }}</span>
              {% endif %}
              {% if shipping_price > 0 %}{{ shipping_price | money }}{% else %}Free{% endif %}
            </span>
          </div>
          
          <!-- Shipping Discounts -->
          {% for discount_application in discount_applications %}
            {% if discount_application.type == 'shipping_discount' %}
            <div class="summary-row discount">
              <span class="summary-label">
                <span class="discount-code">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"/><line x1="7" y1="7" x2="7.01" y2="7"/></svg>
                  {{ discount_application.title }}
                </span>
              </span>
              <span class="summary-value">-{{ discount_application.total_allocated_amount | money }}</span>
            </div>
            {% endif %}
          {% endfor %}
          
          <!-- Taxes -->
          {% if tax_price > 0 %}
          <div class="summary-row">
            <span class="summary-label">Taxes</span>
            <span class="summary-value">{{ tax_price | money }}</span>
          </div>
          {% else %}
          <div class="summary-row">
            <span class="summary-label">Taxes</span>
            <span class="summary-value">$0.00</span>
          </div>
          {% endif %}
          
          <!-- Total -->
          <div class="summary-row total">
            <span class="summary-label">Total</span>
            <span class="summary-value">{{ total_price | money }} {{ currency }}</span>
          </div>
          
          <!-- You Saved -->
          {% assign total_discounts = 0 %}
          {% for discount_application in discount_applications %}
            {% assign total_discounts = total_discounts | plus: discount_application.total_allocated_amount %}
          {% endfor %}
          {% if total_discounts > 0 %}
          <div class="summary-row savings">
            <span class="summary-label"></span>
            <span class="summary-value">You saved {{ total_discounts | money }}</span>
          </div>
          {% endif %}
        </div>
      </div>

      <!-- Customer Information -->
      <div class="section">
        <div class="section-title">Customer Information</div>
        <div class="address-grid">
          {% if requires_shipping and shipping_address %}
          <div class="address-box">
            <h4>Shipping Address</h4>
            <p>
              {{ shipping_address.name }}<br>
              {% if shipping_address.company %}{{ shipping_address.company }}<br>{% endif %}
              {{ shipping_address.address1 }}<br>
              {% if shipping_address.address2 %}{{ shipping_address.address2 }}<br>{% endif %}
              {{ shipping_address.city }}, {{ shipping_address.province_code }} {{ shipping_address.zip }}<br>
              {{ shipping_address.country }}
            </p>
          </div>
          {% endif %}
          {% if billing_address %}
          <div class="address-box">
            <h4>Billing Address</h4>
            <p>
              {{ billing_address.name }}<br>
              {% if billing_address.company %}{{ billing_address.company }}<br>{% endif %}
              {{ billing_address.address1 }}<br>
              {% if billing_address.address2 %}{{ billing_address.address2 }}<br>{% endif %}
              {{ billing_address.city }}, {{ billing_address.province_code }} {{ billing_address.zip }}<br>
              {{ billing_address.country }}
            </p>
          </div>
          {% endif %}
        </div>

        <!-- Payment Method -->
        {% if transactions.size > 0 %}
        <div class="payment-info">
          <h4>Payment</h4>
          {% for transaction in transactions %}
            {% if transaction.status == 'success' or transaction.status == 'pending' %}
              <p>
                {% if transaction.payment_details.credit_card_company %}
                  {{ transaction.payment_details.credit_card_company }} ending in {{ transaction.payment_details.credit_card_last_four_digits }}
                {% else %}
                  {{ transaction.gateway_display_name }}
                {% endif %}
                {% if transaction.status == 'pending' %} (Pending){% endif %}
              </p>
            {% endif %}
          {% endfor %}
        </div>
        {% endif %}

        <!-- Shipping Method -->
        {% if requires_shipping and shipping_method %}
        <div class="shipping-method">
          <h4>Shipping Method</h4>
          <p>{{ shipping_method.title }}
            {% if delivery_instructions %}
              <br><em>Note: {{ delivery_instructions }}</em>
            {% endif %}
          </p>
        </div>
        {% endif %}
      </div>

      <!-- Track Order CTA -->
      <div class="track-order">
        <h3>Track Your Order</h3>
        <p>View your order status anytime using your order number and email.</p>
        <a href="https://kctmenswear.com/order-lookup?order={{ order_name | url_encode }}&email={{ email | url_encode }}" class="btn">Track Order →</a>
      </div>

      <p style="text-align: center; color: #666666; font-size: 14px;">
        Questions about your order? <a href="https://kctmenswear.com/contact" style="color: #000000;">Contact us</a> or reply to this email.
      </p>
    </div>

    <!-- Footer -->
    <div class="footer">
      <div class="social-links">
        <a href="#">Instagram</a> • <a href="#">Facebook</a>
      </div>
      <p>{{ shop.name }}</p>
      <p>{{ shop.address }}</p>
      <p><a href="https://kctmenswear.com">Visit our store</a></p>
    </div>
  </div>
</body>
</html>
```

---

## 2. Shipping Confirmation

**Location:** Shopify Admin → Settings → Notifications → Shipping confirmation

```liquid
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Your Order Has Shipped - {{ shop.name }}</title>
  <style>
    body { margin: 0; padding: 0; background-color: #f8f8f8; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; }
    .container { max-width: 600px; margin: 0 auto; background-color: #ffffff; }
    .header { background-color: #000000; padding: 30px 40px; text-align: center; }
    .header h1 { color: #ffffff; font-size: 24px; font-weight: 300; letter-spacing: 2px; margin: 0; }
    .content { padding: 40px; }
    .hero { text-align: center; padding-bottom: 30px; border-bottom: 1px solid #e5e5e5; margin-bottom: 30px; }
    .hero-icon { font-size: 48px; margin-bottom: 15px; }
    .hero h2 { font-size: 28px; font-weight: 600; color: #1a1a1a; margin: 0 0 10px 0; }
    .hero p { color: #666666; font-size: 16px; margin: 0; }
    .tracking-box { background-color: #f8f5f0; padding: 25px; border-radius: 8px; text-align: center; margin-bottom: 30px; }
    .tracking-box h3 { font-size: 14px; font-weight: 600; text-transform: uppercase; letter-spacing: 1px; color: #999999; margin: 0 0 10px 0; }
    .tracking-number { font-family: monospace; font-size: 18px; font-weight: 600; color: #1a1a1a; background-color: #ffffff; padding: 12px 20px; border-radius: 4px; display: inline-block; margin-bottom: 15px; }
    .carrier { font-size: 14px; color: #666666; margin-bottom: 20px; }
    .btn { display: inline-block; background-color: #000000; color: #ffffff; padding: 14px 32px; text-decoration: none; border-radius: 4px; font-weight: 600; font-size: 14px; }
    .btn-secondary { background-color: transparent; border: 2px solid #000000; color: #000000; margin-left: 10px; }
    .section { margin-bottom: 30px; }
    .section-title { font-size: 14px; font-weight: 600; text-transform: uppercase; letter-spacing: 1px; color: #999999; margin-bottom: 15px; }
    .item { display: flex; padding: 15px 0; border-bottom: 1px solid #f0f0f0; }
    .item:last-child { border-bottom: none; }
    .item-image { width: 70px; height: 90px; object-fit: cover; border-radius: 4px; margin-right: 15px; background-color: #f5f5f5; }
    .item-details { flex: 1; }
    .item-title { font-size: 15px; font-weight: 500; color: #1a1a1a; margin: 0 0 5px 0; }
    .item-variant { font-size: 13px; color: #666666; margin: 0; }
    .shipping-address { background-color: #fafafa; padding: 20px; border-radius: 8px; }
    .shipping-address p { margin: 0; font-size: 14px; line-height: 1.6; color: #333333; }
    .footer { background-color: #1a1a1a; padding: 40px; text-align: center; }
    .footer p { color: #999999; font-size: 12px; margin: 5px 0; }
    .footer a { color: #cccccc; text-decoration: none; }
  </style>
</head>
<body>
  <div class="container">
    <!-- Header -->
    <div class="header">
      {% if shop.email_logo_url %}
        <img src="{{ shop.email_logo_url }}" alt="{{ shop.name }}" style="max-height: 40px;">
      {% else %}
        <h1>{{ shop.name | upcase }}</h1>
      {% endif %}
    </div>

    <!-- Content -->
    <div class="content">
      <!-- Hero Section -->
      <div class="hero">
        <div class="hero-icon">📦</div>
        <h2>Your Order is On Its Way!</h2>
        <p>Order {{ order_name }} has been shipped and is heading to you.</p>
      </div>

      <!-- Tracking Info -->
      <div class="tracking-box">
        <h3>Tracking Information</h3>
        {% if fulfillment.tracking_number %}
          <div class="tracking-number">{{ fulfillment.tracking_number }}</div>
          <p class="carrier">via {{ fulfillment.tracking_company }}</p>
          {% if fulfillment.tracking_url %}
            <a href="{{ fulfillment.tracking_url }}" class="btn">Track with Carrier</a>
          {% endif %}
        {% else %}
          <p style="color: #666666;">Tracking information will be available soon.</p>
        {% endif %}
        <a href="https://kctmenswear.com/order-lookup" class="btn btn-secondary">Track on Our Site</a>
      </div>

      <!-- Shipped Items -->
      <div class="section">
        <div class="section-title">Items in This Shipment</div>
        {% for line in fulfillment.fulfillment_line_items %}
        <div class="item">
          {% if line.line_item.image %}
            <img src="{{ line.line_item | img_url: 'compact_cropped' }}" alt="{{ line.line_item.title }}" class="item-image">
          {% endif %}
          <div class="item-details">
            <p class="item-title">{{ line.line_item.title }}</p>
            {% if line.line_item.variant_title != 'Default Title' %}
              <p class="item-variant">{{ line.line_item.variant_title }} • Qty: {{ line.quantity }}</p>
            {% else %}
              <p class="item-variant">Qty: {{ line.quantity }}</p>
            {% endif %}
          </div>
        </div>
        {% endfor %}
      </div>

      <!-- Shipping Address -->
      <div class="section">
        <div class="section-title">Shipping To</div>
        <div class="shipping-address">
          <p>
            {{ shipping_address.name }}<br>
            {{ shipping_address.address1 }}<br>
            {% if shipping_address.address2 %}{{ shipping_address.address2 }}<br>{% endif %}
            {{ shipping_address.city }}, {{ shipping_address.province_code }} {{ shipping_address.zip }}<br>
            {{ shipping_address.country }}
          </p>
        </div>
      </div>

      <p style="text-align: center; color: #666666; font-size: 14px;">
        Questions? <a href="https://kctmenswear.com/contact" style="color: #000000;">Contact our support team</a>
      </p>
    </div>

    <!-- Footer -->
    <div class="footer">
      <p>{{ shop.name }}</p>
      <p><a href="{{ shop.url }}">Visit our store</a></p>
    </div>
  </div>
</body>
</html>
```

---

## 3. Shipping Update

**Location:** Shopify Admin → Settings → Notifications → Shipping update

```liquid
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Shipping Update - {{ shop.name }}</title>
  <style>
    body { margin: 0; padding: 0; background-color: #f8f8f8; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; }
    .container { max-width: 600px; margin: 0 auto; background-color: #ffffff; }
    .header { background-color: #000000; padding: 30px 40px; text-align: center; }
    .header h1 { color: #ffffff; font-size: 24px; font-weight: 300; letter-spacing: 2px; margin: 0; }
    .content { padding: 40px; }
    .hero { text-align: center; padding-bottom: 30px; margin-bottom: 30px; }
    .hero-icon { font-size: 48px; margin-bottom: 15px; }
    .hero h2 { font-size: 26px; font-weight: 600; color: #1a1a1a; margin: 0 0 10px 0; }
    .hero p { color: #666666; font-size: 16px; margin: 0; }
    .update-box { background-color: #e8f5e9; border-left: 4px solid #4caf50; padding: 20px; margin-bottom: 30px; }
    .update-box h3 { font-size: 16px; font-weight: 600; color: #2e7d32; margin: 0 0 5px 0; }
    .update-box p { color: #333333; font-size: 14px; margin: 0; }
    .tracking-box { background-color: #f8f5f0; padding: 25px; border-radius: 8px; text-align: center; margin-bottom: 30px; }
    .tracking-number { font-family: monospace; font-size: 16px; font-weight: 600; color: #1a1a1a; }
    .btn { display: inline-block; background-color: #000000; color: #ffffff; padding: 14px 32px; text-decoration: none; border-radius: 4px; font-weight: 600; font-size: 14px; margin-top: 15px; }
    .footer { background-color: #1a1a1a; padding: 40px; text-align: center; }
    .footer p { color: #999999; font-size: 12px; margin: 5px 0; }
    .footer a { color: #cccccc; text-decoration: none; }
  </style>
</head>
<body>
  <div class="container">
    <!-- Header -->
    <div class="header">
      {% if shop.email_logo_url %}
        <img src="{{ shop.email_logo_url }}" alt="{{ shop.name }}" style="max-height: 40px;">
      {% else %}
        <h1>{{ shop.name | upcase }}</h1>
      {% endif %}
    </div>

    <!-- Content -->
    <div class="content">
      <!-- Hero Section -->
      <div class="hero">
        <div class="hero-icon">🚚</div>
        <h2>Shipping Update</h2>
        <p>Here's the latest on your order {{ order_name }}</p>
      </div>

      <!-- Update Message -->
      <div class="update-box">
        <h3>Status Update</h3>
        <p>Your package is on its way! Check the tracking link below for real-time updates.</p>
      </div>

      <!-- Tracking Info -->
      <div class="tracking-box">
        {% if fulfillment.tracking_number %}
          <p style="margin: 0 0 5px 0; color: #666666; font-size: 14px;">Tracking Number</p>
          <p class="tracking-number">{{ fulfillment.tracking_number }}</p>
          <p style="margin: 10px 0 0 0; color: #666666; font-size: 14px;">via {{ fulfillment.tracking_company }}</p>
          {% if fulfillment.tracking_url %}
            <a href="{{ fulfillment.tracking_url }}" class="btn">Track Package</a>
          {% endif %}
        {% endif %}
        <br><br>
        <a href="https://kctmenswear.com/order-lookup" style="color: #000000; font-size: 14px;">Or track on our website →</a>
      </div>

      <p style="text-align: center; color: #666666; font-size: 14px;">
        Need help? <a href="https://kctmenswear.com/contact" style="color: #000000;">Contact us</a>
      </p>
    </div>

    <!-- Footer -->
    <div class="footer">
      <p>{{ shop.name }}</p>
      <p><a href="{{ shop.url }}">Visit our store</a></p>
    </div>
  </div>
</body>
</html>
```

---

## 4. Order Cancelled

**Location:** Shopify Admin → Settings → Notifications → Order cancelled

```liquid
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Order Cancelled - {{ shop.name }}</title>
  <style>
    body { margin: 0; padding: 0; background-color: #f8f8f8; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; }
    .container { max-width: 600px; margin: 0 auto; background-color: #ffffff; }
    .header { background-color: #000000; padding: 30px 40px; text-align: center; }
    .header h1 { color: #ffffff; font-size: 24px; font-weight: 300; letter-spacing: 2px; margin: 0; }
    .content { padding: 40px; }
    .hero { text-align: center; padding-bottom: 30px; border-bottom: 1px solid #e5e5e5; margin-bottom: 30px; }
    .hero h2 { font-size: 26px; font-weight: 600; color: #1a1a1a; margin: 0 0 10px 0; }
    .hero p { color: #666666; font-size: 16px; margin: 0; }
    .order-number { display: inline-block; background-color: #f5f5f5; padding: 8px 16px; border-radius: 4px; font-family: monospace; font-size: 14px; color: #333; margin-top: 15px; }
    .info-box { background-color: #fff3e0; border-left: 4px solid #ff9800; padding: 20px; margin-bottom: 30px; }
    .info-box p { color: #333333; font-size: 14px; margin: 0; line-height: 1.6; }
    .section { margin-bottom: 30px; }
    .section-title { font-size: 14px; font-weight: 600; text-transform: uppercase; letter-spacing: 1px; color: #999999; margin-bottom: 15px; }
    .item { display: flex; padding: 12px 0; border-bottom: 1px solid #f0f0f0; }
    .item:last-child { border-bottom: none; }
    .item-title { font-size: 14px; color: #666666; flex: 1; }
    .item-price { font-size: 14px; color: #666666; text-decoration: line-through; }
    .cta-box { background-color: #f8f5f0; padding: 30px; text-align: center; border-radius: 8px; }
    .cta-box h3 { font-size: 18px; font-weight: 600; color: #1a1a1a; margin: 0 0 10px 0; }
    .cta-box p { color: #666666; font-size: 14px; margin: 0 0 20px 0; }
    .btn { display: inline-block; background-color: #000000; color: #ffffff; padding: 14px 32px; text-decoration: none; border-radius: 4px; font-weight: 600; font-size: 14px; }
    .footer { background-color: #1a1a1a; padding: 40px; text-align: center; }
    .footer p { color: #999999; font-size: 12px; margin: 5px 0; }
    .footer a { color: #cccccc; text-decoration: none; }
  </style>
</head>
<body>
  <div class="container">
    <!-- Header -->
    <div class="header">
      {% if shop.email_logo_url %}
        <img src="{{ shop.email_logo_url }}" alt="{{ shop.name }}" style="max-height: 40px;">
      {% else %}
        <h1>{{ shop.name | upcase }}</h1>
      {% endif %}
    </div>

    <!-- Content -->
    <div class="content">
      <!-- Hero Section -->
      <div class="hero">
        <h2>Order Cancelled</h2>
        <p>Your order has been cancelled as requested.</p>
        <div class="order-number">Order {{ name }}</div>
      </div>

      <!-- Info Box -->
      <div class="info-box">
        <p>
          {% if financial_status == 'refunded' or financial_status == 'partially_refunded' %}
            Your refund has been processed and should appear in your account within 5-10 business days, depending on your payment provider.
          {% else %}
            If you were charged, a refund will be processed shortly and should appear in your account within 5-10 business days.
          {% endif %}
        </p>
      </div>

      <!-- Cancelled Items -->
      <div class="section">
        <div class="section-title">Cancelled Items</div>
        {% for line in line_items %}
        <div class="item">
          <span class="item-title">{{ line.title }}{% if line.variant_title != 'Default Title' %} - {{ line.variant_title }}{% endif %} × {{ line.quantity }}</span>
          <span class="item-price">{{ line.final_line_price | money }}</span>
        </div>
        {% endfor %}
      </div>

      <!-- CTA -->
      <div class="cta-box">
        <h3>Changed Your Mind?</h3>
        <p>We'd love to have you back. Browse our latest collection.</p>
        <a href="https://kctmenswear.com/collections" class="btn">Shop Now</a>
      </div>

      <p style="text-align: center; color: #666666; font-size: 14px; margin-top: 30px;">
        Questions? <a href="https://kctmenswear.com/contact" style="color: #000000;">Contact our team</a>
      </p>
    </div>

    <!-- Footer -->
    <div class="footer">
      <p>{{ shop.name }}</p>
      <p><a href="{{ shop.url }}">Visit our store</a></p>
    </div>
  </div>
</body>
</html>
```

---

## 5. Refund Notification

**Location:** Shopify Admin → Settings → Notifications → Refund notification

```liquid
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Refund Processed - {{ shop.name }}</title>
  <style>
    body { margin: 0; padding: 0; background-color: #f8f8f8; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; }
    .container { max-width: 600px; margin: 0 auto; background-color: #ffffff; }
    .header { background-color: #000000; padding: 30px 40px; text-align: center; }
    .header h1 { color: #ffffff; font-size: 24px; font-weight: 300; letter-spacing: 2px; margin: 0; }
    .content { padding: 40px; }
    .hero { text-align: center; padding-bottom: 30px; border-bottom: 1px solid #e5e5e5; margin-bottom: 30px; }
    .hero-icon { font-size: 48px; margin-bottom: 15px; }
    .hero h2 { font-size: 26px; font-weight: 600; color: #1a1a1a; margin: 0 0 10px 0; }
    .hero p { color: #666666; font-size: 16px; margin: 0; }
    .refund-amount { background-color: #e8f5e9; padding: 25px; border-radius: 8px; text-align: center; margin-bottom: 30px; }
    .refund-amount p { margin: 0 0 5px 0; color: #666666; font-size: 14px; }
    .refund-amount .amount { font-size: 32px; font-weight: 700; color: #2e7d32; }
    .info-box { background-color: #f5f5f5; padding: 20px; border-radius: 8px; margin-bottom: 30px; }
    .info-box p { color: #333333; font-size: 14px; margin: 0; line-height: 1.6; }
    .section-title { font-size: 14px; font-weight: 600; text-transform: uppercase; letter-spacing: 1px; color: #999999; margin-bottom: 15px; }
    .item { display: flex; justify-content: space-between; padding: 10px 0; border-bottom: 1px solid #f0f0f0; font-size: 14px; }
    .item:last-child { border-bottom: none; }
    .cta-box { background-color: #f8f5f0; padding: 30px; text-align: center; border-radius: 8px; margin-top: 30px; }
    .cta-box h3 { font-size: 18px; font-weight: 600; color: #1a1a1a; margin: 0 0 10px 0; }
    .cta-box p { color: #666666; font-size: 14px; margin: 0 0 20px 0; }
    .btn { display: inline-block; background-color: #000000; color: #ffffff; padding: 14px 32px; text-decoration: none; border-radius: 4px; font-weight: 600; font-size: 14px; }
    .footer { background-color: #1a1a1a; padding: 40px; text-align: center; }
    .footer p { color: #999999; font-size: 12px; margin: 5px 0; }
    .footer a { color: #cccccc; text-decoration: none; }
  </style>
</head>
<body>
  <div class="container">
    <!-- Header -->
    <div class="header">
      {% if shop.email_logo_url %}
        <img src="{{ shop.email_logo_url }}" alt="{{ shop.name }}" style="max-height: 40px;">
      {% else %}
        <h1>{{ shop.name | upcase }}</h1>
      {% endif %}
    </div>

    <!-- Content -->
    <div class="content">
      <!-- Hero Section -->
      <div class="hero">
        <div class="hero-icon">✓</div>
        <h2>Refund Processed</h2>
        <p>Your refund for order {{ name }} has been processed.</p>
      </div>

      <!-- Refund Amount -->
      <div class="refund-amount">
        <p>Refund Amount</p>
        <div class="amount">{{ amount | money }}</div>
      </div>

      <!-- Info Box -->
      <div class="info-box">
        <p>
          Your refund has been processed and will be credited to your original payment method. 
          Please allow 5-10 business days for the refund to appear in your account, depending on your bank or card issuer.
        </p>
      </div>

      <!-- Refund Details -->
      {% if refund_line_items.size > 0 %}
      <div class="section">
        <div class="section-title">Refunded Items</div>
        {% for line in refund_line_items %}
        <div class="item">
          <span>{{ line.line_item.title }} × {{ line.quantity }}</span>
          <span>{{ line.subtotal | money }}</span>
        </div>
        {% endfor %}
      </div>
      {% endif %}

      <!-- CTA -->
      <div class="cta-box">
        <h3>We'd Love to See You Again</h3>
        <p>Browse our latest arrivals and find something you'll love.</p>
        <a href="https://kctmenswear.com/collections" class="btn">Shop New Arrivals</a>
      </div>

      <p style="text-align: center; color: #666666; font-size: 14px; margin-top: 30px;">
        Questions about your refund? <a href="https://kctmenswear.com/contact" style="color: #000000;">Contact us</a>
      </p>
    </div>

    <!-- Footer -->
    <div class="footer">
      <p>{{ shop.name }}</p>
      <p><a href="{{ shop.url }}">Visit our store</a></p>
    </div>
  </div>
</body>
</html>
```

---

## 6. Delivery Confirmation (Out for Delivery)

**Location:** Shopify Admin → Settings → Notifications → Out for delivery

```liquid
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Your Order is Out for Delivery - {{ shop.name }}</title>
  <style>
    body { margin: 0; padding: 0; background-color: #f8f8f8; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; }
    .container { max-width: 600px; margin: 0 auto; background-color: #ffffff; }
    .header { background-color: #000000; padding: 30px 40px; text-align: center; }
    .header h1 { color: #ffffff; font-size: 24px; font-weight: 300; letter-spacing: 2px; margin: 0; }
    .content { padding: 40px; }
    .hero { text-align: center; padding-bottom: 30px; margin-bottom: 30px; }
    .hero-icon { font-size: 64px; margin-bottom: 15px; }
    .hero h2 { font-size: 28px; font-weight: 600; color: #1a1a1a; margin: 0 0 10px 0; }
    .hero p { color: #666666; font-size: 16px; margin: 0; }
    .delivery-box { background-color: #e3f2fd; border-radius: 8px; padding: 25px; text-align: center; margin-bottom: 30px; }
    .delivery-box h3 { font-size: 18px; font-weight: 600; color: #1565c0; margin: 0 0 10px 0; }
    .delivery-box p { color: #333333; font-size: 14px; margin: 0; }
    .address-box { background-color: #f5f5f5; padding: 20px; border-radius: 8px; margin-bottom: 30px; }
    .address-box .label { font-size: 12px; font-weight: 600; text-transform: uppercase; letter-spacing: 1px; color: #999999; margin-bottom: 10px; }
    .address-box p { margin: 0; font-size: 14px; line-height: 1.6; color: #333333; }
    .btn { display: inline-block; background-color: #000000; color: #ffffff; padding: 14px 32px; text-decoration: none; border-radius: 4px; font-weight: 600; font-size: 14px; }
    .btn-row { text-align: center; margin-bottom: 30px; }
    .footer { background-color: #1a1a1a; padding: 40px; text-align: center; }
    .footer p { color: #999999; font-size: 12px; margin: 5px 0; }
    .footer a { color: #cccccc; text-decoration: none; }
  </style>
</head>
<body>
  <div class="container">
    <!-- Header -->
    <div class="header">
      {% if shop.email_logo_url %}
        <img src="{{ shop.email_logo_url }}" alt="{{ shop.name }}" style="max-height: 40px;">
      {% else %}
        <h1>{{ shop.name | upcase }}</h1>
      {% endif %}
    </div>

    <!-- Content -->
    <div class="content">
      <!-- Hero Section -->
      <div class="hero">
        <div class="hero-icon">🎉</div>
        <h2>Almost There!</h2>
        <p>Your order {{ order_name }} is out for delivery today.</p>
      </div>

      <!-- Delivery Info -->
      <div class="delivery-box">
        <h3>Arriving Today</h3>
        <p>Keep an eye out for the delivery driver. Your package should arrive shortly!</p>
      </div>

      <!-- Delivery Address -->
      <div class="address-box">
        <div class="label">Delivering To</div>
        <p>
          {{ shipping_address.name }}<br>
          {{ shipping_address.address1 }}<br>
          {% if shipping_address.address2 %}{{ shipping_address.address2 }}<br>{% endif %}
          {{ shipping_address.city }}, {{ shipping_address.province_code }} {{ shipping_address.zip }}
        </p>
      </div>

      <!-- Track Button -->
      <div class="btn-row">
        {% if fulfillment.tracking_url %}
          <a href="{{ fulfillment.tracking_url }}" class="btn">Track Live Location</a>
        {% endif %}
        <br><br>
        <a href="https://kctmenswear.com/order-lookup" style="color: #000000; font-size: 14px;">Track on our website →</a>
      </div>

      <p style="text-align: center; color: #666666; font-size: 14px;">
        Not home? Most carriers will leave the package in a safe location or attempt redelivery.
      </p>
    </div>

    <!-- Footer -->
    <div class="footer">
      <p>{{ shop.name }}</p>
      <p><a href="{{ shop.url }}">Visit our store</a></p>
    </div>
  </div>
</body>
</html>
```

---

## 7. Delivered Confirmation

**Location:** Shopify Admin → Settings → Notifications → Delivered

```liquid
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Your Order Has Been Delivered - {{ shop.name }}</title>
  <style>
    body { margin: 0; padding: 0; background-color: #f8f8f8; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; }
    .container { max-width: 600px; margin: 0 auto; background-color: #ffffff; }
    .header { background-color: #000000; padding: 30px 40px; text-align: center; }
    .header h1 { color: #ffffff; font-size: 24px; font-weight: 300; letter-spacing: 2px; margin: 0; }
    .content { padding: 40px; }
    .hero { text-align: center; padding-bottom: 30px; margin-bottom: 30px; }
    .hero-icon { font-size: 64px; margin-bottom: 15px; }
    .hero h2 { font-size: 28px; font-weight: 600; color: #1a1a1a; margin: 0 0 10px 0; }
    .hero p { color: #666666; font-size: 16px; margin: 0; }
    .delivered-box { background-color: #e8f5e9; border-radius: 8px; padding: 25px; text-align: center; margin-bottom: 30px; }
    .delivered-box .checkmark { font-size: 40px; margin-bottom: 10px; }
    .delivered-box h3 { font-size: 18px; font-weight: 600; color: #2e7d32; margin: 0; }
    .section { margin-bottom: 30px; }
    .section-title { font-size: 14px; font-weight: 600; text-transform: uppercase; letter-spacing: 1px; color: #999999; margin-bottom: 15px; }
    .item { display: flex; padding: 12px 0; border-bottom: 1px solid #f0f0f0; }
    .item:last-child { border-bottom: none; }
    .item-image { width: 60px; height: 75px; object-fit: cover; border-radius: 4px; margin-right: 15px; background-color: #f5f5f5; }
    .item-details { flex: 1; }
    .item-title { font-size: 14px; font-weight: 500; color: #1a1a1a; margin: 0; }
    .item-variant { font-size: 13px; color: #666666; margin: 5px 0 0 0; }
    .cta-grid { display: flex; gap: 15px; margin-bottom: 30px; }
    .cta-card { flex: 1; background-color: #f8f5f0; padding: 25px 20px; border-radius: 8px; text-align: center; }
    .cta-card h4 { font-size: 16px; font-weight: 600; color: #1a1a1a; margin: 0 0 8px 0; }
    .cta-card p { font-size: 13px; color: #666666; margin: 0 0 15px 0; }
    .btn { display: inline-block; background-color: #000000; color: #ffffff; padding: 12px 24px; text-decoration: none; border-radius: 4px; font-weight: 600; font-size: 13px; }
    .btn-outline { background-color: transparent; border: 2px solid #000000; color: #000000; }
    .help-text { text-align: center; color: #666666; font-size: 14px; margin-top: 20px; }
    .help-text a { color: #000000; }
    .footer { background-color: #1a1a1a; padding: 40px; text-align: center; }
    .footer p { color: #999999; font-size: 12px; margin: 5px 0; }
    .footer a { color: #cccccc; text-decoration: none; }
  </style>
</head>
<body>
  <div class="container">
    <!-- Header -->
    <div class="header">
      {% if shop.email_logo_url %}
        <img src="{{ shop.email_logo_url }}" alt="{{ shop.name }}" style="max-height: 40px;">
      {% else %}
        <h1>{{ shop.name | upcase }}</h1>
      {% endif %}
    </div>

    <!-- Content -->
    <div class="content">
      <!-- Hero Section -->
      <div class="hero">
        <div class="hero-icon">📬</div>
        <h2>Your Order Has Arrived!</h2>
        <p>Order {{ order_name }} has been delivered.</p>
      </div>

      <!-- Delivered Confirmation -->
      <div class="delivered-box">
        <div class="checkmark">✓</div>
        <h3>Successfully Delivered</h3>
      </div>

      <!-- Delivered Items -->
      <div class="section">
        <div class="section-title">What's in Your Package</div>
        {% for line in line_items %}
        <div class="item">
          {% if line.image %}
            <img src="{{ line | img_url: 'compact_cropped' }}" alt="{{ line.title }}" class="item-image">
          {% endif %}
          <div class="item-details">
            <p class="item-title">{{ line.title }}</p>
            {% if line.variant_title != 'Default Title' %}
              <p class="item-variant">{{ line.variant_title }} • Qty: {{ line.quantity }}</p>
            {% else %}
              <p class="item-variant">Qty: {{ line.quantity }}</p>
            {% endif %}
          </div>
        </div>
        {% endfor %}
      </div>

      <!-- CTAs -->
      <div class="cta-grid">
        <div class="cta-card">
          <h4>Need to Return?</h4>
          <p>Easy returns within 30 days.</p>
          <a href="https://kctmenswear.com/returns" class="btn btn-outline">Start Return</a>
        </div>
        <div class="cta-card">
          <h4>Love It?</h4>
          <p>Share your style with us!</p>
          <a href="https://kctmenswear.com/collections" class="btn">Shop More</a>
        </div>
      </div>

      <p class="help-text">
        Didn't receive your package? <a href="https://kctmenswear.com/contact">Contact us</a> within 48 hours.
      </p>
    </div>

    <!-- Footer -->
    <div class="footer">
      <p>{{ shop.name }}</p>
      <p><a href="{{ shop.url }}">Visit our store</a></p>
    </div>
  </div>
</body>
</html>
```

---

## Installation Instructions

1. **Go to** Shopify Admin → Settings → Notifications
2. **Click** on each notification type listed above
3. **Scroll down** to the Email body (HTML) section
4. **Replace** the entire content with the corresponding template above
5. **Click** Save (all links already point to `kctmenswear.com`)

### Tips
- Preview each email before saving to ensure it looks correct
- Send a test email to yourself
- Update the social links in the footer with your actual social media URLs
- Customize colors by changing the hex values (e.g., `#000000` for black, `#f8f5f0` for the warm beige accent)
