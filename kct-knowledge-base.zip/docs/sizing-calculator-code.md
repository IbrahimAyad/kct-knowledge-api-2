# Size Bot - Sizing Calculator Code

Complete TypeScript implementation for the deterministic sizing calculator.

## Overview

This calculator determines suit, pants, and shirt sizes based on height, weight, and fit preference (slim vs classic). Key principles:
- **Slim fit suits** require sizing UP (+2") because the cut is tighter
- **Pants** come nested with suits (jacket - 6"), but actual waist may differ
- **~15 lbs per size step** weight-to-chest mapping

---

## Full Code

```typescript
// Deterministic Sizing Calculator
// Slim vs Classic fits. Slim cut suits require sizing UP.
// Pants come nested (jacket - 6), but actual waist may differ.

export type FitPreference = 'slim' | 'classic';

export interface SizingResult {
  jacket: {
    size: string;
    chest: number;
    length: 'S' | 'R' | 'L';
  };
  pants: {
    waist: number;           // Actual recommended waist from body
    nestedWaist: number;     // What comes with the suit (jacket - 6)
    inseam: number;
    display: string;
    needsTailoring: boolean;
    tailoringNote?: string;
  };
  shirt: {
    neck: number;
    sleeve: number;
    sleeveRange: string;
  };
  confidencePercent: number;
  confidence: 'high' | 'medium' | 'low';
  rationale: string;
}

export interface AlternativeSize {
  size: string;
  confidencePercent: number;
  note: string;
}

function clamp(n: number, min: number, max: number) {
  return Math.max(min, Math.min(max, n));
}

function roundToEven(n: number) {
  return Math.round(n / 2) * 2;
}

function bmi(heightInches: number, weightLbs: number) {
  return (weightLbs / (heightInches * heightInches)) * 703;
}

function getJacketLength(heightInches: number, chest: number): 'S' | 'R' | 'L' {
  // Short: under 5'6" (66")
  if (heightInches < 66) return 'S';
  
  // Regular extends further for larger sizes (bigger guys can wear R up to 6'2")
  // Smaller sizes transition to L earlier
  const regularMaxHeight = chest >= 46 ? 74 : chest >= 42 ? 73 : 72;
  
  if (heightInches <= regularMaxHeight) return 'R';
  return 'L';
}

function getBaseChestFromWeight(weightLbs: number): number {
  // Calibrated from real sizing data (pattern: ~15 lbs per size step):
  // 38R: Slim 163-183 lbs (base 36+2), Classic 178-193 lbs (base 38)
  // 42R: Slim 193-208 lbs (base 40+2), Classic 208-223 lbs (base 42)
  if (weightLbs < 130) return 32;   // Very slim
  if (weightLbs < 145) return 34;   // 130-144: 34 base
  if (weightLbs < 163) return 36;   // 145-162: 36R classic, 38R slim
  if (weightLbs < 178) return 36;   // 163-177: 36R classic, 38R slim (max for slim 38)
  if (weightLbs < 193) return 38;   // 178-192: 38R classic, 40R slim
  if (weightLbs < 208) return 40;   // 193-207: 40R classic, 42R slim
  if (weightLbs < 223) return 42;   // 208-222: 42R classic, 44R slim
  if (weightLbs < 240) return 44;   // 223-239: 44R classic, 46R slim
  if (weightLbs < 260) return 46;   // 240-259: 46R classic, 48R slim
  if (weightLbs < 285) return 48;   // 260-284: 48R classic, 50R slim
  if (weightLbs < 315) return 50;   // 285-314: 50R classic, 52R slim
  if (weightLbs < 350) return 52;   // 315-349: 52R classic, 54R slim
  return 54;                        // 350+: 54R
}

function heightAdjustment(heightInches: number, weightLbs: number): number {
  // Tall people with proportional weight have BIGGER frames, need larger sizes
  // Only reduce for tall AND lean people (low BMI)
  const v = bmi(heightInches, weightLbs);
  
  if (heightInches >= 76) {
    // 6'4"+ : if lean (BMI < 24) reduce, otherwise add for bigger frame
    if (v < 24) return 0;
    return 2;
  }
  if (heightInches >= 74) {
    // 6'2"-6'3": slight adjustment
    if (v < 24) return 0;
    return 1;
  }
  if (heightInches <= 64) {
    // Under 5'4": smaller frame
    return -2;
  }
  if (heightInches <= 66) {
    // 5'4"-5'6": slightly smaller
    return -1;
  }
  return 0;
}

function getActualWaistFromWeight(weightLbs: number): number {
  // Waist calculated from weight, independent of jacket
  if (weightLbs < 140) return 28;
  if (weightLbs < 155) return 30;
  if (weightLbs < 170) return 32;
  if (weightLbs < 185) return 34;
  if (weightLbs < 200) return 36;
  if (weightLbs < 220) return 38;
  if (weightLbs < 245) return 40;
  if (weightLbs < 270) return 42;
  if (weightLbs < 300) return 44;
  if (weightLbs < 330) return 46;
  if (weightLbs < 360) return 48;
  return 50;
}

function inseamFromHeight(heightInches: number) {
  if (heightInches < 64) return 28;   // Under 5'4"
  if (heightInches < 66) return 29;   // 5'4" to 5'5"
  if (heightInches < 68) return 30;   // 5'6" to 5'7"
  if (heightInches < 70) return 31;   // 5'8" to 5'9"
  if (heightInches < 72) return 32;   // 5'10" to 5'11"
  if (heightInches < 74) return 32;   // 6'0" to 6'1"
  if (heightInches < 76) return 33;   // 6'2" to 6'3"
  if (heightInches < 78) return 34;   // 6'4" to 6'5"
  if (heightInches < 80) return 34;   // 6'6" to 6'7" → 34-35
  return 36;  // 6'8"+
}

function shirtFromHeightWeight(heightInches: number, weightLbs: number) {
  // Neck: half sizes from 14.5-18.5, then 19, 20, 22 (no 19.5, 20.5, 21.5)
  let neck: number;
  if (weightLbs < 140) neck = 14;
  else if (weightLbs < 150) neck = 14.5;
  else if (weightLbs < 160) neck = 15;
  else if (weightLbs < 170) neck = 15.5;
  else if (weightLbs < 180) neck = 16;
  else if (weightLbs < 190) neck = 16.5;
  else if (weightLbs < 200) neck = 17;
  else if (weightLbs < 215) neck = 17.5;
  else if (weightLbs < 230) neck = 18;
  else if (weightLbs < 245) neck = 18.5;
  else if (weightLbs < 265) neck = 19;
  else if (weightLbs < 295) neck = 20;
  else neck = 22;

  // Sleeve: 6'7" (79") → 36-37
  let sleeve: number;
  let sleeveRange: string;
  if (heightInches < 66) { sleeve = 32; sleeveRange = '32'; }
  else if (heightInches < 68) { sleeve = 33; sleeveRange = '32-33'; }
  else if (heightInches < 71) { sleeve = 34; sleeveRange = '33-34'; }
  else if (heightInches < 74) { sleeve = 35; sleeveRange = '34-35'; }
  else if (heightInches < 77) { sleeve = 36; sleeveRange = '35-36'; }
  else { sleeve = 36; sleeveRange = '36-37'; }

  return { neck, sleeve, sleeveRange };
}

function confidenceFromInputs(heightInches: number, weightLbs: number, chest: number) {
  const v = bmi(heightInches, weightLbs);
  let c = 85;

  if (v >= 20 && v <= 28) c += 10;
  else if (v >= 18 && v <= 32) c += 5;
  else c -= 5;

  if (heightInches >= 66 && heightInches <= 74) c += 3;
  if (chest >= 38 && chest <= 48) c += 2;

  return clamp(c, 70, 98);
}

export function calculateSizing(heightInches: number, weightLbs: number, fitPreference: FitPreference): SizingResult {
  let chest = getBaseChestFromWeight(weightLbs);
  
  // Height adjustment based on frame size
  chest += heightAdjustment(heightInches, weightLbs);

  // Fit logic: slim CUT suits are tailored tighter, so size UP to get same room
  // Classic fit = standard sizing
  if (fitPreference === 'slim') chest += 2;

  chest = clamp(roundToEven(chest), 34, 56);

  const length = getJacketLength(heightInches, chest);
  
  // Pants: nested (comes with suit) vs actual (what customer needs)
  const nestedWaist = chest - 6;  // Standard 6" drop
  const actualWaist = getActualWaistFromWeight(weightLbs);
  const inseam = inseamFromHeight(heightInches);
  
  // Check if tailoring needed
  const waistDiff = Math.abs(nestedWaist - actualWaist);
  const needsTailoring = waistDiff >= 2;
  
  let tailoringNote: string | undefined;
  if (needsTailoring) {
    if (actualWaist < nestedWaist) {
      tailoringNote = `Suit comes with ${nestedWaist}W pants. You may need ${actualWaist}W - consider tailoring or pants swap.`;
    } else {
      tailoringNote = `Suit comes with ${nestedWaist}W pants. You may need ${actualWaist}W - consider sizing up or pants swap.`;
    }
  }
  
  const shirt = shirtFromHeightWeight(heightInches, weightLbs);

  const confidencePercent = confidenceFromInputs(heightInches, weightLbs, chest);
  const confidence: SizingResult['confidence'] = confidencePercent >= 90 ? 'high' : confidencePercent >= 80 ? 'medium' : 'low';

  const fitNote = fitPreference === 'slim' ? 'slim cut' : 'classic cut';

  return {
    jacket: { size: `${chest}${length}`, chest, length },
    pants: { 
      waist: actualWaist, 
      nestedWaist,
      inseam, 
      display: `${nestedWaist}x${inseam}`,
      needsTailoring,
      tailoringNote
    },
    shirt,
    confidencePercent,
    confidence,
    rationale: `Based on ${heightInches}" height and ${weightLbs} lbs with ${fitNote} preference. Jacket: ${chest}${length}. Pants nested at ${nestedWaist}W (your waist ~${actualWaist}W).`,
  };
}

export function getAlternativeSize(current: SizingResult, direction: 'smaller' | 'larger'): AlternativeSize | null {
  const delta = direction === 'larger' ? 2 : -2;
  const newChest = current.jacket.chest + delta;
  if (newChest < 34 || newChest > 56) return null;

  const size = `${newChest}${current.jacket.length}`;
  const confidencePercent = clamp(current.confidencePercent - 15, 70, 98);
  const note = direction === 'larger' ? 'More room / comfort fit' : 'Slimmer fit';

  return { size, confidencePercent, note };
}
```

---

## Weight-to-Size Reference Table

| Weight (lbs) | Base Chest | Classic Fit | Slim Fit (+2) |
|--------------|------------|-------------|---------------|
| < 130        | 32         | 32R         | 34R           |
| 130-144      | 34         | 34R         | 36R           |
| 145-162      | 36         | 36R         | 38R           |
| 163-177      | 36         | 36R         | 38R           |
| 178-192      | 38         | 38R         | 40R           |
| 193-207      | 40         | 40R         | 42R           |
| 208-222      | 42         | 42R         | 44R           |
| 223-239      | 44         | 44R         | 46R           |
| 240-259      | 46         | 46R         | 48R           |
| 260-284      | 48         | 48R         | 50R           |
| 285-314      | 50         | 50R         | 52R           |
| 315-349      | 52         | 52R         | 54R           |
| 350+         | 54         | 54R         | 56R           |

---

## Height-to-Length Reference

| Height       | Length |
|--------------|--------|
| Under 5'6"   | S      |
| 5'6" - 6'0"  | R      |
| 6'1"+        | L      |

*Note: Larger chest sizes (46+) can wear R up to 6'2"*

---

## Key Algorithms

### Fit Logic
- **Classic fit**: Uses base chest directly
- **Slim fit**: Adds +2" to base chest (slim cuts are tighter, so size up)

### Pants Logic
- **Nested waist**: jacket size - 6 (what comes with suit)
- **Actual waist**: Calculated independently from weight
- **Tailoring flag**: Triggered when difference ≥ 2"

### Confidence Score
- Base: 85%
- BMI 20-28: +10%
- BMI 18-32: +5%
- Height 5'6"-6'2": +3%
- Chest 38-48: +2%
- Range: 70-98%
